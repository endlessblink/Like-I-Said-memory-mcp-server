---
id: 17504125371823ugwbvx5e
timestamp: 2025-06-20T09:42:17.182Z
complexity: 4
category: code
tags: ["backup-system", "data-protection", "nodejs", "enterprise-grade", "real-time-monitoring", "chokidar", "compression", "integrity-verification", "multi-location", "disaster-recovery"]
priority: medium
status: active
access_count: 0
last_accessed: 2025-06-20T09:42:17.183Z
metadata:
  content_type: code
  size: 5348
  mermaid_diagram: false
---
## Bulletproof Backup & Data Protection System

This is the complete backup system implementation created to prevent data loss in the Like-I-Said MCP v2 project. It provides enterprise-grade protection with real-time monitoring, multi-location redundancy, and integrity verification.

### **Core Components:**

#### **1. Real-Time File Watcher (backup-system.js)**
```javascript
import chokidar from 'chokidar';
import compressing from 'compressing';
import fs from 'fs';
import crypto from 'crypto';

// Configuration
const MEMORIES_DIR = path.resolve('./memories');
const BACKUP_DIR = path.resolve('./backups');
const EXTERNAL_BACKUP = process.env.EXTERNAL_BACKUP_PATH;
const MAX_LOCAL_BACKUPS = 30;
const BACKUP_DEBOUNCE_MS = 5000;

// File watcher with chokidar
const watcher = chokidar.watch(MEMORIES_DIR, {
  persistent: true,
  ignoreInitial: true,
  awaitWriteFinish: { stabilityThreshold: 2000, pollInterval: 100 },
  depth: 10
});

// Backup on any change
watcher.on('add', scheduleBackup)
       .on('change', scheduleBackup)
       .on('unlink', scheduleBackup);
```

#### **2. Compressed Backup with Checksums**
```javascript
async function performBackup() {
  // Create compressed archive
  const backupPath = path.join(BACKUP_DIR, `backup-${timestamp}.tar.gz`);
  await compressing.tgz.compressDir(MEMORIES_DIR, backupPath);
  
  // Generate SHA-256 checksum
  const checksum = await generateChecksum(backupPath);
  await fs.writeFile(`${backupPath}.sha256`, checksum);
  
  // Copy to external location
  await fs.copyFile(backupPath, externalBackupPath);
  
  // Create metadata file
  const metadata = { timestamp, memoryCount, checksum, size, stateHash };
  await fs.writeFile(`${backupPath}.meta.json`, JSON.stringify(metadata, null, 2));
}
```

#### **3. CLI Runner (backup-runner.js)**
```javascript
// Commands:
// node backup-runner.js backup    - Single backup
// node backup-runner.js status    - System status
// node backup-runner.js verify    - Verify backup integrity
// node backup-runner.js restore   - Test restoration
// node backup-runner.js watch     - Start file watcher
```

#### **4. Git Pre-Commit Hook**
```bash
#!/bin/bash
# .git/hooks/pre-commit

MEMORY_COUNT=$(find memories/ -name "*.md" -type f | wc -l)
if [ "$MEMORY_COUNT" -lt 50 ]; then
    echo "❌ ERROR: Memory count suspiciously low ($MEMORY_COUNT)"
    exit 1
fi

# Run backup before commit
node backup-runner.js backup
```

### **Features:**

#### **Multi-Location Storage:**
1. **Local**: `./backups/` (rolling 30-day retention)
2. **External**: `/path/to/external/backup` (synchronized)
3. **Git**: Backup metadata committed automatically

#### **Integrity Protection:**
- **SHA-256 checksums** for every backup
- **Metadata tracking** (timestamp, count, size, state hash)
- **Periodic verification** (hourly integrity checks)
- **Restoration testing** (automated extraction validation)

#### **Smart Deduplication:**
- **State hashing** prevents redundant backups
- **Change detection** only backs up when files actually change
- **Debouncing** batches rapid changes into single backup

#### **Error Recovery:**
- **Backup verification** before marking complete
- **Restoration testing** validates archive integrity
- **Multiple recovery points** with 30-day retention
- **External redundancy** protects against local failures

### **Installation & Setup:**

#### **Dependencies:**
```bash
npm install chokidar compressing
```

#### **Environment Variables:**
```bash
EXTERNAL_BACKUP_PATH=/mnt/external/backups
BACKUP_KEY=your-encryption-key-optional
```

#### **Usage:**
```bash
# Start continuous monitoring
node backup-runner.js watch

# Manual operations
node backup-runner.js backup   # Single backup
node backup-runner.js status   # Check system
node backup-runner.js verify backup.tar.gz  # Verify integrity
```

### **Protection Against Data Loss:**

#### **Real-Time Monitoring:**
- Watches ALL file operations (create/modify/delete)
- Triggers backup within 5 seconds of last change
- Monitors entire directory tree recursively

#### **Multi-Layer Redundancy:**
- Local backups (immediate access)
- External backups (hardware failure protection)  
- Git metadata (version control integration)
- Checksum verification (corruption detection)

#### **Integrity Assurance:**
- SHA-256 checksums prevent corruption
- Metadata validation ensures completeness
- Restoration testing verifies recoverability
- State hashing prevents duplicate work

### **Recovery Process:**
1. **Identify backup**: `node backup-runner.js status`
2. **Verify integrity**: `node backup-runner.js verify backup.tar.gz`
3. **Test extraction**: `node backup-runner.js restore backup.tar.gz`
4. **Manual restore**: Extract to target directory

### **Customization:**
- **Retention policy**: Change `MAX_LOCAL_BACKUPS`
- **Backup locations**: Set `EXTERNAL_BACKUP_PATH`
- **Debounce timing**: Adjust `BACKUP_DEBOUNCE_MS`
- **Watch patterns**: Modify chokidar configuration

### **Performance:**
- **Minimal CPU usage**: Event-driven architecture
- **Efficient compression**: tar.gz format with good ratio
- **Smart deduplication**: Only backup real changes
- **Non-blocking**: Backup runs in separate process

This system prevented complete data loss in the Like-I-Said MCP project and can be adapted for any Node.js project requiring bulletproof data protection.