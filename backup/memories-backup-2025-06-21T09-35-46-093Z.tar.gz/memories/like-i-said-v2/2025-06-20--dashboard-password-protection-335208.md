---
id: 1750407335204bd62g4zw2
timestamp: 2025-06-20T08:15:35.204Z
complexity: 4
category: code
project: like-i-said-v2
tags: ["feature-plan", "authentication", "security", "dashboard", "password-protection", "express", "react", "implementation-plan"]
priority: high
status: active
access_count: 0
last_accessed: 2025-06-20T08:15:35.204Z
metadata:
  content_type: code
  size: 13976
  mermaid_diagram: false
---
# Dashboard Password Protection Feature Plan

## Overview
Add password authentication to the Like-I-Said v2 dashboard to secure access to memory data. This feature will protect the dashboard from unauthorized access while maintaining ease of use for legitimate users.

## Current Architecture Analysis

### Frontend (React)
- **Main App**: `src/App.tsx` - Single-page application with tab navigation
- **Dashboard Server**: `dashboard-server.js` - Express.js API server on port 3001
- **Routes**: Static serving of React build + API endpoints (`/api/*`)
- **Build Output**: Served from `dist/` directory

### Key Endpoints
- `GET /api/memories` - Fetch all memories
- `GET /api/memories/:id` - Fetch specific memory
- `POST /api/memories` - Create new memory
- `PUT /api/memories/:id` - Update memory
- `DELETE /api/memories/:id` - Delete memory
- `GET /api/projects` - Fetch projects
- `GET /api/status` - Server status

## Implementation Plan

### 1. Authentication Strategy

#### Option A: Simple Password Hash (Recommended)
```javascript
// Environment variable or config file
const DASHBOARD_PASSWORD_HASH = process.env.DASHBOARD_PASSWORD_HASH || null

// bcrypt for password hashing
const bcrypt = require('bcryptjs')
```

#### Option B: Session-Based Auth
```javascript
// Express session middleware
const session = require('express-session')
const FileStore = require('session-file-store')(session)
```

#### Option C: JWT Token Auth
```javascript
// JWT for stateless authentication
const jwt = require('jsonwebtoken')
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret'
```

### 2. Backend Implementation (`dashboard-server.js`)

#### 2.1 Authentication Middleware
```javascript
class DashboardBridge {
  constructor(port = 3001, options = {}) {
    this.requireAuth = options.requireAuth || false
    this.passwordHash = options.passwordHash || process.env.DASHBOARD_PASSWORD_HASH
    // ... existing constructor
  }

  setupExpress() {
    this.app.use(cors())
    this.app.use(express.json())
    
    // Session middleware (if using sessions)
    if (this.requireAuth) {
      this.app.use(session({
        secret: process.env.SESSION_SECRET || 'like-i-said-session',
        resave: false,
        saveUninitialized: false,
        cookie: { 
          secure: false, // Set to true in production with HTTPS
          maxAge: 24 * 60 * 60 * 1000 // 24 hours
        }
      }))
    }

    // Authentication routes (before protection)
    this.app.post('/api/auth/login', this.login.bind(this))
    this.app.post('/api/auth/logout', this.logout.bind(this))
    this.app.get('/api/auth/status', this.getAuthStatus.bind(this))

    // Serve login page for unauthenticated users
    this.app.get('/login', (req, res) => {
      res.sendFile(path.resolve('dist/login.html'))
    })

    // Protection middleware for API routes
    this.app.use('/api', this.requireAuthentication.bind(this))
    
    // Existing API routes...
    this.app.get('/api/memories', this.getMemories.bind(this))
    // ... rest of API routes

    // Serve React app (also protected)
    this.app.get('*', this.requireAuthentication.bind(this), (req, res) => {
      res.sendFile(path.resolve('dist/index.html'))
    })
  }

  requireAuthentication(req, res, next) {
    if (!this.requireAuth || !this.passwordHash) {
      return next() // No authentication required
    }

    // Check session authentication
    if (req.session && req.session.authenticated) {
      return next()
    }

    // Check JWT authentication (alternative)
    const token = req.headers.authorization?.replace('Bearer ', '')
    if (token && this.verifyJWT(token)) {
      return next()
    }

    // Redirect to login
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ error: 'Authentication required' })
    } else {
      return res.redirect('/login')
    }
  }

  async login(req, res) {
    const { password } = req.body
    
    if (!password || !this.passwordHash) {
      return res.status(400).json({ error: 'Password required' })
    }

    try {
      const isValid = await bcrypt.compare(password, this.passwordHash)
      
      if (isValid) {
        req.session.authenticated = true
        res.json({ success: true, message: 'Login successful' })
      } else {
        res.status(401).json({ error: 'Invalid password' })
      }
    } catch (error) {
      res.status(500).json({ error: 'Authentication error' })
    }
  }

  logout(req, res) {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: 'Logout failed' })
      }
      res.json({ success: true, message: 'Logged out' })
    })
  }

  getAuthStatus(req, res) {
    const authenticated = !this.requireAuth || 
                        (req.session && req.session.authenticated)
    
    res.json({ 
      authenticated,
      authRequired: this.requireAuth 
    })
  }
}
```

#### 2.2 Configuration Options
```javascript
// CLI argument or environment variable
const requireAuth = process.argv.includes('--auth') || 
                   process.env.DASHBOARD_AUTH === 'true'

const passwordHash = process.env.DASHBOARD_PASSWORD_HASH

const bridge = new DashboardBridge(3001, { 
  requireAuth, 
  passwordHash 
})
```

### 3. Frontend Implementation

#### 3.1 Login Component (`src/components/Login.tsx`)
```typescript
interface LoginProps {
  onLogin: (success: boolean) => void
}

export function Login({ onLogin }: LoginProps) {
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      })

      const data = await response.json()

      if (response.ok) {
        onLogin(true)
      } else {
        setError(data.error || 'Login failed')
        onLogin(false)
      }
    } catch (error) {
      setError('Network error')
      onLogin(false)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-900 to-gray-800 flex items-center justify-center">
      <div className="bg-gray-800/50 backdrop-blur-sm border border-gray-700/50 rounded-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Like I Said</h1>
          <p className="text-gray-400">Enter password to access dashboard</p>
        </div>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              type="password"
              placeholder="Dashboard password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
              disabled={isLoading}
            />
          </div>
          
          {error && (
            <div className="text-red-400 text-sm text-center">{error}</div>
          )}
          
          <Button 
            type="submit" 
            className="w-full bg-violet-600 hover:bg-violet-700"
            disabled={isLoading || !password.trim()}
          >
            {isLoading ? 'Signing in...' : 'Sign In'}
          </Button>
        </form>
      </div>
    </div>
  )
}
```

#### 3.2 Authentication Context (`src/context/AuthContext.tsx`)
```typescript
interface AuthContextType {
  isAuthenticated: boolean
  isLoading: boolean
  login: (password: string) => Promise<boolean>
  logout: () => Promise<void>
  checkAuth: () => Promise<void>
}

export const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/status')
      const data = await response.json()
      setIsAuthenticated(data.authenticated)
    } catch (error) {
      setIsAuthenticated(false)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    checkAuth()
  }, [])

  // ... login, logout implementations
}
```

#### 3.3 App Integration (`src/App.tsx`)
```typescript
export default function App() {
  return (
    <AuthProvider>
      <AuthGuard>
        {/* Existing app content */}
      </AuthGuard>
    </AuthProvider>
  )
}

function AuthGuard({ children }: { children: React.ReactNode }) {
  const auth = useContext(AuthContext)
  
  if (auth?.isLoading) {
    return <LoadingScreen />
  }
  
  if (!auth?.isAuthenticated) {
    return <Login onLogin={auth.checkAuth} />
  }
  
  return <>{children}</>
}
```

### 4. Security Considerations

#### 4.1 Password Security
- Use bcrypt for password hashing (minimum 12 rounds)
- Store hash in environment variable, not source code
- Implement rate limiting for login attempts
- Consider password strength requirements

#### 4.2 Session Security
```javascript
// Session configuration
{
  secret: crypto.randomBytes(64).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production', // HTTPS only in prod
    httpOnly: true, // Prevent XSS
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: 'strict' // CSRF protection
  }
}
```

#### 4.3 Rate Limiting
```javascript
const rateLimit = require('express-rate-limit')

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 attempts per window
  message: 'Too many login attempts, please try again later',
  standardHeaders: true,
  legacyHeaders: false
})

app.post('/api/auth/login', loginLimiter, this.login.bind(this))
```

### 5. Configuration and Setup

#### 5.1 Environment Variables
```bash
# .env file
DASHBOARD_AUTH=true
DASHBOARD_PASSWORD_HASH=$2a$12$...  # Generated with bcrypt
SESSION_SECRET=random-secret-key
NODE_ENV=production
```

#### 5.2 CLI Setup Command
```javascript
// Add to cli.js
const setupAuth = async () => {
  const password = await prompt('Enter dashboard password: ', { silent: true })
  const hash = await bcrypt.hash(password, 12)
  
  console.log('Add this to your .env file:')
  console.log(`DASHBOARD_PASSWORD_HASH=${hash}`)
  console.log('DASHBOARD_AUTH=true')
}
```

#### 5.3 Package.json Scripts
```json
{
  "scripts": {
    "start:dashboard": "node dashboard-server.js",
    "start:dashboard:auth": "DASHBOARD_AUTH=true node dashboard-server.js",
    "setup:auth": "node cli.js setup-auth"
  }
}
```

### 6. Deployment Considerations

#### 6.1 Development vs Production
- Development: Optional authentication, clear error messages
- Production: Required authentication, minimal error exposure
- Environment-based configuration switching

#### 6.2 Docker Integration
```dockerfile
# Dockerfile additions
ENV DASHBOARD_AUTH=false
ENV DASHBOARD_PASSWORD_HASH=""
ENV SESSION_SECRET=""

# Optional: Add healthcheck that respects auth
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3001/api/auth/status || exit 1
```

#### 6.3 Reverse Proxy Considerations
- HTTPS termination for secure cookies
- Proper forwarding of client IP for rate limiting
- Session store considerations for load balancing

### 7. Alternative Implementations

#### 7.1 File-Based Configuration
```javascript
// auth-config.json
{
  "enabled": true,
  "passwordHash": "$2a$12$...",
  "sessionTimeout": 86400000,
  "rateLimiting": {
    "enabled": true,
    "attempts": 5,
    "windowMs": 900000
  }
}
```

#### 7.2 Multiple User Support (Future)
```javascript
// users.json
{
  "users": [
    {
      "username": "admin",
      "passwordHash": "$2a$12$...",
      "permissions": ["read", "write", "admin"]
    }
  ]
}
```

#### 7.3 OAuth Integration (Future)
- Google OAuth for easy setup
- GitHub OAuth for developer workflows
- Integration with existing identity providers

### 8. Testing Strategy

#### 8.1 Backend Tests
- Authentication middleware functionality
- Session management
- Rate limiting effectiveness
- Password validation

#### 8.2 Frontend Tests
- Login form validation
- Authentication state management
- Redirect behavior
- Error handling

#### 8.3 Integration Tests
- End-to-end login flow
- Session persistence
- Logout functionality
- Protected route access

### 9. Migration Strategy

#### 9.1 Backward Compatibility
- Default to no authentication (existing behavior)
- Opt-in via configuration
- Clear migration documentation

#### 9.2 Upgrade Path
1. Update dependencies
2. Set environment variables
3. Restart dashboard server
4. Test login functionality

### 10. Documentation Requirements

#### 10.1 User Documentation
- Setup instructions
- Password configuration
- Troubleshooting guide
- Security best practices

#### 10.2 Developer Documentation
- API authentication endpoints
- Frontend integration patterns
- Configuration options
- Extension points for custom auth

## Implementation Priority

### Phase 1: Basic Protection
1. Simple password hash authentication
2. Session-based auth
3. Login component
4. Basic rate limiting

### Phase 2: Enhanced Security
1. Improved session management
2. CSRF protection
3. Secure cookie configuration
4. Comprehensive rate limiting

### Phase 3: Advanced Features
1. Multiple authentication methods
2. User management interface
3. Audit logging
4. Advanced security headers

## Estimated Effort
- **Phase 1**: 1-2 days development + testing
- **Phase 2**: 1 day additional security hardening
- **Phase 3**: 2-3 days for advanced features

This feature would significantly enhance the security of Like-I-Said v2 while maintaining the simplicity and ease of use that makes it valuable for memory management.