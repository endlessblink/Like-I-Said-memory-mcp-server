---
id: 17507558479339bnu1iye6
timestamp: 2025-06-24T09:04:07.933Z
complexity: 4
category: work
project: bina-bekitzur-site
tags: ["github-integration","mcp-server","dynamic-content","ai-tools","repository-cards","title:Github Dynamic Integration Mcp Server Setup Session","summary:Completed GitHub Integration System"]
priority: high
status: active
access_count: 0
last_accessed: 2025-06-24T09:04:07.933Z
metadata:
  content_type: text
  size: 4950
  mermaid_diagram: false
---
# GitHub Dynamic Integration & MCP Server Setup - Session Summary

## Completed GitHub Integration System

### 1. GitHub API Service (`src/lib/github.ts`)
- **Dynamic Repository Fetching**: Auto-fetches user's public repositories from GitHub API
- **AI Enhancement**: Automatically detects AI-related projects and adds enhanced metadata
- **Smart Categorization**: Categorizes repos as AI Memory, AI Tools, Chatbots, etc.
- **Technology Detection**: Extracts programming languages and tech stack
- **Cover Image System**: 
- Started implementing README image extraction (IN PROGRESS)
- Falls back to beautiful generated gradient covers
- **Caching**: 10-minute cache with 30-minute retention
- **Curated Repository List**: 
  ```typescript
private readonly FEATURED_REPOS: string[] = [
    'bina-bekitzur',
    'Like-I-Said-memory-mcp-server',
    'Claude-Code-Tools'
  ];
```

### 2. Dynamic Repository Cards (`src/components/cards/GitHubProjectCard.tsx`)
- **Rich UI Components**: Beautiful cards with gradients, badges, and hover effects
- **AI Project Badges**: Special highlighting for AI-related repositories
- **Technology Tags**: Displays programming languages and frameworks
- **Statistics**: Shows stars, forks, last update dates
- **Fallback Covers**: Generates beautiful gradient covers when images unavailable
- **Responsive Design**: Works on all screen sizes

### 3. Data Management (`src/data/hooks/useGitHubRepositories.ts`)
- **React Query Integration**: Efficient data fetching with caching
- **Auto-refresh**: Updates every 15 minutes automatically
- **Filtering & Search**: Filter by AI projects, languages, search terms
- **Error Handling**: Falls back to mock data if GitHub API fails
- **Statistics**: Provides repo counts, AI project percentages, language stats

### 4. Integration Points
- **Portfolio Page**: `/portfolio` - Added GitHub section alongside videos
- **Code Projects Page**: `/portfolio/code` - Replaced old hard-coded card with dynamic system
- **Mock Data**: Created fallback data for development (`src/data/mock/githubRepositories.ts`)

## MCP Server for Site Management

### Installation & Setup
**Location**: `/mcp-servers/site-management/`
**Status**: ✅ Installed and configured in Claude Code

**Added to Claude Code**:
```bash
claude mcp add site-management "node \"/path/to/server.js\""
```

**Dependencies Installed**:
- @anthropic-ai/sdk
- @modelcontextprotocol/sdk
- contentful & contentful-management
- dotenv, fs-extra, glob, yaml, zod

### Available Tools

#### Content Management
- `add_ai_tool` - Add new AI tools to Contentful
- `update_ai_tool` - Update existing tools
- `delete_ai_tool` - Remove tools
- `add_ai_term` - Add AI terminology
- `create_category_page` - Create dynamic categories

#### Site Management
- `update_seo_config` - Update meta tags, domains, OpenGraph
- `update_site_config` - Global site settings
- `validate_content` - Quality assurance checks
- `backup_content` - Create content backups
- `sync_github_projects` - Refresh GitHub data

#### Available Resources
- `contentful://tools` - All AI tools from Contentful
- `contentful://terms` - All AI terms
- `contentful://categories` - All categories
- `file://site-config` - Site configuration
- `file://seo-config` - SEO settings
- `file://mock-data` - Development data

## Current Status & Issues Fixed

### ✅ Completed
- GitHub API integration with real repository data
- Dynamic repository cards with AI enhancement
- Curated repository filtering (only shows 3 selected repos)
- MCP server fully installed and functional
- Replaced old hard-coded project card
- Fixed TypeScript build errors
- Production deployment assets created

### 🔄 In Progress (Stopped Mid-Implementation)
- **README Image Extraction**: Started implementing system to pull first image from repository README files as cover images
- **File Modified**: `src/lib/github.ts` - Added `fetchRepositoryReadme()` and `extractImageFromReadme()` methods
- **Status**: Functions created but not yet integrated into the processing pipeline

### Repository Display Status
Currently showing 3 curated repositories:
1. **bina-bekitzur** - Main website project
2. **Like-I-Said-memory-mcp-server** - MCP memory server
3. **Claude-Code-Tools** - Claude development tools

## Domain Discussion
- Discussed using `ai-liftoff.click` for multilingual content
- Identified potential conflict with DreamHost's "Liftoff" AI website builder
- Decision postponed pending further consideration

## Key Files & Locations
- **GitHub Service**: `src/lib/github.ts`
- **Repository Cards**: `src/components/cards/GitHubProjectCard.tsx`
- **Data Hooks**: `src/data/hooks/useGitHubRepositories.ts`
- **GitHub Section**: `src/components/sections/GitHubProjectsSection.tsx`
- **Portfolio Pages**: `src/pages/Portfolio.tsx`, `src/pages/portfolio/CodeProjects.tsx`
- **MCP Server**: `mcp-servers/site-management/server.js`
- **Mock Data**: `src/data/mock/githubRepositories.ts`