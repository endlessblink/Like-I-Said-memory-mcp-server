---
id: 1752572655029carjtfzeu
timestamp: 2025-07-15T09:44:15.029Z
complexity: 4
category: work
project: comfyui-troubleshooting
tags: ["troubleshooting", "comfyui", "flux", "pytorch", "huggingface", "installation", "session-capture", "title:ComfyUI FLUX Installation Troubleshooting Session", "summary:ComfyUI FLUX Installation Troubleshooting Session"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T09:44:15.029Z
metadata:
  content_type: code
  size: 2740
  mermaid_diagram: false
---## ComfyUI FLUX Installation Troubleshooting Session

### Session Overview
**Started**: ~2025-07-15 (ongoing)
**Issue**: Multiple ComfyUI FLUX model installation problems
**Status**: In progress, needs systematic resolution

### Problems Identified

#### 1. PyTorch Version Conflicts
- **Current**: PyTorch 2.5.1+cu121 
- **Issue**: xformers built for PyTorch 2.1.2+cu121
- **Error**: "xformers can't load C++/CUDA extensions"
- **Impact**: Memory-efficient attention unavailable

#### 2. HuggingFace Authentication Issues  
- **Error**: "401 Unauthorized" when downloading models
- **Affected**: ae.safetensors from black-forest-labs/FLUX.1-schnell
- **Cause**: Invalid or expired HuggingFace token
- **Requirements**: Need access to gated repositories

#### 3. Missing Model Repositories
- **Error**: "404 Repository Not Found" for nunchaku-ai models
- **Affected**: FLUX Kontext models, various quantized versions
- **Cause**: Repositories may be private, deleted, or renamed

#### 4. CUDA/GPU Setup
- **Hardware**: RTX 4070 Ti (12GB VRAM)
- **CUDA**: Version 12.1
- **Status**: Properly detected but dependency conflicts

### Environment Details
- **Path**: D:\\MY PROJECTS\\AI\\STABLE DIFFUSION UI\\Stable Diffusion Venv_5
- **Python**: 3.10.16 (Anaconda)
- **GPU Memory**: 12,282 MB total VRAM, 81,661 MB RAM

### Proposed Solutions

#### Phase 1: Dependency Resolution
```bash
# Fix PyTorch/xformers compatibility
pip install torch==2.4.0+cu121 torchvision==0.19.0+cu121 torchaudio==2.4.0+cu121 --index-url https://download.pytorch.org/whl/cu121 --force-reinstall
pip install xformers==0.0.27.post2
```

#### Phase 2: Authentication Fix
```bash
# Get new HuggingFace token with proper permissions
huggingface-cli logout
huggingface-cli login
# Accept FLUX license at https://huggingface.co/black-forest-labs/FLUX.1-dev
```

#### Phase 3: Alternative Model Sources
```bash
# Use alternative VAE
curl -L "https://huggingface.co/madebyollin/sdxl-vae-fp16-fix/resolve/main/sdxl_vae.safetensors" -o "ae.safetensors"
# Try community quantized models
huggingface-cli download Kijai/flux-fp8 flux1-dev-fp8.safetensors
```

### Current Status
- Problems identified and documented
- Solutions proposed but not yet implemented
- Need to execute fixes systematically
- Should verify each step before proceeding

### Next Steps
1. Back up current environment state
2. Fix PyTorch/xformers compatibility first
3. Resolve HuggingFace authentication
4. Download alternative models
5. Test ComfyUI startup with new configuration

### Learning Points
- Always check dependency compatibility before upgrading
- Keep HuggingFace tokens up to date
- Have backup model sources for critical components
- Document working configurations for future reference