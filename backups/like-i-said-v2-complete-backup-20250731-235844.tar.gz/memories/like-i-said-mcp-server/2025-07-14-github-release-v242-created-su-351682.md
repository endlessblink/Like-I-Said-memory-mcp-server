---
id: 1752494351675zvjgo3koo
timestamp: 2025-07-14T11:59:11.675Z
complexity: 4
category: work
project: like-i-said-mcp-server
tags: ["github", "release", "v2.4.2", "dxt", "fix", "published", "title:Status: RELEASE PUBLISHED ✅", "summary:GitHub Release v2.4.2 Created Successfully"]
priority: high
status: active
related_memories: ["1752494273860tzt1zqics"]
access_count: 0
last_accessed: 2025-07-14T11:59:11.675Z
metadata:
  content_type: text
  size: 1312
  mermaid_diagram: false
---GitHub Release v2.4.2 Created Successfully

# Status: RELEASE PUBLISHED ✅

## Release Details
- **Version**: v2.4.2
- **Title**: 🔧 v2.4.2 - DXT Installation Fix
- **URL**: https://github.com/endlessblink/Like-I-Said-memory-mcp-server/releases/tag/v2.4.2
- **Asset**: like-i-said-memory-v2.dxt (included)

## What's in This Release
1. **Fixed DXT Installation Error** - Resolved "Invalid manifest: user_config: Required, Required, Required"
2. **Updated DXT Package** - Rebuilt with proper manifest validation
3. **Enhanced Documentation** - Clear distinction between Claude Desktop and Claude Code installation
4. **Version Bump** - All components updated to v2.4.2

## Release Notes Highlights
- ✅ Bug fix for DXT manifest validation error
- ✅ Documentation improvements with client type distinction
- ✅ Updated README.md with comparison table
- ✅ Technical details explaining the fix

## Impact
- Users experiencing DXT installation issues can now download v2.4.2
- Fixed DXT file is immediately available for download from the release
- No breaking changes for existing users
- Clear guidance on which installation method to use

## Next Steps
- Users should download the new DXT file from the release
- The fix is now publicly available and documented
- Issue should be resolved for all Claude Desktop users