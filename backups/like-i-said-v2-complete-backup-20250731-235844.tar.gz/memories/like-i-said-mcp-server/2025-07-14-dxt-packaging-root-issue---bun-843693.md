---
id: 17524968436864jkhmce7f
timestamp: 2025-07-14T12:40:43.686Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["dxt", "bundling", "esbuild", "solution", "packaging", "title:Critical Discovery: DXT Packaging Best Practices", "summary:DXT Packaging Root Issue - Bundle Dependencies, Don't Include nodemodules"]
priority: urgent
status: active
related_memories: ["1752496204364h3rh6qmek"]
access_count: 0
last_accessed: 2025-07-14T12:40:43.686Z
metadata:
  content_type: code
  size: 1620
  mermaid_diagram: false
---DXT Packaging Root Issue - Bundle Dependencies, Don't Include node_modules

# Critical Discovery: DXT Packaging Best Practices

## Root Cause Revealed
The research shows that **DXT packages should NOT include node_modules directories**. Instead, they should bundle all dependencies into single files using tools like esbuild, webpack, or ncc.

## Why node_modules Approach Fails
1. **Platform Path Issues**: Windows vs Linux path resolution problems
2. **Size Overhead**: Huge packages with unnecessary files
3. **Dependency Conflicts**: Complex dependency trees cause issues
4. **Security Vulnerabilities**: Bundled npm packages create attack vectors

## Recommended Solution: esbuild Bundling
Instead of packaging node_modules, bundle all dependencies into a single file:

```bash
# Install esbuild
npm install -g esbuild

# Bundle server with all dependencies
esbuild server-markdown.js --bundle --platform=node --outfile=dist/server-bundled.js --external:fs --external:path --external:os
```

## Alternative Tools
1. **esbuild**: 10-100x faster, best for Node.js
2. **@vercel/ncc**: Zero-config bundling, very reliable
3. **webpack**: Best compatibility with complex dependencies
4. **pkg**: Creates standalone executables

## Benefits of Bundling
- ✅ No node_modules directory needed
- ✅ Single file deployment  
- ✅ Faster installation
- ✅ Cross-platform compatibility
- ✅ Smaller package sizes
- ✅ No dependency version conflicts

## Next Steps
1. Create bundled version of server using esbuild
2. Update DXT build script to use bundled server
3. Remove node_modules packaging entirely
4. Test bundled DXT package