---
id: 1752495260099t2hyozpi0
timestamp: 2025-07-14T12:14:20.099Z
complexity: 4
category: code
project: like-i-said-mcp-server
tags: ["dxt", "manifest", "validation", "fix", "completed", "user_config", "title-fields", "title:DXT Manifest Validation Fix Applied", "summary:Root Cause Identified"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T12:14:20.099Z
metadata:
  content_type: code
  size: 1968
  mermaid_diagram: false
---## DXT Manifest Validation Fix Applied

### Root Cause Identified
The DXT manifest validation error "user_config: Required, Required, Required" was caused by **missing "title" fields** in the user_config section. The DXT specification requires each user_config field to have a "title" property for UI display.

### Solution Applied
1. **Added "title" fields** to all user_config entries in:
   - `build-dxt-production.js` (production DXT builder)
   - `build-dxt-simple.cjs` (simple DXT builder)
   - Root `manifest.json` already had correct structure

2. **Changed directory field types** from "string" to "directory" for proper DXT handling:
   - `memory_directory` → type: "directory"
   - `task_directory` → type: "directory"

### Updated User Config Structure
```json
"user_config": {
  "memory_directory": {
    "type": "directory",
    "title": "Memory Directory",
    "default": "~/Documents/claude-memories",
    "description": "Directory for storing memory files",
    "required": false
  },
  "task_directory": {
    "type": "directory", 
    "title": "Task Directory",
    "default": "~/Documents/claude-tasks",
    "description": "Directory for storing task files",
    "required": false
  },
  "default_project": {
    "type": "string",
    "title": "Default Project",
    "default": "my-project",
    "description": "Default project name",
    "required": false
  }
}
```

### DXT Packages Rebuilt
- ✅ **Production DXT**: `/dist-dxt-production/like-i-said-memory-v2.dxt` (0.15 MB) - Full 23 tools
- ✅ **Simple DXT**: `/dist-dxt/like-i-said-memory-v2.dxt` (3 KB) - Basic 11 tools

### Key Changes Made
1. **Title fields added** to all user_config entries
2. **Directory types corrected** for proper file selection UI
3. **Both build scripts updated** to generate correct manifests
4. **Packages rebuilt** with validated manifests

This should resolve the "Extension Preview Failed" validation error that was preventing DXT installation in Claude Desktop.