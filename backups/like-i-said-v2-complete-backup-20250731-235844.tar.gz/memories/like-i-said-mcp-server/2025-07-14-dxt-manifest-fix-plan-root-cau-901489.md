---
id: 1752489901484ybhbfn36p
timestamp: 2025-07-14T10:45:01.484Z
complexity: 4
category: code
project: like-i-said-mcp-server
tags: ["dxt", "manifest", "fix-plan", "testing", "title:Root Cause", "summary:The DXT manifest specification requires a required boolean field for each userconfig item", "but our manifests are missing this field."]
priority: high
status: active
related_memories: ["1752489815878qe5vheoe2"]
access_count: 0
last_accessed: 2025-07-14T10:45:01.484Z
metadata:
  content_type: code
  size: 1103
  mermaid_diagram: false
---DXT Manifest Fix Plan

# Root Cause
The DXT manifest specification requires a "required" boolean field for each user_config item, but our manifests are missing this field.

# Fix Implementation
Need to add "required": false to all user_config items since they all have defaults:
- memory_directory
- task_directory  
- default_project
- enable_auto_linking
- max_search_results
- enable_ollama
- ollama_model

# Files to Update
1. `/manifest.json` - Root manifest
2. `/build-dxt-simple.cjs` - Simple build script
3. `/build-dxt-production.js` - Production build script

# User's Testing Question
User asked: "If I remove the mcp from claude desktop and try to reinstall it, will it mess anything with the mcp or the dashboard?"

Answer: No, removing and reinstalling the MCP from Claude Desktop will NOT affect:
- The MCP server code itself
- The dashboard functionality
- Any stored memories or tasks
- The React dashboard

The MCP installation in Claude Desktop only creates a configuration entry pointing to the server. Removing it just removes that config entry, not the actual server files or data.