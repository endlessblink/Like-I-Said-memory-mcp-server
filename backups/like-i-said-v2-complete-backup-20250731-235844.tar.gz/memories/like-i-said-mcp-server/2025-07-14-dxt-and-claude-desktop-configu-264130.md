---
id: 1752490264124lbyqbdh0l
timestamp: 2025-07-14T10:51:04.124Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["dxt", "claude-desktop", "claude-code", "configuration", "clarification", "title:Important Distinction: Claude Desktop vs Claude Code", "summary:DXT and Claude Desktop Configuration Clarification"]
priority: high
status: active
related_memories: ["1752490163037onq5zoqo2"]
access_count: 0
last_accessed: 2025-07-14T10:51:04.124Z
metadata:
  content_type: text
  size: 1317
  mermaid_diagram: false
---DXT and Claude Desktop Configuration Clarification

# Important Distinction: Claude Desktop vs Claude Code

## DXT Files Work With:
- **Claude Desktop** (the desktop app) - YES, DXT automatically configures this
- **Claude Code** (claude.ai/code web interface) - NO, DXT does not configure this

## What DXT Configures:
When installed in Claude Desktop app:
1. Automatically adds MCP server configuration to Claude Desktop's config
2. Creates the server entry in Claude Desktop settings
3. Sets up the connection between Claude Desktop and the MCP server
4. No manual JSON configuration needed by the user

## What DXT Does NOT Configure:
- Does NOT set up anything for Claude Code (web interface)
- Claude Code users must still manually configure their MCP clients:
  - Cursor: ~/.cursor/mcp.json
  - Windsurf: ~/.codeium/windsurf/mcp_config.json
  - VS Code with Continue: manual setup

## Key Point:
DXT is specifically a Claude Desktop Extension format. It's designed to make MCP server installation easy for Claude Desktop app users. Web-based Claude Code users and other IDE users still need manual configuration.

## Current User Base:
- Claude Desktop users: Can use DXT for one-click install
- Claude Code users: Need manual MCP client configuration
- Other IDE users: Need manual configuration per their IDE