---
id: 1752495132561vwl3ojjn2
timestamp: 2025-07-14T12:12:12.561Z
complexity: 4
category: code
project: like-i-said-mcp-server
tags: ["dxt", "manifest", "validation", "user_config", "debugging", "title:DXT Manifest Validation Analysis", "summary:DXT Manifest Validation Analysis"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T12:12:12.561Z
metadata:
  content_type: text
  size: 1383
  mermaid_diagram: false
---## DXT Manifest Validation Analysis

### Current Error
"Extension Preview Failed: Invalid manifest: user_config: Required, Required, Required"

### Analysis
The error suggests that 3 fields in user_config are missing some required property. Looking at the current manifest:

1. **memory_directory**: has type, default, description, required
2. **task_directory**: has type, default, description, required  
3. **default_project**: has type, default, description, required
4. **enable_auto_linking**: has type, default, description, required
5. **max_search_results**: has type, default, description, required
6. **enable_ollama**: has type, default, description, required
7. **ollama_model**: has type, default, description, required

All fields have the required properties, but the error persists.

### Potential Issues
1. **Missing "title" field**: Based on web search, DXT user_config might require a "title" field for UI display
2. **Directory type validation**: Directory fields might need type "directory" instead of "string"
3. **Sensitive field handling**: API keys might need "sensitive": true
4. **Multiple directory support**: Directory fields might need "multiple": true

### Next Steps
1. Add "title" field to all user_config items
2. Change directory fields to type "directory"
3. Test with minimal user_config to isolate the issue
4. Compare with working DXT examples