---
id: 1752489815878qe5vheoe2
timestamp: 2025-07-14T10:43:35.878Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["dxt", "installation", "error", "manifest", "title:Issue", "summary:Users friend encountered error when installing DXT file:"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T10:43:35.878Z
metadata:
  content_type: text
  size: 1183
  mermaid_diagram: false
---DXT Installation Error Investigation

# Issue
User's friend encountered error when installing DXT file:
- Error: "Extension Preview Failed"
- Message: "Invalid manifest: user_config: Required, Required, Required"

# Research Findings

## DXT Files Found
1. `dist-dxt/like-i-said-memory-v2.dxt` (3KB) - Basic version
2. `dist-dxt-production/like-i-said-memory-v2.dxt` (1.2MB) - Production version

## Manifest Structure Analysis
All manifest.json files have proper `user_config` structure with:
- type (string/boolean/number)
- default (value)
- description (text)

## Build Scripts
- `build-dxt-simple.cjs` - Creates basic DXT
- `build-dxt-production.js` - Creates production DXT with all 23 tools

## Key Observations
1. The error message format suggests the manifest validator is expecting certain fields to be marked as "required"
2. Current manifests don't have a "required" field in user_config items
3. The error shows "Required" three times, suggesting 3 fields are missing required status

## Potential Root Cause
The DXT manifest specification might require a "required" boolean field for each user_config item to indicate whether the configuration is mandatory or optional.