---
id: 175293079884183nrde97p
timestamp: 2025-07-19T13:13:18.841Z
complexity: 4
category: code
project: like-i-said-mcp-server
tags: ["npx", "installation", "claude-code", "wsl", "windows", "mcp", "title:Command Mcp Add Npx Fails Because", "summary:NPX installation issue with like-i-said-memory-mcp-v2 on Windows WSL for Claude Code. The command claude mcp add like-i-said-memory-mcp-v2 -- npx -..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-19T13:13:18.841Z
metadata:
  content_type: text
  size: 740
  mermaid_diagram: false
---NPX installation issue with like-i-said-memory-mcp-v2 on Windows WSL for Claude Code.

The command `claude mcp add like-i-said-memory-mcp-v2 -- npx -y like-i-said-memory-mcp-v2` fails because:

1. The package name is incorrect - should be `@endlessblink/like-i-said-v2`
2. The correct NPX command format is: `npx -p @endlessblink/like-i-said-v2 like-i-said-v2`

Correct installation commands:
- For Claude Code: `claude mcp add like-i-said-memory-v2 -- npx -p @endlessblink/like-i-said-v2@latest like-i-said-v2`
- Direct NPX: `npx -p @endlessblink/like-i-said-v2@latest like-i-said-v2 install`
- Alternative: Clone repo and use `node cli.js install`

The published NPM package is @endlessblink/like-i-said-v2, not like-i-said-memory-mcp-v2.