---
id: 1752498238143g8zi1ptzy
timestamp: 2025-07-14T13:03:58.143Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["dxt", "windows", "path-issue", "extraction", "enoent", "title:New Error File Exists Dxt Not Found After Extraction", "summary:DXT Path Resolution Issue on Windows"]
priority: urgent
status: active
access_count: 0
last_accessed: 2025-07-14T13:03:58.143Z
metadata:
  content_type: text
  size: 1156
  mermaid_diagram: false
---DXT Path Resolution Issue on Windows

# New Error Pattern: File Exists in DXT but Not Found After Extraction

## Error Details
`ENOENT: no such file or directory, open 'C:\Users\endle\AppData\Roaming\Claude\Claude Extensions\local.dxt.endlessblink.like-i-said-memory-v2\server\standalone-server.js'`

## Key Observations
1. The file IS in the DXT package (verified with unzip -l)
2. Claude Desktop is trying to run it (progress!)
3. But the file isn't found after extraction

## Possible Causes
1. **Extraction failure** - Files not being extracted properly on Windows
2. **Permission issues** - Windows security blocking file creation
3. **Path encoding** - Unix vs Windows path separators
4. **File attributes** - Missing executable permissions
5. **Antivirus** - Security software blocking extraction

## Diagnostic Information
- DXT is valid ZIP file
- Contains correct files at correct paths
- Error happens AFTER extraction attempt

## Hypothesis
Claude Desktop on Windows may have issues with:
- File extraction permissions
- Path resolution after extraction
- Security policies blocking script files
- Unicode or special character handling in paths