---
id: 1752498473468wzf7r5o14
timestamp: 2025-07-14T13:07:53.468Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["perplexity", "prompt", "dxt", "research", "troubleshooting", "title:Comprehensive Research Prompt", "summary:Perplexity Research Prompt for DXT Installation Issues"]
priority: urgent
status: active
access_count: 0
last_accessed: 2025-07-14T13:07:53.468Z
metadata:
  content_type: text
  size: 2701
  mermaid_diagram: false
---Perplexity Research Prompt for DXT Installation Issues

# Comprehensive Research Prompt

## Context
We're experiencing persistent installation failures with Claude Desktop Extension (DXT) packages on Windows. Despite multiple approaches and fixes, all DXT packages fail to install with various ENOENT errors.

## Research Questions

### 1. Claude Desktop DXT Installation Process
- How does Claude Desktop extract and install DXT files on Windows?
- What are the exact file path requirements for DXT packages on Windows?
- Are there known issues with DXT installation on Windows vs macOS/Linux?
- What security or permission requirements exist for DXT files on Windows?

### 2. ENOENT Error Patterns
We've seen these specific errors:
- `ENOENT: no such file or directory, open 'C:\Users\[user]\AppData\Roaming\Claude\Claude Extensions\local.dxt.endlessblink.like-i-said-memory-v2\server\node_modules'`
- `ENOENT: no such file or directory, open '...\server\lib'`
- `ENOENT: no such file or directory, open '...\server\standalone-server.js'`

What causes these ENOENT errors during DXT installation?

### 3. Working vs Non-Working DXT Analysis
- A Python-based DXT (comfy-guru) works perfectly
- All Node.js-based DXTs fail with ENOENT errors
- What are the differences in how Claude Desktop handles Python vs Node.js DXT packages?

### 4. DXT Package Structure Requirements
- What is the exact required structure for Node.js DXT packages?
- Are there specific requirements for the manifest.json user_config section?
- How should dependencies be handled in Node.js DXT packages?
- Should node_modules be included, bundled, or self-installed?

### 5. Windows-Specific Issues
- Are there known path resolution issues with DXT on Windows?
- Do Windows security policies affect DXT extraction?
- Are there file permission requirements for DXT packages on Windows?
- Does Windows Defender or antivirus software interfere with DXT installation?

### 6. Alternative Solutions
- Are there successful examples of Node.js DXT packages that work on Windows?
- What bundling or packaging strategies work for Node.js DXT packages?
- Should we consider converting to Python like the working example?
- Are there debugging tools or logs for DXT installation failures?

## Additional Context
- Working example: comfy-guru.dxt (Python, no user_config, self-installing dependencies)
- Failed attempts: Various Node.js packages with different approaches (bundled, node_modules included, self-installing)
- Environment: Windows 11, Claude Desktop latest version
- All packages work when manually configured but fail as DXT

Please provide comprehensive information about solving Node.js DXT installation issues on Windows.