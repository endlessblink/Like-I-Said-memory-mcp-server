---
id: 17524903426265b8uklm3m
timestamp: 2025-07-14T10:52:22.626Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["installation", "mcp", "cursor", "windsurf", "claude-code", "setup", "title:Installation Methods by Client Type", "summary:1. Claude Desktop (Desktop App)"]
priority: high
status: active
related_memories: ["1752490264124lbyqbdh0l"]
access_count: 0
last_accessed: 2025-07-14T10:52:22.626Z
metadata:
  content_type: code
  size: 1516
  mermaid_diagram: false
---MCP Installation Methods for Different Clients

# Installation Methods by Client Type

## 1. Claude Desktop (Desktop App)
- **Method**: DXT file (one-click install)
- **Process**: Download .dxt file → Open in Claude Desktop → Configure → Done
- **Status**: Currently broken due to manifest issue we're fixing

## 2. Claude Code + Cursor
- **Method**: Manual configuration
- **Process**:
  1. Clone/install the MCP server locally
  2. Edit ~/.cursor/mcp.json
  3. Add server configuration pointing to local installation
  ```json
  {
    "mcpServers": {
      "like-i-said-memory-v2": {
        "command": "node",
        "args": ["/path/to/server-markdown.js"]
      }
    }
  }
  ```

## 3. Claude Code + Windsurf
- **Method**: Manual configuration
- **Process**:
  1. Clone/install the MCP server locally
  2. Edit ~/.codeium/windsurf/mcp_config.json
  3. Add server configuration
  ```json
  {
    "mcp": {
      "servers": {
        "like-i-said-memory-v2": {
          "command": "node",
          "args": ["/path/to/server-markdown.js"]
        }
      }
    }
  }
  ```

## 4. Installation Options for Manual Setup
- **NPX (Recommended)**: `npx -p @endlessblink/like-i-said-v2 like-i-said-v2 install`
- **NPM Global**: `npm install -g @endlessblink/like-i-said-v2`
- **Git Clone**: Clone repo → npm install → node cli.js install

## Key Point
DXT is ONLY for Claude Desktop app. All other clients (Cursor, Windsurf, VS Code) require manual MCP configuration regardless of how you use Claude (Code or Desktop).