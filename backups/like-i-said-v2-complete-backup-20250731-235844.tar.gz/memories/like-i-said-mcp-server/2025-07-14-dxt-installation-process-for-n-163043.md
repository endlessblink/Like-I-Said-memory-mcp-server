---
id: 1752490163037onq5zoqo2
timestamp: 2025-07-14T10:49:23.037Z
complexity: 4
category: research
project: like-i-said-mcp-server
tags: ["dxt", "installation", "deployment", "user-experience", "title:What Happens When Someone Installs Dxt File Without", "summary:DXT Installation Process for New Users"]
priority: high
status: active
related_memories: ["1752489815878qe5vheoe2", "1752489901484ybhbfn36p"]
access_count: 0
last_accessed: 2025-07-14T10:49:23.037Z
metadata:
  content_type: text
  size: 1567
  mermaid_diagram: false
---DXT Installation Process for New Users

# What Happens When Someone Installs a DXT File Without Having the MCP/Server

## DXT Package Contents
The DXT file is a self-contained package that includes:
1. The MCP server code (embedded in the package)
2. All necessary library files
3. Default directory structures
4. Manifest configuration

## Installation Process
When someone installs a DXT file in Claude Desktop:

1. **Claude Desktop extracts the DXT package** to a local directory (usually in the user's app data folder)
2. **All server files are copied** from the DXT to the installation location
3. **User configuration prompts** appear based on manifest.json user_config
4. **Claude Desktop creates the MCP configuration** pointing to the extracted server
5. **The server runs from the extracted location** when Claude Desktop starts

## Key Points
- Users DO NOT need to have the MCP server pre-installed
- They DO NOT need Node.js or npm installed (Claude Desktop handles Node runtime)
- The DXT is completely self-contained
- All dependencies are bundled in the production DXT

## Production vs Development
- **Production DXT (1.2MB)**: Contains all code, libraries, and dependencies
- **Simple DXT (3KB)**: Contains minimal mock server (for testing)
- Our production DXT includes the full server implementation

## Data Storage
After installation:
- Memories stored in: `~/Documents/claude-memories/` (or user-configured path)
- Tasks stored in: `~/Documents/claude-tasks/` (or user-configured path)
- These directories are created automatically on first use