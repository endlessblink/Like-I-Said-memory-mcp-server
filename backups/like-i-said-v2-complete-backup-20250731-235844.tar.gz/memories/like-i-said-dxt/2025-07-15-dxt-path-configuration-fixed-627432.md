---
id: 1752596627420qsw9veq1m
timestamp: 2025-07-15T16:23:47.420Z
complexity: 4
category: code
project: like-i-said-dxt
tags: ["dxt", "configuration", "persistence", "paths", "fix", "title:Summary", "summary:Fixed the Like-I-Said DXT package to support persistent path configuration across all sessions, allowing users to set custom memory and task direct..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T16:23:47.420Z
metadata:
  content_type: code
  size: 1420
  mermaid_diagram: false
---DXT Path Configuration Fixed - Persistent Storage Solution

## Summary
Fixed the Like-I-Said DXT package to support persistent path configuration across all sessions, allowing users to set custom memory and task directories.

## Key Changes
1. **Enhanced set_paths tool**: Now saves configuration persistently by default
2. **Multiple config locations**: Checks for dxt-config.json in multiple locations:
   - Current working directory
   - DXT installation directory  
   - ~/Documents/claude-dxt-config.json
3. **Auto-reload**: Automatically reloads memory index when paths are changed
4. **Backwards compatibility**: Still supports temporary path changes if persistent=false

## Technical Details
- Updated getConfiguredPath() to check multiple config file locations
- set_paths tool now writes to dxt-config.json for persistence
- Added memory count display when reloading from new path
- Configuration is saved to multiple locations for redundancy

## Usage
The user can now use set_paths to permanently change directories:
```
set_paths(memory_directory="D:\\APPSNospaces\\like-i-said-mcp-server-v2\\memories", 
          task_directory="D:\\APPSNospaces\\like-i-said-mcp-server-v2\\tasks")
```

This will save the configuration and apply to all future Claude Desktop sessions.

## File Updated
/home/endlessblink/projects/like-i-said-mcp-server-v2/temp-dxt/like-i-said-memory-v2-fixed.dxt (built with these fixes)