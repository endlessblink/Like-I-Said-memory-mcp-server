---
id: 17525967754358il42v92l
timestamp: 2025-07-15T16:26:15.435Z
complexity: 4
category: research
project: like-i-said-dxt
tags: ["dxt", "configuration", "research", "best-practices", "environment-variables", "title:Key Findings", "summary:1. How userconfig Should Work"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T16:26:15.435Z
metadata:
  content_type: text
  size: 1921
  mermaid_diagram: false
---DXT Configuration Research - Best Practices and Known Issues

## Key Findings

### 1. How user_config Should Work
- DXT extensions declare user configuration in manifest.json under "user_config" section
- Claude Desktop automatically generates UI for these configurations
- Values are stored securely (OS keychain for sensitive data)
- Accessed via `${user_config.variable_name}` in manifest

### 2. Known Issues with Environment Variables
- **Windows Issue**: Environment variables like `${APPDATA}` sometimes aren't expanded properly
- **user_config expansion**: There are reports that `${user_config.x}` variables may not always expand correctly
- This matches our debug output showing: `user_config_memory_directory: "not set"`

### 3. Alternative Approaches That Work
Instead of relying solely on `${user_config.x}` environment variables:

a) **Config File Approach** (Our Implementation):
   - Use a dxt-config.json file in multiple locations
   - Check for config at runtime in the server code
   - This is more reliable than environment variable expansion

b) **Command Line Arguments**:
   - Pass configuration as args instead of env variables
   - More reliable across platforms

c) **Direct Path Configuration**:
   - Allow runtime configuration through tools (our set_paths implementation)
   - Save to persistent config file

### 4. Best Practices
1. Don't rely solely on environment variable expansion
2. Implement fallback mechanisms
3. Check multiple config locations
4. Provide runtime configuration tools
5. Use absolute paths when possible

### 5. Our Implementation is Correct
Our approach of:
- Checking multiple config file locations
- Providing a set_paths tool for runtime configuration
- Saving to dxt-config.json for persistence
- Not relying solely on `${user_config.x}` expansion

Is actually MORE robust than relying on Claude Desktop's environment variable expansion, which has known issues.