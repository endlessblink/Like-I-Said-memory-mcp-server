---
id: 1750430777059vsohjx111
timestamp: 2025-06-20T14:46:17.059Z
complexity: 4
category: work
project: like-i-said-v2
tags: ["mcp","backup","perplexity","troubleshooting","stdio","process-isolation"]
priority: high
status: active
---
## Perplexity Prompt for MCP + Backup System Fix

**Problem Statement:**
I need help fixing MCP server compatibility issues with a real-time backup system in Node.js. The backup system causes "process exited" errors in Claude Desktop and connection failures in Cursor, though Windsurf works fine.

**Technical Stack:**
- MCP server using @modelcontextprotocol/sdk v0.5.0 with StdioServerTransport
- Backup system using chokidar for real-time file watching  
- Node.js v20.19.2 with ES modules
- Running in WSL2 Ubuntu environment

**Current Implementation Issues:**

My MCP server tries to start the backup system after connection:
```javascript
// Current approach - causes stdio interference
setTimeout(() => {
  const backupProcess = spawn('node', [path.join(__dirname, 'backup-system.js')], {
    detached: true,
    stdio: ['ignore', 'ignore', 'ignore'], // Still causes issues
    cwd: __dirname
  });
  backupProcess.unref();
}, 2000);
```

The backup system immediately starts watching files on import:
```javascript
// backup-system.js - this blocks MCP stdio
const watcher = chokidar.watch(MEMORIES_DIR, {
  persistent: true,
  ignoreInitial: false,
  awaitWriteFinish: { stabilityThreshold: 2000, pollInterval: 100 }
});
```

**Test Results:**
- Server WITHOUT backup: ✅ Works in all clients
- Server WITH backup: ❌ Claude Desktop and Cursor fail, ✅ Windsurf works
- Error patterns: "process exited" in Claude, "Cannot detect MCP server" in Cursor

**Client Configurations (all identical format):**
```json
{
  "mcpServers": {
    "like-i-said-memory-v2": {
      "command": "node",
      "args": ["/path/to/server-with-backup.js"],
      "cwd": "/path/to/project"
    }
  }
}
```

**Critical Requirements:**
1. Backup system MUST run automatically (not optional)
2. Real-time file watching is essential for data protection
3. Must work in ALL clients: Claude Desktop, Cursor, and Windsurf
4. Cannot interfere with stdio communication
5. WSL2 compatibility required
6. Production-ready solution (no manual startup)

**Key Questions:**
1. What's the best way to run a file watcher alongside an MCP server without stdio interference?
2. Why does Windsurf tolerate chokidar file watching while Claude/Cursor don't?
3. Should the backup run as a child process, worker thread, or completely separate process?
4. Are there WSL-specific considerations for process management with stdio servers?
5. How can I ensure clean stdio communication while maintaining real-time file monitoring?
6. What process isolation techniques work best for MCP servers?

**Environmental Context:**
- WSL2 Ubuntu with Node.js v20.19.2
- Multiple AI clients with different stdio tolerance levels
- Real-time memory backup system for enterprise data protection
- MCP server handles memory management with markdown files

Please provide a production-ready solution that maintains both MCP functionality and automatic backup protection across all AI clients.