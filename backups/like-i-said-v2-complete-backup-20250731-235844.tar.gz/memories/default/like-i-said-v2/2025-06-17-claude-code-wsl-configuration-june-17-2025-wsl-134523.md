---
id: 1750181134523
complexity: 2
category: research
project: like-i-said-v2
tags: ["wsl","claude-code","configuration","setup","june-2025"]
priority: medium
status: active
---
# CLAUDE CODE WSL CONFIGURATION (June 17, 2025) - WSL compatibility status - Server

CLAUDE CODE WSL CONFIGURATION (June 17, 2025): WSL compatibility status - Server works in WSL environment with Node.js + JSON file storage, uses WSL-native paths (/mnt/d/APPSNospaces/...), npm run dev:full working in WSL. Manual configuration steps: 1) Open VS Code in WSL, 2) Add MCP server config to ~/.vscode-server/data/User/settings.json with claude.mcpServers key, 3) Test server responds, 4) Restart VS Code. WSL-specific considerations: Windows paths (D:\) vs WSL paths (/mnt/d/), environment variables WSL_DISTRO_NAME and WSL_INTEROP, file I/O performance considerations.