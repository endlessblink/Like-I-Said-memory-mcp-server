---
id: 1750696545109xkgo0ilis
timestamp: 2025-06-23T16:35:45.109Z
complexity: 4
category: code
project: like-i-said-v2
tags: ["mcp","bug-fix","debugging","json-rpc","claude-desktop","windsurf","complete-session"]
priority: high
status: active
---
# MCP Server Loading Error - Complete Fix Session

## Problem Summary
The Like-I-Said MCP server v2 was failing to load in Claude Desktop and Windsurf with JSON parse error: "Unexpected token 'S', '[Startup Ch...' is not valid JSON"

## Investigation Process

### 1. Initial Error Discovery
- Error occurred when Claude/Windsurf tried to initialize the MCP server
- The error message indicated JSON parsing was failing on startup

### 2. Configuration Files Checked
- `/claude_desktop_config.json` - Found old path configuration
- `/mcp-config.json` - Correct configuration for like-i-said-memory-v2
- Both files had proper JSON syntax

### 3. Server Startup Analysis
- Examined `server-markdown.js` startup sequence
- Found multiple console.log/console.error statements outputting before JSON-RPC protocol
- Discovered startup validation messages were interfering with JSON-RPC communication

### 4. Root Cause Identified
The server was outputting these messages to stderr before JSON-RPC started:
```
.env file loaded successfully
🔧 Using environment variable path: /mnt/d/APPSNospaces/Like-I-said-mcp-server-v2/memories
🔧 Debug: Server at: /mnt/d/APPSNospaces/Like-I-said-mcp-server-v2
🔧 Debug: Final memories path: /mnt/d/APPSNospaces/Like-I-said-mcp-server-v2/memories
Like-I-Said Memory Server v2 - Markdown File Mode
Running startup validation of all memory files...
[Startup Check] Validation complete. All memory files appear to be valid.
[Auto-Sanitize] Initializing watcher for path: /mnt/d/APPSNospaces/Like-I-said-mcp-server-v2/memories
[Auto-Sanitize] File watcher is now running.
Like I Said Memory MCP Server v2 started successfully
```

## Files Modified

### 1. `/server-markdown.js`
- Line 90: Commented out `.env file loaded successfully`
- Lines 840, 847, 852: Commented out memory path debug messages
- Lines 861-862: Commented out server location debug messages
- Line 866: Commented out "Like-I-Said Memory Server v2" message
- Lines 1276-1307: Commented out startup validation console outputs
- Line 1320: Commented out validation error logging
- Line 1330: Commented out "started successfully" message

### 2. `/memory-sanitizer.js`
- Lines 16-20: Commented out periodic stats logging interval
- Line 53: Commented out backup error logging
- Line 76: Commented out auto-sanitized file notification
- Line 81: Commented out sanitization error logging
- Line 89: Commented out watcher initialization message
- Line 106: Commented out watcher error logging
- Line 110: Commented out "File watcher is now running" message

## Testing Results
Successfully tested with:
```bash
echo '{"jsonrpc": "2.0", "id": 1, "method": "tools/list"}' | node server-markdown.js
```

Server now returns clean JSON-RPC response without any preceding text.

## Key Learning
MCP servers must not output ANY text to stdout/stderr before the JSON-RPC protocol begins. All startup messages, debug logs, and status updates must be suppressed or redirected to avoid breaking the JSON parsing in MCP clients.