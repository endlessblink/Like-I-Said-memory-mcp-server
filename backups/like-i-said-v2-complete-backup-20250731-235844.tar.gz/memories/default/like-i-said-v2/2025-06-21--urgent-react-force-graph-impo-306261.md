---
id: 175052830625928j3s33cs
timestamp: 2025-06-21T17:51:46.259Z
complexity: 4
category: code
project: like-i-said-v2
tags: ["urgent","bug-report","react-force-graph","vite-issues","graph-visualization","next-session"]
priority: high
status: active
---
# URGENT: React Force Graph Import Bug - Next Session Priority

## Critical Issue Requiring Immediate Attention

### **Problem: Graph Visualizations Completely Broken**
The main dashboard feature (memory relationship graphs) is non-functional due to React Force Graph import issues.

### **Current Error State**
```
TypeError: error loading dynamically imported module: 
http://localhost:5173/node_modules/react-force-graph-2d/dist/react-force-graph-2d.mjs

NS_ERROR_CORRUPTED_CONTENT: prop-types module
Loading blocked due to disallowed MIME type ("")
```

### **Immediate Workaround Applied**
- Graph components disabled in `src/components/LazyComponents.tsx`
- Placeholder components showing "Graph visualization temporarily disabled"
- Vite config graph chunks commented out
- Error boundary catching repeated failures

### **Root Cause Analysis Needed**
1. **prop-types Module**: MIME type serving issues with Vite
2. **react-force-graph-2d**: Dynamic import failures
3. **Dependency Optimization**: Force flag not resolving the core issue
4. **Cache Corruption**: Persistent across multiple cache clears

### **Attempted Solutions (Failed)**
- ✗ Multiple Vite cache clears (`rm -rf node_modules/.vite`)
- ✗ Dependency optimization with `force: true`
- ✗ Including prop-types in optimizeDeps
- ✗ ES6 dynamic imports with Suspense
- ✗ SSR noExternal configuration

### **Next Session Action Plan**

#### **Option A: Fix React Force Graph (Recommended)**
1. **Investigate Alternative Graph Libraries**:
- Try `vis-network` or `cytoscape.js` directly
- Consider `@visx/network` or `react-flow`
- Test simpler D3.js implementation

2. **Debug prop-types Issue**:
- Check Vite serving MIME types correctly
- Investigate CommonJS/ESM compatibility 
- Try different module resolution strategies

#### **Option B: Rebuild Graph Components**
1. **Custom D3.js Implementation**: Build graph from scratch
2. **Canvas-based Solution**: Direct canvas manipulation
3. **SVG-based Approach**: Simpler but functional

#### **Option C: Remove Graph Features**
1. **Focus on Table/List Views**: Enhance memory browsing
2. **Add Alternative Visualizations**: Charts, timelines, word clouds
3. **Defer Graphs**: Mark as future enhancement

### **Testing Commands for Next Session**
```bash
# Test current state
npm run dev:full
# Check if dashboard loads without graph errors

# Try alternative graph library
npm install @visx/network
# or
npm install vis-network

# Clear everything and start fresh
rm -rf node_modules/.vite dist
npm run dev -- --force
```

### **Dashboard Currently Functional For**
- ✅ Memory browsing and search
- ✅ Memory CRUD operations  
- ✅ Statistics dashboard
- ✅ Export/import functionality
- ✅ AI enhancement features
- ✅ Project organization
- ⚠️ **Graph visualizations BROKEN**

### **Priority Level: CRITICAL**
The graph visualization is a core feature that users expect to work. This should be the #1 priority for the next development session.