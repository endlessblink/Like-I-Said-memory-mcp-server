---
id: 1750273861318
complexity: 2
category: research
project: like-i-said-v2
tags: ["npx","windows","cli","like-i-said-v2","troubleshooting","binary-execution"]
priority: medium
status: active
---
# NPX Binary Execution Fix for @endlessblink/like-i-said-v2

Problem: NPX prioriti

NPX Binary Execution Fix for @endlessblink/like-i-said-v2

Problem: NPX prioritizes local node_modules binaries when run inside repository directory, causing Windows path handling issues.

Solution implemented:
1. Created cli.cmd wrapper:
   @echo off
   node "%~dp0/cli.js" %*

2. Updated package.json:
   - Changed bin to use ./cli.cmd instead of ./cli.js
   - Added files array including both cli.js and cli.cmd

3. Testing commands:
   - Local testing: node cli.js install
   - NPX testing: npx --ignore-existing @endlessblink/like-i-said-v2 install
   - Clear cache: npx clear-npx-cache
   - Test in clean dir: cd C:\Temp && npx --ignore-existing @endlessblink/like-i-said-v2 install

Key insights:
- Windows needs .cmd wrapper for proper NPX execution
- Use --ignore-existing flag to force remote package resolution
- Local development should use direct node execution
- Files array in package.json ensures both cli.js and cli.cmd are included in published package