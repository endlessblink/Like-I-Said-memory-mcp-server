---
id: 17506965111034ljfkbqmm
timestamp: 2025-06-23T16:35:11.103Z
complexity: 4
category: code
project: like-i-said-v2
tags: ["mcp","bug-fix","json-rpc","claude-desktop","windsurf","startup"]
priority: high
status: active
---
# MCP Server Loading Fix - JSON Parse Error Resolution

## Problem
The Like-I-Said MCP server v2 was failing to load in Claude Desktop and Windsurf with the error "Unexpected token 'S', '[Startup Ch...' is not valid JSON". This was caused by the server outputting debug messages to stderr before the JSON-RPC protocol started.

## Root Cause
The server was outputting various startup messages like:
- ".env file loaded successfully"
- "[Startup Check] Validation complete..."
- "[Auto-Sanitize] Initializing watcher..."
- Debug path information

These messages were being sent to stderr before the JSON-RPC communication began, causing the MCP clients to fail when trying to parse the initial response.

## Solution
Commented out all console.log and console.error statements that were outputting during server startup:

1. In `server-markdown.js`:
- Commented out .env loading success message
- Commented out memory path debug messages
- Commented out startup validation messages
- Commented out server started successfully message

2. In `memory-sanitizer.js`:
- Commented out auto-sanitize initialization messages
- Commented out periodic stats logging
- Commented out file sanitization notifications
- Commented out error messages during file processing

## Result
The server now starts silently and immediately begins JSON-RPC communication, allowing it to load successfully in Claude Desktop and Windsurf.

## Testing
Verified the fix by running:
```bash
echo '{"jsonrpc": "2.0", "id": 1, "method": "tools/list"}' | node server-markdown.js
```

The server now returns clean JSON-RPC responses without any preceding text.