---
id: 1750696757490cgxoe2mlr
timestamp: 2025-06-23T16:39:17.490Z
complexity: 4
category: code
project: like-i-said-v2
tags: ["project-audit","maintenance","updates","testing","dependencies","action-plan"]
priority: high
status: active
---
# Project Audit Action Plan - Safe Implementation Strategy

## Overview
Based on the project audit report, here's a careful implementation plan to address the issues without breaking the existing functionality.

## Priority 1: Critical Updates (Do First)

### 1. Update MCP SDK (CRITICAL)
**Current**: v0.5.0 | **Target**: v1.13.1

**Safe Approach**:
1. Create a new branch: `git checkout -b update-mcp-sdk`
2. Test current functionality first
3. Update incrementally if possible
4. Check breaking changes in MCP SDK changelog
5. Update package.json: `"@modelcontextprotocol/sdk": "^1.13.1"`
6. Run `npm install`
7. Test all MCP tools thoroughly
8. Fix any API changes required

**Risk**: High - Major version jump may have breaking changes

## Priority 2: Version Alignment

### 1. Add .nvmrc File
```bash
echo "20.11.0" > .nvmrc
```
This matches the Docker Node version for consistency.

### 2. Fix Docker Version Mismatch
Update docker-compose.yml and Dockerfile to reference v2.3.5 instead of v2.3.2

## Priority 3: Cleanup Tasks

### 1. Update .gitignore
Add to .gitignore:
```
backup/
development-backups/
memory_backups/
*.backup
*.backup.*
```

### 2. Clean Git Status
```bash
git rm -r --cached backup/backup/
git rm -r --cached development-backups/
git add .gitignore
git commit -m "chore: Clean up backup directories and update gitignore"
```

## Priority 4: Testing Infrastructure

### 1. Add Test Framework (Vitest recommended for Vite projects)
```bash
npm install -D vitest @testing-library/react @testing-library/jest-dom jsdom
```

### 2. Create Basic Test Structure
```
tests/
├── unit/
│   ├── memory-sanitizer.test.js
│   └── server-markdown.test.js
└── integration/
    └── mcp-tools.test.js
```

### 3. Add Test Scripts to package.json
```json
"scripts": {
  "test": "vitest",
  "test:coverage": "vitest --coverage"
}
```

## Priority 5: Safe Dependency Updates

### Major Updates to Consider (Test Thoroughly):
- React 18 → 19 (wait for stable ecosystem)
- Express 4 → 5 (check middleware compatibility)
- Vite 4 → 6 (usually safe, good performance gains)

### Update Strategy:
1. Create separate branch for each major update
2. Update one dependency at a time
3. Run full test suite after each update
4. Check dashboard functionality manually
5. Test MCP server with Claude/Windsurf

## Implementation Order:

1. **Week 1**: 
- Add .nvmrc
- Fix Docker versions
- Clean up git/backup folders

2. **Week 2**:
- Update MCP SDK (most critical)
- Test thoroughly

3. **Week 3**:
- Setup test infrastructure
- Write basic tests for critical paths

4. **Week 4**:
- Update minor dependencies
- Consider Vite update

5. **Future**:
- Plan major updates (React 19, Express 5)
- Add CI/CD pipeline

## Testing Checklist After Each Change:
- [ ] MCP server starts without errors
- [ ] All MCP tools work in Claude/Windsurf
- [ ] Dashboard loads correctly
- [ ] Memory CRUD operations work
- [ ] Export/Import functionality works
- [ ] WebSocket real-time updates work
- [ ] Docker container builds and runs
- [ ] NPM package can be installed via npx

## Rollback Strategy:

Always maintain the ability to rollback:
1. Work in feature branches
2. Tag stable versions before major changes
3. Keep backups of working configurations
4. Document any configuration changes

## DO NOT:
- Update all dependencies at once
- Skip testing after updates
- Merge to main without thorough testing
- Update in production directly
- Remove features without user notice