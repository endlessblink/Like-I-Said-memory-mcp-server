---
id: 1750407154630jd2kbx1cq
timestamp: 2025-06-20T08:12:34.630Z
complexity: 4
category: code
tags: ["wsl", "browser-automation", "puppeteer", "playwright", "claude-code", "mcp", "xvfb", "troubleshooting"]
priority: high
status: active
access_count: 0
last_accessed: 2025-06-20T08:12:34.630Z
metadata:
  content_type: code
  size: 2415
  mermaid_diagram: false
---# WSL Browser Automation Fix: Puppeteer & Playwright MCP Setup

## Problem
When using Claude Code in WSL, both Puppeteer and Playwright MCP servers fail with these errors:
- **Puppeteer**: "Missing X server or $DISPLAY" / "Failed to launch the browser process!"
- **Playwright**: "Chromium distribution 'chrome' is not found at /opt/google/chrome/chrome"

## Root Causes
1. WSL lacks a graphical display server (X server) by default
2. Chrome/Chromium browser binaries not installed in WSL
3. `sudo` requires password, blocking automated package installation

## Complete Solution

### Step 1: Enable Passwordless Sudo
```bash
echo "$(whoami) ALL=(ALL) NOPASSWD:ALL" | sudo tee /etc/sudoers.d/$(whoami)
sudo chmod 0440 /etc/sudoers.d/$(whoami)
```

### Step 2: Install Xvfb (Virtual Display)
```bash
sudo apt-get update && sudo apt-get install -y xvfb
```

### Step 3: Install Chrome for Playwright
```bash
npx playwright install chrome
```

### Step 4: Reconfigure Puppeteer MCP with Xvfb Wrapper
```bash
# Remove current puppeteer MCP server
claude mcp remove puppeteer

# Add puppeteer with xvfb wrapper
claude mcp add puppeteer -- xvfb-run -a npx -y @modelcontextprotocol/server-puppeteer
```

### Step 5: Restart Claude Code
Restart Claude Code to reload MCP configuration.

## Verification
- **Playwright MCP**: Works immediately after Chrome installation
- **Puppeteer MCP**: Works after reconfiguration with xvfb-run wrapper

## Persistence
These fixes persist across new WSL terminals because:
- Passwordless sudo is system-wide configuration
- Xvfb and Chrome are installed globally
- MCP configuration is saved to Claude Code settings

## Alternative Approaches
If you prefer to see browser UI:
1. Install X server on Windows (VcXsrv/Xming)
2. Set DISPLAY variable in WSL:
   ```bash
echo 'export DISPLAY=$(cat /etc/resolv.conf | grep nameserver | awk "{print \$2; exit;}"):0.0' >> ~/.bashrc
   source ~/.bashrc
```

## Common Additional Flags
For problematic setups, add these flags to browser launch options:
- `--disable-gpu`
- `--no-sandbox`
- `--disable-setuid-sandbox`
- `--single-process`

## Testing Commands
```bash
# Test Playwright
mcp__playwright-mcp__browser_navigate url="https://example.com"

# Test Puppeteer (after restart)
mcp__puppeteer__puppeteer_navigate url="https://example.com"
```

This solution resolves browser automation issues for Claude Code in WSL environments permanently.