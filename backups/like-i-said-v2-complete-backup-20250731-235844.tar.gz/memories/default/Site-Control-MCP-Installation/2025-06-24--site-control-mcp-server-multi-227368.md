---
id: 1750765227362ifdwftfic
timestamp: 2025-06-24T11:40:27.362Z
complexity: 4
category: work
project: Site-Control-MCP-Installation
tags: ["mcp","multi-client","configuration","contentful","cursor-issue"]
priority: high
status: active
---
# Site Control MCP Server Multi-Client Installation Project

## Project Overview
Successfully installed and configured Site Control MCP server across multiple AI clients (Claude Code, Claude Desktop, Windsurf, Cursor). The MCP server provides Contentful-based site management tools for the Bina Bekitzur AI site.

## Repository Details
- **Source**: https://github.com/endlessblink/Site-Control-MCP.git
- **Local Path**: `/mnt/d/MY PROJECTS/AI/LLM/AI Code Gen/my-builds/Web Dev/Bina-Bekitzur-Main/Site-Control-MCP-Export/`
- **Server File**: `server.js`
- **Main Site Project**: Bina Bekitzur AI tools and tutorials website

## MCP Server Capabilities
The Site Control MCP provides 10 tools for:
- Content Management (AI tools, terms, categories)
- SEO Management (meta tags, domains, OpenGraph)
- Quality Assurance (content validation, backups)
- GitHub Integration (repo sync, project data)
- Site Configuration (global settings)

## Client Configuration Status

### ✅ Claude Code (WSL)
- **Config**: `~/.claude.json`
- **Status**: Working configuration
- **Path**: WSL format `/mnt/d/...`

### ✅ Claude Desktop
- **Config**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Status**: Configuration ready
- **Path**: Windows format `D:\\...`

### ✅ Windsurf
- **Config**: `.windsurf/settings.json`
- **Status**: Configuration ready
- **Path**: Windows format `D:\\...`

### ⚠️ Cursor - ISSUE IDENTIFIED
- **Config**: `.cursor/mcp.json`
- **Status**: Shows zero tools - authentication issue
- **Problem**: Using placeholder token instead of real Contentful management token

## Environment Variables Required
```bash
CONTENTFUL_SPACE_ID=hd99ode6traw
CONTENTFUL_DELIVERY_TOKEN=placeholder_token  # NEEDS REAL TOKEN
CONTENTFUL_MANAGEMENT_TOKEN=CFPAT-3VWUNXEkGKOoZtfyGP9wsDIg6LrVTcydzBe9ulNptQg  # REAL TOKEN
CONTENTFUL_ENVIRONMENT=master
```

## Key Technical Discoveries
1. **Cursor uses `.cursor/mcp.json`** not `.cursor/settings.json`
2. **Path format differences**: WSL vs Windows paths for different clients
3. **Token authentication critical**: Placeholder tokens result in zero tools
4. **MCP protocol working**: Server responds correctly to JSON-RPC calls

## Files Created/Modified
- `.cursor/mcp.json` - Cursor MCP configuration
- `.mcp.json` - Project-specific MCP configuration  
- `cursor_config.json` - Standalone Cursor config
- `MULTI_CLIENT_SETUP.md` - Updated with correct paths
- `COMPLETE_SETUP_GUIDE.md` - Comprehensive setup documentation
- `.env` - Environment variables with placeholder tokens

## User's Final Request
Create a local server with shared environment that all MCP clients can pull from, instead of managing each client configuration manually. This would centralize token management and simplify deployment.

## Next Priority Actions
1. Design centralized MCP environment server
2. Fix Cursor authentication issue with real tokens
3. Test all clients with working credentials
4. Implement shared environment solution