---
id: 1750702056113sfqkv9y5j
timestamp: 2025-06-23T18:07:36.113Z
complexity: 4
category: research
tags: ["MCP","memory-server","architecture","best-practices","performance-optimization","project-isolation","global-search","storage","implementation-guide"]
priority: high
status: reference
---
Based on the search results and MCP best practices, here's a comprehensive analysis of your memory server architecture and solutions:

### Best Practices for MCP Memory Storage Architecture
1. **Global vs. Project-Scoped Storage**  
   MCP architectures should support both storage modes simultaneously:
- **Project-scoped memories** should be stored in `.mcp-memory` within each project directory [2][14]
- **Global memories** should reside in `~/.config/mcp-memory` [2][5]
- This dual approach maintains isolation while allowing cross-project knowledge sharing [2][15]

2. **Default Search Behavior**  
   Tools should default to **project-scoped search** when executed within a project context:
- This aligns with MCP's isolation principles [4][9]
- Global search should require explicit parameters (e.g., `--global` flag) [5][15]
- Anthropic's MCP implementation shows session-specific contexts take precedence [4][9]

3. **Performance Optimization**  
   For 100+ memory files:
- Implement **indexing** using vector databases (Qdrant/Elasticsearch) [5][11][16]
- Use **caching mechanisms** for frequently accessed memories [7][17]
- Add **pagination** to search results (e.g., `limit=25` parameter) [2][14]
- Project-scoped searches naturally reduce latency by limiting scan scope [17]

4. **Session/Project Isolation**  
- Maintain strict **directory-based isolation**: `/memories/{project-name}` [2][4][9]
- Implement **session-bound memory access** using context tokens [6][19]
- Use **role-based access control** for cross-project memory access [11][20]
- Claude's MCP workflow recommends Git worktrees for complete isolation [9]

5. **Persistence & Cross-Session Access**  
- **Project memories** should persist in project directories [2][9]
- **Global memories** should persist in user home directories [2][5]
- Use **memory consolidation techniques** to merge relevant cross-session data [6][18]
- Implement **semantic search** rather than directory scans for cross-project recall [5][12][16]

### Recommended Implementation Adjustments
1. **Modify Search Parameters**  
   ```javascript
// Before (project-limited)
   const memories = await storage.listMemories(project);

   // After (configurable scope)
   const { scope = 'project' } = args;
   const memories = scope === 'global' 
     ? await storage.listMemories()
     : await storage.listMemories(project);
```

2. **Adopt Tiered Memory Architecture**  
   ```mermaid
graph LR
   A[Memory Request] --> B{Scope Defined?}
   B -->|Project| C[Scan Project Directory]
   B -->|Global| D[Query Central Index]
   C --> E[Return Results]
   D --> E
```

3. **Performance Optimization Table**  
   | Approach | Project-Scoped | Global |
   |----------|----------------|--------|
   | **Scan Time** | O(n) for project files | O(m) for all files |
   | **Recommended** | Default | With caching/indexing |
   | **Tools** | Direct filesystem access | Vector database |

### Security Considerations
- **Memory access controls**: Implement session-bound authorization [19][20]
- **Audit trails**: Log all memory operations [11][13]
- **Data encryption**: Protect sensitive memories at rest [19][20]

### Summary
Your fix aligns with MCP best practices by enabling global search when project context isn't required. For optimal performance:
1. Maintain **project-scoped as default** behavior [4][9]
2. Implement **indexed global search** using vector databases [5][12][16]
3. Add **explicit scope parameters** to MCP tools [2][15]
4. Preserve **isolation through directory structure** [2][9]
5. Consider **transition to database-backed storage** at scale [5][11][16]

These patterns balance performance with context integrity, following implementations like Anthropic's MCP servers [4], OpenMemory [11], and Claude's memory architecture [18].

[References 1-46 included as provided]