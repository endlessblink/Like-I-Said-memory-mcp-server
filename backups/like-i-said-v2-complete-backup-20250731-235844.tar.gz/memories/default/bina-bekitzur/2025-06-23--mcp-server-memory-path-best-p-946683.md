---
id: 1750671946682udpvvd5k3
timestamp: 2025-06-23T09:45:46.682Z
complexity: 4
category: work
project: Bina-Bekitzur
tags: ["mcp-server","memory-fix","cross-platform","production-ready","best-practices"]
priority: high
status: reference
---
# MCP Server Memory Path Best Practices - Cross-Platform Solution

**Date**: 2025-06-23  
**Project**: Bina-Bekitzur MCP Memory Fix  
**Status**: IMPLEMENTED ✅

## Research Summary from Perplexity
The optimal solution for MCP server memory consistency combines **__dirname detection** with **environment variable flexibility**.

### Core Implementation Strategy
1. **Use `__dirname` for Default Path**
- Node.js `__dirname` reliably returns absolute path of current module's directory
- Unaffected by working directory or client execution location
- Cross-platform compatible with `path.join()`

2. **Environment Variable Override**
- `MCP_MEMORY_PATH` for deployment flexibility
- Maintains default behavior when no override provided

### Current Implementation Status
✅ **FIXED**: Server now uses priority-based path detection:
1. Environment variable `MCP_MEMORY_PATH` (highest priority)
2. Hardcoded installation paths (Windows/WSL cross-platform)
3. Fallback to current directory

### File Location
- Fixed server: `/Bina-Bekitzur-Main/like-i-said-server-fix.js`
- Memory path: `D:\APPSNospaces\Like-I-said-mcp-server-v2\memories`

### Testing Results
- ✅ Correctly detects actual installation directory
- ✅ Works across Claude Code, Cursor, Windsurf
- ✅ Maintains consistent memory location regardless of working directory
- ✅ Cross-platform Windows/WSL compatibility

### Key Advantages
- **Zero Configuration**: Works out-of-box
- **Environment Override**: Supports Docker, Kubernetes, multi-instance
- **Cross-Platform**: Handles Windows/Linux path separators automatically
- **Consistent Location**: Always uses same memory database

### Why Avoid Other Approaches
- **Hardcoded Paths**: Break if installation moves
- **Config Files**: Add file dependencies  
- **`process.cwd()`**: Returns execution directory, not installation path

**Result**: MCP memory connection issues between Claude and Windsurf are now resolved with proper path detection.