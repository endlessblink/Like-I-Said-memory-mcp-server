---
id: 1752869345356fuu2svedk
timestamp: 2025-07-18T20:09:05.356Z
complexity: 4
category: code
tags: ["debugging", "cors", "dashboard", "port-mismatch", "browser-cache", "localStorage", "troubleshooting", "title:Symptoms", "summary:Title: Dashboard Not Loading - CORS Errors Due to Cached Wrong Port. Problem: React dashboard wouldn't load in Firefox, showing CORS errors about '..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-18T20:09:05.356Z
metadata:
  content_type: text
  size: 1289
  mermaid_diagram: false
---Title: Dashboard Not Loading - CORS Errors Due to Cached Wrong Port

Problem: React dashboard wouldn't load in Firefox, showing CORS errors about 'Access-Control-Allow-Credentials' when trying to access API endpoints.

Root Cause: Browser localStorage had cached port 3001 from a previous session, but the server was now running on port 3002. This caused the frontend (served from port 3002) to make cross-origin requests to the wrong port (3001).

Symptoms:
- CORS errors in browser console
- "NetworkError when attempting to fetch resource"
- API calls failing with "expected 'true' in CORS header"

Solution:
1. Open browser console (F12)
2. Clear cached port: localStorage.removeItem('like-i-said-api-port')
3. Hard refresh page (Ctrl+F5)
4. Frontend will auto-detect correct port

Prevention:
- Always verify which port the browser is trying to connect to
- Check actual server port with: ps aux | grep dashboard
- Test API directly: curl http://localhost:PORT/api/status

Important: This is NOT a WSL2 networking issue! Don't create complex port forwarding or firewall rules. The dashboard already handles port detection automatically - just clear the cache.

Tags: debugging, cors, dashboard, port-mismatch, browser-cache, localStorage, troubleshooting
Priority: High
Category: Code