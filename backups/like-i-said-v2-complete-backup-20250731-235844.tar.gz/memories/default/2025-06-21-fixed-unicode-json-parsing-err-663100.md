---
id: 1750497663100sgr50maah
timestamp: 2025-06-21T09:21:03.100Z
complexity: 2
category: code
tags: ["bug-fix","unicode","json","api","mcp-server"]
priority: high
status: active
---
Fixed Unicode JSON parsing error in Like-I-Said MCP server v2. The error "no low surrogate in string: line 1 column 5957" was caused by improper handling of Unicode surrogate pairs in the sanitizeForJSON function when making AI API calls to OpenAI/Anthropic.

**Problem:** The original sanitizeForJSON function was removing surrogate pairs incorrectly with `.replace(/[\uD800-\uDFFF]/g, '')` which could break valid Unicode characters.

**Solution:** Enhanced the sanitizeForJSON function in server-markdown.js:80-99 to:
1. First validate JSON compatibility with JSON.stringify()
2. Apply minimal sanitization if validation passes
3. Use aggressive sanitization only if validation fails
4. Properly handle surrogate pairs: `.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g, '?')` for valid pairs
5. Remove only orphaned surrogates: `.replace(/[\uD800-\uDFFF]/g, '')`

This prevents API errors when memory content contains Unicode characters that could break JSON parsing in AI enhancement requests.