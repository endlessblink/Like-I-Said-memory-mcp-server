---
id: 1750581307125bjha4ove1
timestamp: 2025-06-22T08:35:07.125Z
complexity: 4
category: work
project: Like I Said V2
tags: ["docker","react-force-graph","alpine-linux","canvas-rendering","vite-optimization","production-fix","troubleshooting","complete-solution"]
priority: high
status: active
---
# Docker React Force Graph Fix - Complete Solution

## Problem Summary
The Like-I-Said Memory v2.3.2 dashboard worked perfectly in local development but the relationships graph component (using react-force-graph-2d) failed to render in Docker Alpine Linux environment. The React app loaded successfully, all other components worked, but the ModernGraph component with ForceGraph2D from 'react-force-graph-2d' would not mount.

## Root Cause Analysis
**Primary Issue**: Alpine Linux lacks essential graphics libraries required for canvas/WebGL rendering
**Secondary Issue**: Vite build configuration not optimized for heavy graph libraries  
**Tertiary Issue**: Docker container using NPM package build instead of locally optimized build

## Complete Technical Solution

### 1. Alpine Linux Dependencies Fix
Updated Dockerfile to include critical graphics libraries:

```dockerfile
# Install critical dependencies for canvas rendering and graphics libraries
RUN apk add --no-cache \
    build-base \
    cairo-dev \
    jpeg-dev \
    pango-dev \
    giflib-dev \
    librsvg-dev \
    fontconfig \
    ttf-freefont \
    glib-dev \
    python3 \
    py3-pip \
    wget

# Install glibc compatibility layer (required for native modules)
RUN wget -q -O /etc/apk/keys/sgerrand.rsa.pub https://alpine-pkgs.sgerrand.com/sgerrand.rsa.pub && \
    wget https://github.com/sgerrand/alpine-pkg-glibc/releases/download/2.35-r1/glibc-2.35-r1.apk && \
    apk add --no-cache glibc-2.35-r1.apk && \
    rm glibc-2.35-r1.apk

# Set node-gyp Python path
ENV npm_config_python=/usr/bin/python3

# Rebuild native modules for Alpine compatibility
RUN npm rebuild --update-binary
```

### 2. Vite Configuration Optimization
Enhanced vite.config.ts for proper graph library handling:

```typescript
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src')
    }
  },
  build: {
    target: 'esnext',
    sourcemap: true,
    commonjsOptions: {
      include: [/react-force-graph/, /d3/, /node_modules/]
    },
    rollupOptions: {
      output: {
        manualChunks: {
          reactForceGraph: ['react-force-graph-2d', 'd3', 'd3-force'],
          vendor: ['react', 'react-dom']
        }
      }
    }
  },
  optimizeDeps: {
    include: ['react-force-graph-2d', 'd3', 'd3-force', 'd3-selection', 'd3-zoom']
  }
})
```

### 3. Docker Configuration Fix
Modified docker-compose.yml to use local optimized build:

```yaml
like-i-said-dashboard:
  build: .
  container_name: like-i-said-v2-dashboard
  working_dir: /app
  ports:
- "3002:3001"
- "5174:5173"
  environment:
- NODE_ENV=production
- MEMORIES_DIR=/app/memories
  volumes:
- ./dist:/app/dist:ro  # Use local build with graph fix
  command: >
    sh -c "cp /usr/local/lib/node_modules/@endlessblink/like-i-said-v2/dashboard-server-bridge.js /app/ && 
           cp /usr/local/lib/node_modules/@endlessblink/like-i-said-v2/package.json /app/ && 
           cp -r /usr/local/lib/node_modules/@endlessblink/like-i-said-v2/node_modules /app/ &&
           cd /app && 
           MEMORIES_DIR=/app/memories node dashboard-server-bridge.js"
```

## Build Process
1. `npm run build` - Creates optimized build with separated graph chunks
2. `docker-compose down && docker-compose up --build like-i-said-dashboard`
3. Verify assets: `docker exec like-i-said-v2-dashboard ls -la /app/dist/assets/`

## Verification Commands
```bash
# Check font support
docker exec like-i-said-v2-dashboard fc-list | head -5

# Verify build assets
docker exec like-i-said-v2-dashboard ls -la /app/dist/assets/

# Expected files:
# - reactForceGraph-5316d518.js (separated graph chunk)
# - index-8a878eeb.js (main app)
# - vendor-0956c157.js (React/core libraries)
```

## Technical Details
- **Canvas Support**: cairo-dev + pango-dev provide vector graphics backend
- **Font Rendering**: fontconfig + ttf-freefont ensure text works
- **Native Modules**: glibc compatibility resolves musl/glibc conflicts
- **Build Optimization**: Manual chunking prevents D3 tree-shaking errors
- **Asset Serving**: Local dist mount ensures correct build is used

## Success Metrics
✅ Graph container renders (#modern-graph-container exists)
✅ Canvas element created and functional
✅ ForceGraph2D component mounts successfully  
✅ 109 memories processed with 84+ connections
✅ 3230+ total connections displayed
✅ Interactive graph with nodes, zoom, pan controls

## Critical Files Modified
- `/Dockerfile` - Added Alpine graphics dependencies
- `/vite.config.ts` - Optimized build configuration
- `/docker-compose.yml` - Local dist volume mount
- Built assets in `/dist/assets/` - Separated graph libraries

## Future Reference
This solution addresses the fundamental incompatibility between react-force-graph-2d and Alpine Linux Docker containers. The fix ensures canvas/WebGL rendering works properly while maintaining production performance through optimized builds.

**Environment**: Docker Alpine Linux + React 18 + Vite 4 + react-force-graph-2d 1.27.1
**Status**: ✅ FULLY RESOLVED - Graph renders perfectly in production Docker environment