---
id: 17504982389637d58hnse3
timestamp: 2025-06-21T09:30:38.963Z
complexity: 2
category: work
tags: ["file-organization","memory-management","cleanup","project-structure"]
priority: medium
status: active
---
# **Memory Organization Issue Discovered**


Found orphaned memory files in root `/memories` directory that should be in project folders:

**Files outside project folders:**
- `2025-06-17_5bf3aec7.md`
- `2025-06-18_8d47b584.md`

**Proper project structure should be:**
- `/memories/default/` - Default project memories
- `/memories/like-i-said-v2/` - Project-specific memories  
- `/memories/test-suite/` - Test memories

**Root cause:** These files were likely created before the project-based organization system was fully implemented in the markdown storage system. The MarkdownStorage class in server-markdown.js now properly organizes memories into project directories, but legacy files remain in the root.

**Impact:** These orphaned files may not be properly accessible through the project-filtered API calls and could cause confusion in the dashboard interface.

**Solution needed:** Migrate orphaned files to appropriate project directories or default folder.