---
id: 1752617319428yqo9bf7ik
timestamp: 2025-07-15T22:08:39.428Z
complexity: 4
category: work
project: Like-I-said-mcp-server-v2
tags: ["maya-debug", "windows-issues", "v2.6.2", "installation", "title:Mayas Windows Installation Issues - Complete Debug Session", "summary:Mayas Windows Installation Issues - Complete Debug Session"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T22:08:39.428Z
metadata:
  content_type: code
  size: 1143
  mermaid_diagram: false
---## Maya's Windows Installation Issues - Complete Debug Session

### Issue Timeline:
1. Maya initially had v1.0.0 installed in wrong directory
2. She was using `npm install` instead of `npx` command
3. Got v2.6.0 working but couldn't create memories - "directory exists but is empty"
4. Fixed Windows path handling in v2.6.2 - case-sensitive path comparison issue
5. After v2.6.2 update, "it's not working at all now"

### Technical Details:
- Maya's memory path: `C:\\Users\\User\\like-i-said-mcp\\memories`
- The issue was in `getProjectDir()` method - Windows paths need case-insensitive comparison
- Fixed by normalizing paths with `toLowerCase()` and `replace(/\\/g, '/')` on Windows
- Published v2.6.2 with the fix

### Current Status:
- Maya reports v2.6.2 "not working at all"
- Need to debug if:
  1. NPM update actually updated Claude Desktop's files
  2. Debug console.error messages are breaking JSON-RPC
  3. Windows is caching old version
  4. Installation path issues

### Commands for Maya:
```bash
# Check version
npm list -g @endlessblink/like-i-said-v2

# Reinstall
npx @endlessblink/like-i-said-v2 like-i-said-v2 install
```