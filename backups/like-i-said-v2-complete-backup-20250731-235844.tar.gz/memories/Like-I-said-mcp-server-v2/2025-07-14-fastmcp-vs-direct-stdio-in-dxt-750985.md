---
id: 1752518750978h8r833a6w
timestamp: 2025-07-14T18:45:50.978Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["fastmcp", "stdio", "dxt", "solution", "debugging", "title:**Working Pattern**", "summary:FastMCP vs Direct stdio in DXT Environment. Key Discovery: The basic JSON-RPC DXT that worked did NOT use FastMCP."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:45:50.978Z
metadata:
  content_type: text
  size: 942
  mermaid_diagram: false
---FastMCP vs Direct stdio in DXT Environment

**Key Discovery**: The basic JSON-RPC DXT that worked did NOT use FastMCP!

**Working Pattern**:
1. Direct stdin reading: `for line in sys.stdin:`
2. Direct stdout writing: `print(response_json)` + `sys.stdout.flush()`
3. No complex frameworks, just Python stdlib
4. Simple JSON-RPC 2.0 message handling

**Why FastMCP fails in DXT**:
- FastMCP's stdio transport may not be compatible with Claude Desktop's DXT environment
- The embedded Python environment might have issues with FastMCP's async handling
- Complex initialization or transport setup failing silently

**Solution**: Create simple stdio-based server without FastMCP
- Read JSON-RPC messages from stdin line by line
- Process messages synchronously
- Write responses to stdout with flush
- Use only Python standard library + minimal deps (yaml)

This explains why all FastMCP-based builds failed while the basic JSON-RPC server worked.