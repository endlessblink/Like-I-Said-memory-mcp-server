---
id: 17525993647355joywvcvk
timestamp: 2025-07-15T17:09:24.735Z
complexity: 3
category: code
project: like-i-said-mcp-server-v2
tags: ["cleanup", "folder-structure", "repository-organization", "title:Folder cleanup recommendations for like-i-said-mcp-server-v2", "summary:Folder cleanup recommendations for like-i-said-mcp-server-v2:. Essential folders to keep:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:09:24.735Z
metadata:
  content_type: text
  size: 720
  mermaid_diagram: false
---Folder cleanup recommendations for like-i-said-mcp-server-v2:

**Essential folders to keep:**
- lib/ (core server libraries)
- src/ (React dashboard source)
- public/ (static assets)

**Folders to delete (already gitignored):**
- __tests__/, tests/ (test files)
- dist/ (build output, auto-generated)
- data/, data-backups/, vectors/ (runtime data)
- config/, config-examples/ (one-off configs)
- scripts/ (one-off scripts)
- temp-dxt*, dist-final-working/, build/ (old build artifacts)

**Consider removing:**
- python-port/ (221MB - Python port attempt, delete if not needed)
- assets/images/mcp-error-*.png (error screenshots)

This cleanup would significantly reduce repository size while keeping all essential code.