---
id: 1752517958194i8i1kpe0l
timestamp: 2025-07-14T18:32:38.194Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["python", "mcp", "dxt", "fastmcp", "claude-desktop", "debugging", "solution", "title:**Root Causes Identified**", "summary:Python MCP Server DXT Disconnection Solution. Problem: Python FastMCP server works perfectly when run directly but disconnects immediately when pac..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:32:38.194Z
metadata:
  content_type: code
  size: 1082
  mermaid_diagram: false
---Python MCP Server DXT Disconnection Solution

**Problem**: Python FastMCP server works perfectly when run directly but disconnects immediately when packaged as DXT in Claude Desktop.

**Root Causes Identified**:
1. Embedded Python distribution path issues - python._pth file needs proper configuration
2. Complex async wrappers interfere with stdio transport
3. FastMCP needs direct mcp.run() call without intermediaries

**Working Solution (v3)**:
1. Fix python311._pth file:
```
python311.zip
.
..\server
..\server\lib
import site
```

2. Simple main.py entry point:
```python
from comprehensive_server import mcp
if __name__ == "__main__":
    mcp.run()  # Direct call, no wrappers
```

3. Manifest structure must match working DXTs:
- dxt_version: "0.1" (not "0.1.0")
- server.type: "python"
- server.entry_point: "server/main.py"
- Use ${__dirname} in args

**Key Insights**:
- Embedded Python needs explicit path configuration
- Simple is better - avoid complex wrappers
- FastMCP handles stdio automatically when called directly
- No async wrappers needed for DXT environment