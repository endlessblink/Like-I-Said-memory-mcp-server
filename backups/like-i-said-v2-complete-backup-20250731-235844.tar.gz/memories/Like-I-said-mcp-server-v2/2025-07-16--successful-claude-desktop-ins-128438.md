---
id: 1752699127153gif7fxsuz
timestamp: 2025-07-16T20:52:07.153Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["claude-desktop", "success", "v2.5.1", "installation", "working", "json-rpc-fix", "title:Successful Claude Desktop Installation - v2.5.1 Working", "summary:Problem Solved: The Claude Desktop JSON-RPC protocol corruption issue was resolved by using v2.5.1."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T20:52:07.153Z
metadata:
  content_type: text
  size: 799
  mermaid_diagram: false
---## Successful Claude Desktop Installation - v2.5.1 Working

**Problem Solved**: The Claude Desktop JSON-RPC protocol corruption issue was resolved by using v2.5.1.

**Working Commands**:
1. `npm i @endlessblink/like-i-said-v2@2.5.1` - Downloads the package
2. `npx @endlessblink/like-i-said-v2@2.5.1 install` - Configures Claude Desktop (this worked really well)

**Key Finding**: v2.5.1 is the stable version that works with Claude Desktop without the JSON-RPC corruption issues that were affecting the latest version.

**Error Avoided**: `Unexpected token '�', "�� More in"... is not valid JSON` - this was happening with latest version due to Unicode/console output pollution.

**Environment Variables Used**:
- MEMORY_DIR=C:\Users\endle\memories
- TASK_DIR= (empty)
- MCP_QUIET=true
- NO_COLOR=1