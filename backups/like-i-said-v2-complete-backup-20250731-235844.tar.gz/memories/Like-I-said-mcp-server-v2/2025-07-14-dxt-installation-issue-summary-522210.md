---
id: 175249952219909xm1fmjc
timestamp: 2025-07-14T13:25:22.199Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["dxt", "windows", "debugging", "mcp", "claude-desktop", "title:DXT Installation Issue Summary", "summary:DXT Installation Issue Summary:. js-based MCP servers fail in Claude Desktop DXT packages on Windows with Server disconnected errors."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T13:25:22.199Z
metadata:
  content_type: text
  size: 986
  mermaid_diagram: false
---DXT Installation Issue Summary:

**Problem**: Node.js-based MCP servers fail in Claude Desktop DXT packages on Windows with "Server disconnected" errors.

**Key Findings**:
1. Python-based DXT (comfy-guru) works perfectly
2. Node.js DXT installs but server disconnects immediately after initialize request
3. Error: "Server transport closed unexpectedly, this is likely due to the process exiting early"
4. Multiple approaches tried: ES modules, CommonJS, bundling, auto-install - all failed

**Working Example Analysis (comfy-guru)**:
- Python-based with FastMCP
- No user_config in manifest
- Self-installing dependencies
- Uses standalone_mcp_server.py entry point

**Failed Attempts**:
1. ES modules with dynamic imports
2. Pure CommonJS with .cjs extension  
3. Bundled with esbuild
4. Including node_modules
5. Auto-installing dependencies
6. Various manifest configurations

**Hypothesis**: Claude Desktop may have different execution contexts for Python vs Node.js DXT packages.