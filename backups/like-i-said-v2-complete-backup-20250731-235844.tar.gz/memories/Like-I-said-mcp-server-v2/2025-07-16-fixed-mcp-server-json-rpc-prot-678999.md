---
id: 1752692678976qu6bh83se
timestamp: 2025-07-16T19:04:38.976Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["mcp", "json-rpc", "bugfix", "npx", "protocol", "ansi-codes", "title:Fixed Mcp Server Protocol Corruption Issue Caused Console", "summary:Fixed MCP server JSON-RPC protocol corruption issue caused by console output and ANSI color codes in NPX mode.  Created npx-clean-wrapper."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T19:04:38.976Z
metadata:
  content_type: code
  size: 633
  mermaid_diagram: false
---Fixed MCP server JSON-RPC protocol corruption issue caused by console output and ANSI color codes in NPX mode. Created npx-clean-wrapper.js that:
1. Suppresses all console output except stderr MCP messages
2. Filters out ANSI color codes and startup messages
3. Sets environment variables for quiet mode and no colors
4. Only allows clean JSON-RPC messages through

The error was visible in Claude Desktop showing "Unexpected token" errors with ANSI codes like [34m, [32m corrupting the JSON.

Solution: Added new bin entry "like-i-said-v2-mcp" that uses the clean wrapper for MCP mode while keeping regular CLI functionality intact.