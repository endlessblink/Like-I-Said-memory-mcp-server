---
id: 1752523921402myttvirso
timestamp: 2025-07-14T20:12:01.402Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["mcp-server", "tool-inventory", "schema-documentation", "python-port", "api-reference", "title:Complete 23-Tool MCP Server Inventory", "summary:Tool Categories Overview"]
priority: high
status: reference
access_count: 0
last_accessed: 2025-07-14T20:12:01.402Z
metadata:
  content_type: code
  size: 12468
  mermaid_diagram: false
---# Complete 23-Tool MCP Server Inventory

## Tool Categories Overview
- **Memory Tools (6)**: add_memory, get_memory, list_memories, delete_memory, search_memories, test_tool
- **Task Management Tools (6)**: create_task, update_task, list_tasks, get_task_context, delete_task, generate_dropoff
- **Enhancement Tools (5)**: enhance_memory_metadata, batch_enhance_memories, smart_status_update, get_task_status_analytics, validate_task_workflow
- **Automation Tools (3)**: get_automation_suggestions, batch_enhance_memories_ollama, batch_enhance_tasks_ollama
- **Ollama Tools (2)**: check_ollama_status, enhance_memory_ollama
- **Utility Tools (1)**: deduplicate_memories

## Complete Tool Definitions

### 1. add_memory
**Description**: AUTOMATICALLY use when user shares important information, code snippets, decisions, learnings, or context that should be remembered for future sessions. Includes smart categorization and auto-linking.
**Required**: content
**Properties**:
- content (string): The memory content to store
- tags (array of strings): Optional tags for the memory
- category (string): Memory category (personal, work, code, research, conversations, preferences)
- project (string): Project name to organize memory files
- priority (string): Priority level (low, medium, high)
- status (string): Memory status (active, archived, reference)
- related_memories (array of strings): IDs of related memories for cross-referencing
- language (string): Programming language for code content

### 2. get_memory
**Description**: Retrieve a memory by ID
**Required**: id
**Properties**:
- id (string): The memory ID to retrieve

### 3. list_memories
**Description**: List all stored memories or memories from a specific project
**Required**: None
**Properties**:
- limit (number): Maximum number of memories to return
- project (string): Filter by project name

### 4. delete_memory
**Description**: Delete a memory by ID
**Required**: id
**Properties**:
- id (string): The memory ID to delete

### 5. search_memories
**Description**: AUTOMATICALLY use when user asks about past work, previous decisions, looking for examples, or needs context from earlier sessions. Provides semantic and keyword-based search.
**Required**: query
**Properties**:
- query (string): Search query
- project (string): Limit search to specific project

### 6. test_tool
**Description**: Simple test tool to verify MCP is working
**Required**: message
**Properties**:
- message (string): Test message

### 7. generate_dropoff
**Description**: Generate conversation dropoff document for session handoff with context from recent memories, git status, and project info
**Required**: None
**Properties**:
- session_summary (string): Brief summary of work done in this session (default: 'Session work completed')
- include_recent_memories (boolean): Include recent memories in the dropoff (default: true)
- include_git_status (boolean): Include git status and recent commits (default: true)
- recent_memory_count (number): Number of recent memories to include (default: 5)
- output_format (string): Output format: markdown or json (enum: ['markdown', 'json'], default: 'markdown')
- output_path (string): Custom output directory path (default: null)

### 8. create_task
**Description**: Create a new task with intelligent memory linking. Tasks start in "todo" status. IMPORTANT: After creating a task, remember to update its status to "in_progress" when you begin working on it.
**Required**: title, project
**Properties**:
- title (string): Task title
- description (string): Detailed task description
- project (string): Project identifier
- category (string): Task category (enum: ['personal', 'work', 'code', 'research'])
- priority (string): Task priority (enum: ['low', 'medium', 'high', 'urgent'], default: 'medium')
- parent_task (string): Parent task ID for subtasks
- manual_memories (array of strings): Memory IDs to manually link
- tags (array of strings): Task tags
- auto_link (boolean): Automatically find and link relevant memories (default: true)

### 9. update_task
**Description**: Update task status and details. STATE MANAGEMENT GUIDELINES: Always mark tasks as "in_progress" when starting work, update to "done" immediately after completing, set to "blocked" when encountering obstacles, use "todo" for tasks not yet started.
**Required**: task_id
**Properties**:
- task_id (string): Task ID to update
- status (string): New task status (enum: ['todo', 'in_progress', 'done', 'blocked'])
- title (string): New task title
- description (string): New task description
- add_subtasks (array of strings): Task titles to add as subtasks
- add_memories (array of strings): Memory IDs to link
- remove_memories (array of strings): Memory IDs to unlink

### 10. list_tasks
**Description**: List tasks with filtering options. Shows task status distribution and workflow health. Use this to monitor work progress and identify tasks that need status updates.
**Required**: None
**Properties**:
- project (string): Filter by project
- status (string): Filter by status (enum: ['todo', 'in_progress', 'done', 'blocked'])
- category (string): Filter by category
- has_memory (string): Filter by memory connection
- include_subtasks (boolean): Include subtasks in results (default: true)
- limit (number): Maximum tasks to return (default: 20)

### 11. get_task_context
**Description**: Get detailed task information including status, relationships, and connected memories. Use this to understand task context and determine if status updates are needed.
**Required**: task_id
**Properties**:
- task_id (string): Task ID
- depth (string): How many levels of connections to traverse (enum: ['direct', 'deep'], default: 'direct')

### 12. delete_task
**Description**: Delete a task and its subtasks
**Required**: task_id
**Properties**:
- task_id (string): Task ID to delete

### 13. enhance_memory_metadata
**Description**: Generate optimized title and summary for a memory to improve dashboard card display. Uses intelligent content analysis to create concise, meaningful titles (max 60 chars) and summaries (max 150 chars).
**Required**: memory_id
**Properties**:
- memory_id (string): The ID of the memory to enhance with title and summary
- regenerate (boolean): Force regeneration even if title/summary already exist

### 14. batch_enhance_memories
**Description**: Batch process multiple memories to add optimized titles and summaries. Useful for enhancing existing memories that lack proper metadata for dashboard display.
**Required**: None
**Properties**:
- project (string): Filter by project name (optional)
- category (string): Filter by category (optional)
- limit (number): Maximum number of memories to process (default: 50)
- skip_existing (boolean): Skip memories that already have titles/summaries (default: true)

### 15. smart_status_update
**Description**: AUTOMATICALLY use when user mentions status changes in natural language. Intelligently parses natural language to determine intended status changes with validation and automation.
**Required**: natural_language_input
**Properties**:
- task_id (string): Task ID to update (optional - can be inferred from natural language)
- natural_language_input (string): Natural language description of the status change
- context (object): Additional context for intelligent processing
  - force_complete (boolean)
  - skip_validation (boolean)
  - blocking_reason (string)
  - completion_evidence (string)
- apply_automation (boolean): Whether to apply automation suggestions (default: true)

### 16. get_task_status_analytics
**Description**: AUTOMATICALLY use when user asks about task progress, status overview, productivity metrics, or wants analytics. Provides comprehensive status insights and recommendations.
**Required**: None
**Properties**:
- project (string): Filter analytics by project (optional)
- time_range (string): Time range for analytics (enum: ['day', 'week', 'month', 'quarter'], default: 'week')
- include_trends (boolean): Include trend analysis (default: true)
- include_recommendations (boolean): Include actionable recommendations (default: true)
- include_project_breakdown (boolean): Include project-by-project analysis (default: true)

### 17. validate_task_workflow
**Description**: Validate a proposed task status change with intelligent suggestions and workflow analysis. Use when you need to check if a status change makes sense.
**Required**: task_id, proposed_status
**Properties**:
- task_id (string): Task ID to validate
- proposed_status (string): Proposed new status (enum: ['todo', 'in_progress', 'done', 'blocked'])
- context (object): Additional context for validation
  - force_complete (boolean)
  - skip_testing (boolean)
  - skip_review (boolean)
  - blocking_reason (string)

### 18. get_automation_suggestions
**Description**: Get intelligent automation suggestions for a task based on context analysis. Use when you want to see what automated actions are possible.
**Required**: task_id
**Properties**:
- task_id (string): Task ID to analyze for automation opportunities

### 19. batch_enhance_memories_ollama
**Description**: Batch process memories using local AI (Ollama) for privacy-focused title/summary generation. Processes large numbers of memories efficiently without external API calls.
**Required**: None
**Properties**:
- project (string): Filter by project name (optional)
- category (string): Filter by category (optional)
- limit (number): Maximum number of memories to process (default: 50)
- skip_existing (boolean): Skip memories that already have titles/summaries (default: true)
- model (string): Ollama model to use (default: llama3.1:8b)
- batch_size (number): Number of memories to process in parallel (default: 5)

### 20. batch_enhance_tasks_ollama
**Description**: Batch process tasks using local AI (Ollama) for privacy-focused title/description enhancement. Processes large numbers of tasks efficiently without external API calls.
**Required**: None
**Properties**:
- project (string): Filter by project name (optional)
- category (string): Filter by category (optional)
- status (string): Filter by task status (optional)
- limit (number): Maximum number of tasks to process (default: 50)
- skip_existing (boolean): Skip tasks that already have enhanced titles/descriptions (default: true)
- model (string): Ollama model to use (default: llama3.1:8b)
- batch_size (number): Number of tasks to process in parallel (default: 5)

### 21. check_ollama_status
**Description**: Check if Ollama server is running and list available models for local AI processing.
**Required**: None
**Properties**:
- show_models (boolean): Whether to list available models (default: true)

### 22. enhance_memory_ollama
**Description**: Enhance a single memory with local AI (Ollama) for privacy-focused title/summary generation.
**Required**: memory_id
**Properties**:
- memory_id (string): ID of the memory to enhance
- model (string): Ollama model to use (default: llama3.1:8b)
- force_update (boolean): Force update even if memory already has title/summary (default: false)

### 23. deduplicate_memories
**Description**: Find and remove duplicate memory files, keeping the newest version of each memory ID. Use this to clean up duplicate memories caused by batch operations.
**Required**: None
**Properties**:
- preview_only (boolean): Preview what would be removed without actually deleting files (default: false)

## Implementation Notes for Python Server

### Schema Patterns
- All tools use `type: 'object'` for inputSchema
- Common field types: string, boolean, number, array
- Enums are frequently used for status fields and categories
- Many fields have default values specified
- Required fields are always specified in a `required` array

### Tool Categories for Implementation Priority
1. **Core Memory (6 tools)**: Essential functionality - implement first
2. **Core Task Management (6 tools)**: Task workflow - implement second  
3. **Enhancement Features (5 tools)**: Advanced features - implement third
4. **Ollama Integration (3 tools)**: Local AI processing - implement fourth
5. **Automation & Analytics (3 tools)**: Advanced automation - implement last

### Key Implementation Requirements
- All tools must support proper error handling
- Memory and task linking requires sophisticated content analysis
- Status management requires state validation
- Ollama tools need local AI integration
- All tools should support project-based organization