---
id: 1752608199416xhzotetfc
timestamp: 2025-07-15T19:36:39.416Z
complexity: 3
project: like-i-said-mcp-server-v2
tags: ["npm-installation", "bug", "missing-npm-install", "title:The installer", "summary:NPM installation fails consistently with "Server test failed" error even in clean directory. Test directory: D:\MY PROJECTS\AI\LLM\AI Code Gen\my-b..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T19:36:39.416Z
metadata:
  content_type: text
  size: 585
  mermaid_diagram: false
---NPM installation fails consistently with "Server test failed" error even in clean directory.

Test directory: `D:\MY PROJECTS\AI\LLM\AI Code Gen\my-builds\My MCP\like-i-said-npm-test`

The installer:
1. Successfully copies all files (mcp-server-wrapper.js, server-markdown.js, package.json, README.md)
2. Creates memories directory
3. Fails at server test step

This indicates the installer is not running `npm install` to install dependencies before testing the server. The server test likely fails because required Node modules (js-yaml, @modelcontextprotocol/sdk) are not installed.