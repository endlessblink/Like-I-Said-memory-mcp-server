---
id: 1752574230699vhagxrwbs
timestamp: 2025-07-15T10:10:30.699Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dashboard", "configuration", "paths", "user-data", "title:User Ran Dashboard Saved Default Needs Set Custom Paths", "summary:User ran dashboard and saved default configuration", "but needs to set custom paths to existing memories and tasks.  Dashboard working correctly but ..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T10:10:30.699Z
metadata:
  content_type: text
  size: 257
  mermaid_diagram: false
---User ran dashboard and saved default configuration, but needs to set custom paths to existing memories and tasks. Dashboard working correctly but pointing to wrong directories. Need to use --config flag to reconfigure paths to user's existing data location.