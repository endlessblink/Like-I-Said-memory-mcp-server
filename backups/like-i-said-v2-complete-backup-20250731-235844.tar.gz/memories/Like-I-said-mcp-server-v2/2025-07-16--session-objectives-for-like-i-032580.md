---
id: 17526730325727186xv740
timestamp: 2025-07-16T13:37:12.572Z
complexity: 4
category: work
project: Like-I-said-mcp-server-v2
tags: ["session-objectives", "requirements", "dynamic-ports", "path-configuration", "auto-discovery", "title:Session Objectives Complete Requirements", "summary:Primary Objectives (Must Complete):"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T13:37:12.572Z
metadata:
  content_type: code
  size: 1670
  mermaid_diagram: false
---# Session Objectives for Like-I-Said v2.6.8 - Complete Requirements

## Primary Objectives (Must Complete):

### 1. Dynamic Port Detection System
- NO hardcoded ports anywhere in the codebase
- Automatic available port discovery for dashboard server
- Frontend discovers API port dynamically at runtime
- Write discovered port to .dashboard-port file
- Fallback mechanisms if port discovery fails

### 2. Custom Path Configuration (Absolute Certainty)
- Users can set custom paths via dashboard UI
- Changes must persist across sessions
- Must handle Windows paths correctly (D:\, C:\, etc.)
- Validate paths exist and are writable
- Show real-time feedback on path validity
- Support both relative and absolute paths

### 3. Automatic Folder Discovery
- Auto-detect existing memories/tasks folders on system
- Scan common locations:
  - User home directory
  - Documents folder
  - Previous Like-I-Said installations
  - Current working directory
- Present discovered folders as suggestions
- Allow selection from found folders or manual entry
- Remember user's choice

## Constraints:
- MUST NOT break any existing functionality
- All current features must continue working
- Backward compatibility with existing installations
- User at D:\MY PROJECTS\AI\LLM\AI Code Gen\my-builds\My MCP\like-i-said-npm-test\Like-I-Said-memory-mcp-server should be able to git pull and have everything work flawlessly

## Success Criteria:
1. No port conflicts ever occur
2. Path configuration works 100% reliably
3. Auto-discovery finds existing data folders
4. All tests pass
5. WebSocket real-time updates work
6. Dashboard shows memory updates live
7. No hardcoded values anywhere