---
id: 1752524028618cjzszp1nd
timestamp: 2025-07-14T20:13:48.618Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["json-schemas", "python-validation", "exact-implementation", "tool-schemas", "title:Complete JSON Schemas for Python Implementation", "summary:Tool Schemas by Category"]
priority: high
status: reference
access_count: 0
last_accessed: 2025-07-14T20:13:48.618Z
metadata:
  content_type: code
  size: 12798
  mermaid_diagram: false
---# Complete JSON Schemas for Python Implementation

## Tool Schemas by Category

### Memory Tools (6)

#### 1. add_memory
```json
{
  "type": "object",
  "properties": {
    "content": {"type": "string", "description": "The memory content to store"},
    "tags": {"type": "array", "items": {"type": "string"}, "description": "Optional tags for the memory"},
    "category": {"type": "string", "description": "Memory category (personal, work, code, research, conversations, preferences)"},
    "project": {"type": "string", "description": "Project name to organize memory files"},
    "priority": {"type": "string", "description": "Priority level (low, medium, high)"},
    "status": {"type": "string", "description": "Memory status (active, archived, reference)"},
    "related_memories": {"type": "array", "items": {"type": "string"}, "description": "IDs of related memories for cross-referencing"},
    "language": {"type": "string", "description": "Programming language for code content"}
  },
  "required": ["content"]
}
```

#### 2. get_memory  
```json
{
  "type": "object",
  "properties": {
    "id": {"type": "string", "description": "The memory ID to retrieve"}
  },
  "required": ["id"]
}
```

#### 3. list_memories
```json
{
  "type": "object", 
  "properties": {
    "limit": {"type": "number", "description": "Maximum number of memories to return"},
    "project": {"type": "string", "description": "Filter by project name"}
  }
}
```

#### 4. delete_memory
```json
{
  "type": "object",
  "properties": {
    "id": {"type": "string", "description": "The memory ID to delete"}
  },
  "required": ["id"]
}
```

#### 5. search_memories
```json
{
  "type": "object",
  "properties": {
    "query": {"type": "string", "description": "Search query"},
    "project": {"type": "string", "description": "Limit search to specific project"}
  },
  "required": ["query"]
}
```

#### 6. test_tool
```json
{
  "type": "object",
  "properties": {
    "message": {"type": "string", "description": "Test message"}
  },
  "required": ["message"]
}
```

### Task Management Tools (6)

#### 7. generate_dropoff
```json
{
  "type": "object",
  "properties": {
    "session_summary": {"type": "string", "description": "Brief summary of work done in this session", "default": "Session work completed"},
    "include_recent_memories": {"type": "boolean", "description": "Include recent memories in the dropoff", "default": true},
    "include_git_status": {"type": "boolean", "description": "Include git status and recent commits", "default": true},
    "recent_memory_count": {"type": "number", "description": "Number of recent memories to include", "default": 5},
    "output_format": {"type": "string", "description": "Output format: markdown or json", "enum": ["markdown", "json"], "default": "markdown"},
    "output_path": {"type": "string", "description": "Custom output directory path", "default": null}
  }
}
```

#### 8. create_task
```json
{
  "type": "object",
  "properties": {
    "title": {"type": "string", "description": "Task title"},
    "description": {"type": "string", "description": "Detailed task description"},
    "project": {"type": "string", "description": "Project identifier"},
    "category": {"type": "string", "enum": ["personal", "work", "code", "research"], "description": "Task category"},
    "priority": {"type": "string", "enum": ["low", "medium", "high", "urgent"], "default": "medium", "description": "Task priority"},
    "parent_task": {"type": "string", "description": "Parent task ID for subtasks"},
    "manual_memories": {"type": "array", "items": {"type": "string"}, "description": "Memory IDs to manually link"},
    "tags": {"type": "array", "items": {"type": "string"}, "description": "Task tags"},
    "auto_link": {"type": "boolean", "default": true, "description": "Automatically find and link relevant memories"}
  },
  "required": ["title", "project"]
}
```

#### 9. update_task
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID to update"},
    "status": {"type": "string", "enum": ["todo", "in_progress", "done", "blocked"], "description": "New task status"},
    "title": {"type": "string", "description": "New task title"},
    "description": {"type": "string", "description": "New task description"},
    "add_subtasks": {"type": "array", "items": {"type": "string"}, "description": "Task titles to add as subtasks"},
    "add_memories": {"type": "array", "items": {"type": "string"}, "description": "Memory IDs to link"},
    "remove_memories": {"type": "array", "items": {"type": "string"}, "description": "Memory IDs to unlink"}
  },
  "required": ["task_id"]
}
```

#### 10. list_tasks
```json
{
  "type": "object",
  "properties": {
    "project": {"type": "string", "description": "Filter by project"},
    "status": {"type": "string", "enum": ["todo", "in_progress", "done", "blocked"], "description": "Filter by status"},
    "category": {"type": "string", "description": "Filter by category"},
    "has_memory": {"type": "string", "description": "Filter by memory connection"},
    "include_subtasks": {"type": "boolean", "default": true, "description": "Include subtasks in results"},
    "limit": {"type": "number", "default": 20, "description": "Maximum tasks to return"}
  }
}
```

#### 11. get_task_context
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID"},
    "depth": {"type": "string", "enum": ["direct", "deep"], "default": "direct", "description": "How many levels of connections to traverse"}
  },
  "required": ["task_id"]
}
```

#### 12. delete_task
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID to delete"}
  },
  "required": ["task_id"]
}
```

### Enhancement Tools (5)

#### 13. enhance_memory_metadata
```json
{
  "type": "object",
  "properties": {
    "memory_id": {"type": "string", "description": "The ID of the memory to enhance with title and summary"},
    "regenerate": {"type": "boolean", "description": "Force regeneration even if title/summary already exist"}
  },
  "required": ["memory_id"]
}
```

#### 14. batch_enhance_memories
```json
{
  "type": "object",
  "properties": {
    "project": {"type": "string", "description": "Filter by project name (optional)"},
    "category": {"type": "string", "description": "Filter by category (optional)"},
    "limit": {"type": "number", "description": "Maximum number of memories to process (default: 50)"},
    "skip_existing": {"type": "boolean", "description": "Skip memories that already have titles/summaries (default: true)"}
  }
}
```

#### 15. smart_status_update
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID to update (optional - can be inferred from natural language)"},
    "natural_language_input": {"type": "string", "description": "Natural language description of the status change"},
    "context": {
      "type": "object",
      "properties": {
        "force_complete": {"type": "boolean"},
        "skip_validation": {"type": "boolean"}, 
        "blocking_reason": {"type": "string"},
        "completion_evidence": {"type": "string"}
      },
      "description": "Additional context for intelligent processing"
    },
    "apply_automation": {"type": "boolean", "description": "Whether to apply automation suggestions (default: true)"}
  },
  "required": ["natural_language_input"]
}
```

#### 16. get_task_status_analytics
```json
{
  "type": "object",
  "properties": {
    "project": {"type": "string", "description": "Filter analytics by project (optional)"},
    "time_range": {"type": "string", "enum": ["day", "week", "month", "quarter"], "description": "Time range for analytics (default: week)"},
    "include_trends": {"type": "boolean", "description": "Include trend analysis (default: true)"},
    "include_recommendations": {"type": "boolean", "description": "Include actionable recommendations (default: true)"},
    "include_project_breakdown": {"type": "boolean", "description": "Include project-by-project analysis (default: true)"}
  }
}
```

#### 17. validate_task_workflow
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID to validate"},
    "proposed_status": {"type": "string", "enum": ["todo", "in_progress", "done", "blocked"], "description": "Proposed new status"},
    "context": {
      "type": "object", 
      "properties": {
        "force_complete": {"type": "boolean"},
        "skip_testing": {"type": "boolean"},
        "skip_review": {"type": "boolean"},
        "blocking_reason": {"type": "string"}
      },
      "description": "Additional context for validation"
    }
  },
  "required": ["task_id", "proposed_status"]
}
```

### Automation Tools (3)

#### 18. get_automation_suggestions
```json
{
  "type": "object",
  "properties": {
    "task_id": {"type": "string", "description": "Task ID to analyze for automation opportunities"}
  },
  "required": ["task_id"]
}
```

#### 19. batch_enhance_memories_ollama
```json
{
  "type": "object",
  "properties": {
    "project": {"type": "string", "description": "Filter by project name (optional)"},
    "category": {"type": "string", "description": "Filter by category (optional)"},
    "limit": {"type": "number", "description": "Maximum number of memories to process (default: 50)"},
    "skip_existing": {"type": "boolean", "description": "Skip memories that already have titles/summaries (default: true)"},
    "model": {"type": "string", "description": "Ollama model to use (default: llama3.1:8b)"},
    "batch_size": {"type": "number", "description": "Number of memories to process in parallel (default: 5)"}
  }
}
```

#### 20. batch_enhance_tasks_ollama
```json
{
  "type": "object",
  "properties": {
    "project": {"type": "string", "description": "Filter by project name (optional)"},
    "category": {"type": "string", "description": "Filter by category (optional)"},
    "status": {"type": "string", "description": "Filter by task status (optional)"},
    "limit": {"type": "number", "description": "Maximum number of tasks to process (default: 50)"},
    "skip_existing": {"type": "boolean", "description": "Skip tasks that already have enhanced titles/descriptions (default: true)"},
    "model": {"type": "string", "description": "Ollama model to use (default: llama3.1:8b)"},
    "batch_size": {"type": "number", "description": "Number of tasks to process in parallel (default: 5)"}
  }
}
```

### Ollama Tools (2)

#### 21. check_ollama_status  
```json
{
  "type": "object",
  "properties": {
    "show_models": {"type": "boolean", "description": "Whether to list available models (default: true)"}
  }
}
```

#### 22. enhance_memory_ollama
```json
{
  "type": "object",
  "properties": {
    "memory_id": {"type": "string", "description": "ID of the memory to enhance"},
    "model": {"type": "string", "description": "Ollama model to use (default: llama3.1:8b)"},
    "force_update": {"type": "boolean", "description": "Force update even if memory already has title/summary (default: false)"}
  },
  "required": ["memory_id"]
}
```

### Utility Tools (1)

#### 23. deduplicate_memories
```json
{
  "type": "object",
  "properties": {
    "preview_only": {"type": "boolean", "description": "Preview what would be removed without actually deleting files (default: false)"}
  }
}
```

## Python Schema Implementation

### Validation Helper
```python
import jsonschema
from typing import Dict, Any, Optional

def validate_tool_input(tool_name: str, params: Dict[str, Any], schemas: Dict[str, Dict]) -> tuple[bool, Optional[str]]:
    """Validate tool input parameters against schema"""
    try:
        if tool_name not in schemas:
            return False, f"Unknown tool: {tool_name}"
        
        schema = schemas[tool_name]
        jsonschema.validate(params, schema)
        return True, None
    except jsonschema.ValidationError as e:
        return False, f"Validation error: {e.message}"
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"

def apply_defaults(tool_name: str, params: Dict[str, Any], schemas: Dict[str, Dict]) -> Dict[str, Any]:
    """Apply default values from schema to parameters"""
    if tool_name not in schemas:
        return params
    
    schema = schemas[tool_name]
    properties = schema.get('properties', {})
    
    result = params.copy()
    for field_name, field_schema in properties.items():
        if field_name not in result and 'default' in field_schema:
            result[field_name] = field_schema['default']
    
    return result
```

This comprehensive schema collection provides everything needed for exact Python implementation of all 23 MCP server tools.