---
id: 1752690547656veinql5ug
timestamp: 2025-07-16T18:29:07.656Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["mcp-server", "crash-fix", "sharp-module", "windows", "dependencies", "title:MCP Server Crash Fix - Sharp Module Issue", "summary:Problem: The like-i-said-memory-v2 MCP server crashes on Windows due to missing native bindings for the sharp module", "which is a dependency of @xen..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T18:29:07.656Z
metadata:
  content_type: code
  size: 1478
  mermaid_diagram: false
---## MCP Server Crash Fix - Sharp Module Issue

**Problem**: The like-i-said-memory-v2 MCP server crashes on Windows due to missing native bindings for the `sharp` module, which is a dependency of `@xenova/transformers`.

**Error Message**:
```
Error: Cannot find module '../build/Release/sharp-win32-x64.node'
```

**Root Cause**: The `sharp` module is used by `@xenova/transformers` (imported in `lib/vector-storage.js`) and requires platform-specific native bindings that weren't properly installed.

**Solutions**:

### Option 1: Reinstall sharp with platform-specific binaries (Recommended)
```bash
# From the project directory
npm uninstall sharp
npm install --platform=win32 --arch=x64 sharp
```

### Option 2: Full dependency reinstall
```bash
# Remove node_modules and reinstall
rm -rf node_modules package-lock.json
npm install
```

### Option 3: Install sharp separately with verbose logging
```bash
npm install --ignore-scripts=false --foreground-scripts --verbose sharp
```

### Option 4: Make VectorStorage optional (code modification)
If vector search isn't critical, modify server-markdown.js to lazy-load VectorStorage:
- Move the import inside a try-catch
- Only initialize if successfully imported
- Gracefully handle vector-related operations

**Additional Notes**:
- This is a Windows-specific issue
- The sharp module is only used for image processing in the transformers library
- The error occurs at server startup because imports are evaluated immediately