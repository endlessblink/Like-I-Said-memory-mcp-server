---
id: 17526004278562qc6quu2g
timestamp: 2025-07-15T17:27:07.856Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["cleanup", "file-analysis", "root-files", "title:Root file analysis for like-i-said-mcp-server-v2", "summary:Root file analysis for like-i-said-mcp-server-v2:. KEEP - Essential Core Files:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:27:07.856Z
metadata:
  content_type: text
  size: 1297
  mermaid_diagram: false
---Root file analysis for like-i-said-mcp-server-v2:

**KEEP - Essential Core Files:**
- README.md - Main project documentation
- CLAUDE.md - Project instructions for Claude
- package.json, package-lock.json - NPM configuration
- server-markdown.js - Main MCP server
- dashboard-server-bridge.js - Dashboard API server
- cli.js - NPX installer/CLI tool
- like-i-said-memory-v2-main.dxt - DXT package
- index.html - React app entry point

**KEEP - Build Configuration:**
- vite.config.ts - Vite build config
- tsconfig.json, tsconfig.app.json, tsconfig.node.json - TypeScript configs
- tailwind.config.js - Tailwind CSS
- postcss.config.js - PostCSS
- eslint.config.js - ESLint
- jest.config.cjs - Jest tests

**DELETE - Unnecessary Files:**
- README-CLEAR.md - Duplicate README
- RELEASE-PACKAGE-GUIDE.md, RELEASE-STRUCTURE.md - One-off docs
- SESSION-DROPOFF-*.md - Session files
- TEST-DASHBOARD.md - Test documentation
- build-dxt-standalone.js, build-release-package.js - One-off scripts
- errors-1.png - Error screenshot
- test-api.html, test-concurrent-launch.js - Test files
- mcp-server-like-i-said-v2.log - Log file
- tsconfig.tsbuildinfo - Build cache

**Dashboard preserved in:**
- src/ folder with all React components
- public/ folder with static assets
- All dashboard components intact