---
id: 1752599304649gncwbt53z
timestamp: 2025-07-15T17:08:24.649Z
complexity: 3
project: like-i-said-mcp-server-v2
tags: ["cleanup", "repository-structure", "gitignore", "title:Repository cleanup analysis for like-i-said-mcp-server-v2", "summary:Repository cleanup analysis for like-i-said-mcp-server-v2:. - tests/ (move single test to tests/)."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:08:24.650Z
metadata:
  content_type: text
  size: 705
  mermaid_diagram: false
---Repository cleanup analysis for like-i-said-mcp-server-v2:

**Folders to REMOVE:**
- __tests__/ (move single test to tests/)
- assets/ (move screenshots to docs)
- build/ (build output)
- config-examples/ (merge with config/)
- data/, data-backups/, vectors/ (runtime data)
- dist-final-working/ (old distribution)
- python-port/ (failed port attempt)
- schemas/ (empty)
- temp-dxt*, temp-dxt-broken/, temp-dxt-new/ (temporary builds)
- tests/ (needs major cleanup - keep only essential tests)

**Folders to KEEP:**
- lib/ (core libraries)
- src/ (React dashboard)
- public/, config/, docs/, scripts/

The .gitignore already covers most of these but physical removal would clean up the repo significantly.