---
id: 175260944715391b43vmeb
timestamp: 2025-07-15T19:57:27.153Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["npm-fix", "v2.4.6", "mcp-protocol", "json-rpc", "title:Fixed MCP server test in v2.4.6 based on actual error output", "summary:Fixed MCP server test in v2. 6 based on actual error output:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T19:57:27.153Z
metadata:
  content_type: code
  size: 752
  mermaid_diagram: false
---Fixed MCP server test in v2.4.6 based on actual error output:

**Issue identified**: 
- Server returned error: "expected: object, received: undefined" for params
- The initialization request was using wrong protocol version

**Fixes applied**:
1. Updated protocol version from "0.1.0" to "2024-11-05" (MCP standard)
2. Added proper clientInfo to initialization
3. Added empty params object to tools/list request (required by JSON-RPC)
4. Increased delay between initialization and tools/list to 500ms
5. Added proper stdin.end() timing

**Test command that revealed the issue**:
```cmd
set DEBUG=1
node node_modules\@endlessblink\like-i-said-v2\cli.js install
```

This showed the actual JSON-RPC error response which helped identify the exact problem.