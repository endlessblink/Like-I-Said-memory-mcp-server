---
id: 1752518771056mse8fy6hu
timestamp: 2025-07-14T18:46:11.056Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["solution", "python", "dxt", "stdio", "working", "fastmcp", "claude-desktop", "title:Direct stdin reading (NO FastMCP)", "summary:for line in sys.stdin:"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:46:11.056Z
metadata:
  content_type: code
  size: 1236
  mermaid_diagram: false
---Solution: Python MCP Server DXT Working Without FastMCP

**Problem Solved**: All FastMCP-based Python DXT builds were failing with "Server disconnected" error in Claude Desktop.

**The solution is**: Create a simple stdio-based server WITHOUT FastMCP, using direct stdin/stdout handling.

**Working Pattern Discovered**:
```python
# Direct stdin reading (NO FastMCP)
for line in sys.stdin:
    request = json.loads(line)
    response = handle_message(request)
    print(json.dumps(response))
    sys.stdout.flush()
```

**Why this works**:
1. The basic JSON-RPC DXT that worked did NOT use FastMCP
2. FastMCP's stdio transport appears incompatible with Claude Desktop's DXT environment
3. Simple, synchronous stdin/stdout handling works reliably
4. No complex async operations or framework initialization

**Implementation**: Created `like-i-said-v2-simple-stdio.dxt` that:
- Reads JSON-RPC messages line by line from stdin
- Processes messages synchronously
- Writes responses directly to stdout with flush
- Uses only Python stdlib + yaml (no FastMCP)

**Key Insight**: FastMCP works perfectly when run directly but fails in DXT environment. The embedded Python or DXT runtime has issues with FastMCP's stdio transport implementation.