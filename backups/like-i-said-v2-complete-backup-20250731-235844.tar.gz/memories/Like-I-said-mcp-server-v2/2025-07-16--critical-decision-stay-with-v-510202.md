---
id: 1752699509082qplyhnauq
timestamp: 2025-07-16T20:58:29.082Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["critical-decision", "v2.5.1", "no-dependencies", "json-rpc-stable", "claude-desktop", "protocol-protection", "title:Critical Stay Not Add Dependencies That Break Mcp", "summary:CRITICAL DECISION: Stay with v2.5.1 - Do NOT Add Dependencies That Break MCP"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T20:58:29.082Z
metadata:
  content_type: code
  size: 1580
  mermaid_diagram: false
---## CRITICAL DECISION: Stay with v2.5.1 - Do NOT Add Dependencies That Break MCP

### The Discovery
After extensive debugging, we found that v2.5.1 is the PERFECT version:
- ✅ ALL AI features working (enhance_memory_metadata, ollama integration, smart analytics, etc.)
- ✅ JSON-RPC protocol stable with Claude Desktop
- ✅ All 23 MCP tools functional except one minor get_memory bug
- ✅ No protocol corruption issues

### What Broke Later Versions
Adding these dependencies after v2.5.1:
- Sharp module (image processing)
- @xenova packages (vector storage)
- Native bindings that output to stdout
- These cause Unicode pollution: `Unexpected token '�', "�� More in"... is not valid JSON`

### The Rule: NO NEW DEPENDENCIES
**NEVER add dependencies that:**
1. Have native bindings
2. Output to stdout during initialization
3. Use ANSI color codes
4. Print progress indicators
5. Could pollute JSON-RPC stream

### What v2.5.1 Already Has (All Working)
- 23 MCP tools including AI features
- Memory management with auto-categorization
- Task management with auto-linking
- Ollama integration
- Smart analytics and work detection
- Advanced search with multiple strategies
- Session handoffs and dropoff generation

### The Only Issue
- `get_memory` tool has split() error - needs surgical fix
- Fix this WITHOUT adding any new dependencies
- Keep the codebase minimal and protocol-safe

### Success Metrics
- Claude Desktop continues to work with NPX installation
- All 23 tools remain functional
- No JSON-RPC protocol corruption
- Maintain v2.5.1 stability while fixing the one bug