---
id: 1752611812133use42svf9
timestamp: 2025-07-15T20:36:52.133Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["mcp-protocol", "json-rpc", "pitfalls", "bug-fixes", "v2.5.1", "title:1. **Console.log Breaking JSON-RPC Protocol** (CRITICAL)", "summary:- Issue: Any console.log output to stdout breaks JSON-RPC communication"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T20:36:52.133Z
metadata:
  content_type: text
  size: 1828
  mermaid_diagram: false
---Comprehensive list of MCP server pitfalls discovered and fixed in v2.5.1:

## 1. **Console.log Breaking JSON-RPC Protocol** (CRITICAL)
- **Issue**: Any console.log output to stdout breaks JSON-RPC communication
- **Fix**: Replaced all 58 console.log statements with console.error across 14 lib files
- **Affected Files**: vector-storage.js, file-system-monitor.js, and 12 others

## 2. **Node.js Path Not Found**
- **Issue**: Claude Desktop can't find 'node' command, especially with nvm installations
- **Fix**: Detect and use full Node.js executable path (process.execPath)
- **Solution**: Changed from command: 'node' to command: process.execPath

## 3. **Automatic Path Detection**
- **Issue**: Users had to manually configure memory/task paths
- **Fix**: Auto-detect existing directories in common locations:
  - Current directory, parent directories
  - User home/Documents folders
  - Common Windows paths (D:\memories, etc.)

## 4. **MCP_QUIET Environment Variable**
- **Issue**: Even stderr output can cause issues in some environments
- **Fix**: Added MCP_QUIET: 'true' to all server configurations

## 5. **Transport Timeout Issues**
- Research showed servers disconnect after ~60 seconds
- Need to ensure server stays responsive

## 6. **Error Response Format**
- Must follow JSON-RPC 2.0 error codes (-32700 to -32000)
- Must include proper error structure with code, message, data

## 7. **Sharp Module Dependency**
- Optional dependency that fails on some systems
- Server should continue without it (image processing features)

## Key MCP Protocol Requirements:
- stdout is ONLY for JSON-RPC messages
- Use stderr for all logging/debugging
- Messages must be newline-delimited
- No embedded newlines in messages
- Requests must include string/integer ID (not null)
- Either result or error must be set (not both)