---
id: 1752661240351ilv9iwj3a
timestamp: 2025-07-16T10:20:40.351Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["path-validation", "npx-compatibility", "windows-paths", "security", "file-system", "title:Summary of Path Validation Issues", "summary:1. server-markdown.js - MarkdownStorage class"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T10:20:40.351Z
metadata:
  content_type: text
  size: 3242
  mermaid_diagram: false
---COMPLETE PATH VALIDATION ANALYSIS - Like-I-Said MCP Server

## Summary of Path Validation Issues

### 1. **server-markdown.js - MarkdownStorage class**
- **Constructor**: Accepts baseDir parameter (default: 'memories')
- **getProjectDir()**: 
  - Lines 101-141: Has security checks for path traversal
  - Sanitizes project names (removes special chars, limits to 50 chars)
  - Validates that resolved project dir starts with resolved base dir
  - Windows-specific normalization (lowercases paths, replaces backslashes)
  - Creates directory if it doesn't exist

### 2. **listMemories() method** (lines 402-471)
- Creates base directory if it doesn't exist
- Has path traversal checks when listing project directories
- Validates each project directory is within the base directory

### 3. **Path Initialization** (lines 549-550)
- MEMORY_DIR initialized from: savedConfig.memoryDir || process.env.MEMORY_DIR || process.env.LIKE_I_SAID_MEMORY_DIR || 'memories'
- TASK_DIR initialized from: savedConfig.taskDir || process.env.TASK_DIR || process.env.LIKE_I_SAID_TASK_DIR || 'tasks'
- Supports multiple environment variable names for compatibility

### 4. **set_memory_path & set_task_path tools** (lines 3042-3162)
- Accept new absolute paths
- Resolve paths to absolute using path.resolve()
- Create directories if they don't exist
- Update global MEMORY_DIR/TASK_DIR variables
- Re-initialize storage instances with new paths
- Save configuration for persistence

### 5. **task-storage.js**
- getProjectFilePath(): Uses path.join with baseDir
- No explicit path validation beyond basic joins

### 6. **memory-storage-wrapper.js**
- Uses path.join throughout for file operations
- No restrictive path validation found

### 7. **CLI Installer (cli.js)**
- Detects existing memory/task directories in multiple locations
- Supports NPX mode with absolute paths
- Creates Windows-compatible path configurations
- Sets MEMORY_DIR and TASK_DIR environment variables in client configs

## Key Issues for NPX Mode

1. **Path Traversal Security**: getProjectDir() validates that project directories stay within base directory - this could be problematic if base directory is an absolute path in NPX mode

2. **Windows Path Normalization**: Special handling for Windows paths (lowercase, backslash replacement) in getProjectDir()

3. **No Hardcoded Path Restrictions**: The changelog mentions removing hardcoded path checks, but the current code still has path traversal checks

4. **Environment Variable Support**: Good - supports multiple env vars for paths

5. **Dynamic Path Changes**: set_memory_path and set_task_path allow runtime path changes

## Recommendations for NPX Compatibility

1. **Relax Path Traversal Checks**: When using absolute paths (NPX mode), the path traversal checks in getProjectDir() may be too restrictive

2. **NPX Mode Detection**: Add explicit NPX mode detection to bypass certain security checks

3. **Absolute Path Handling**: Ensure all path operations work with both relative and absolute paths

4. **Cross-Platform Path Handling**: Continue using path.resolve() and path.join() for cross-platform compatibility

5. **Configuration Persistence**: The savedConfig system properly persists custom paths across sessions