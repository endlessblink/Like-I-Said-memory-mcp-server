---
id: 1752611042653lwfky7l15
timestamp: 2025-07-15T20:24:02.653Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["release", "npm", "v2.5.0", "environment-variables", "configuration", "title:New features in v2.5.0", "summary:Successfully published Like-I-Said MCP Server v2. 0 to npm with environment variable support."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T20:24:02.653Z
metadata:
  content_type: text
  size: 747
  mermaid_diagram: false
---Successfully published Like-I-Said MCP Server v2.5.0 to npm with environment variable support.

New features in v2.5.0:
- Added support for MEMORY_DIR and TASK_DIR environment variables
- Alternative environment variable names: LIKE_I_SAID_MEMORY_DIR and LIKE_I_SAID_TASK_DIR
- Allows users to set custom memory and task directories from within Claude Desktop or IDE configuration
- Maintains backward compatibility - defaults to 'memories' and 'tasks' directories if not set

Installation command for v2.5.0:
npx -p @endlessblink/like-i-said-v2@2.5.0 like-i-said-v2 install

Users can now configure custom paths in their Claude Desktop config by adding:
"env": {
  "MEMORY_DIR": "/path/to/custom/memories",
  "TASK_DIR": "/path/to/custom/tasks"
}