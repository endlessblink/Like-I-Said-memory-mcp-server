---
id: 1752612252107psidyf29j
timestamp: 2025-07-15T20:44:12.107Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["v2.6.0", "dynamic-paths", "mcp-tools", "configuration", "title:How it works:", "summary:- Changed const to let for MEMORYDIR and TASKDIR variables"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T20:44:12.107Z
metadata:
  content_type: code
  size: 1357
  mermaid_diagram: false
---Implemented dynamic path configuration for Like-I-Said MCP Server v2.6.0!

Added three new MCP tools that allow Claude Desktop to change memory/task paths dynamically:

1. **set_memory_path** - Changes where memories are stored
   - Updates path immediately without restart
   - Creates directory if it doesn't exist
   - Saves configuration to .like-i-said-config.json
   - Re-initializes storage with new path

2. **set_task_path** - Changes where tasks are stored
   - Same functionality as memory path
   - Updates all dependent components

3. **get_current_paths** - Shows current storage locations
   - Shows active paths in use
   - Shows saved configuration
   - Shows environment variables

## How it works:
- Changed const to let for MEMORY_DIR and TASK_DIR variables
- Re-initializes storage instances when paths change
- Saves configuration to .like-i-said-config.json for persistence
- On startup, loads from: saved config → env vars → defaults

## Priority order for paths:
1. Saved configuration (.like-i-said-config.json)
2. Environment variables (MEMORY_DIR, TASK_DIR)
3. Default paths (memories, tasks)

Now Claude Desktop can change storage paths just by calling:
- set_memory_path with path: "D:\\MyNewMemories"
- set_task_path with path: "D:\\MyNewTasks"

This brings back the DXT functionality where paths could be changed dynamically!