---
id: 1752504265344zfe8f54o8
timestamp: 2025-07-14T14:44:25.345Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["MCP", "Python", "DXT", "validation", "Claude Desktop", "research", "title:Comprehensive Mcp Research Python Dxt Validation Errors", "summary:Comprehensive MCP Research Analysis: Python DXT Validation Errors"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T14:44:25.345Z
metadata:
  content_type: code
  size: 9255
  mermaid_diagram: false
---# Comprehensive MCP Research Analysis: Python DXT Validation Errors

## Research Summary

After extensive research into Model Context Protocol (MCP) specifications, Claude Desktop implementation, and Python server validation, I've identified the root causes of the Zod validation errors in Python DXT packages.

## 1. MCP Protocol Specification Requirements

### JSON-RPC 2.0 Foundation
- MCP strictly follows JSON-RPC 2.0 specification
- All messages must have: `jsonrpc: "2.0"`, `id` (string/number, NOT null), `method`
- Responses must have same ID as request, either `result` OR `error` (not both)
- Error codes must be integers

### Critical Message Formats

#### Initialize Request:
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "initialize",
  "params": {
    "protocolVersion": "2024-11-05",
    "capabilities": {
      "tools": {},
      "resources": {},
      "prompts": {}
    },
    "clientInfo": {
      "name": "Client Name",
      "version": "1.0.0"
    }
  }
}
```

#### Tools/List Response:
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "tools": [
      {
        "name": "tool_name",
        "description": "Tool description",
        "inputSchema": {
          "type": "object",
          "properties": {
            "param": {
              "type": "string",
              "description": "Parameter description"
            }
          },
          "required": ["param"]
        }
      }
    ]
  }
}
```

## 2. Root Cause Analysis of Zod Validation Errors

### "Expected string, received null" Errors
1. **Required fields missing or null**: Tool parameters marked as required but receiving null values
2. **Incorrect type annotations**: Python type hints not properly translated to JSON schema
3. **Array type issues**: Using `["string", "null"]` instead of proper Optional/Union types
4. **Missing default values**: Optional parameters without proper defaults

### "invalid_union" and "unionErrors" 
1. **Union type mismatches**: Python Union types not properly serialized to JSON schema
2. **Multiple type validation**: Zod union validation failing on multiple possible types
3. **Type coercion failures**: Automatic type conversion between Python and JSON types

### "Unrecognized key(s) in object: 'error'"
1. **Error handling format**: Python exceptions not properly formatted as JSON-RPC errors
2. **Response structure**: Mixing result and error fields in responses
3. **Error propagation**: Internal errors leaking into response format

## 3. Python Implementation Issues

### Common Validation Problems
1. **Array types in schema**: Using `["object", "null"]` instead of Python Optional types
2. **Null handling**: Not properly handling None values in required fields
3. **Type conversion**: Automatic type coercion causing validation mismatches
4. **Schema generation**: Python type hints not correctly translated to JSON schema

### FastMCP vs Standard SDK
- FastMCP provides automatic type validation and schema generation
- Standard SDK requires manual schema definition and validation
- Both can have issues with null/None value handling

## 4. Claude Desktop Specific Requirements

### DXT Package Structure
- `manifest.json` is the ONLY required file
- Must follow exact schema defined in MANIFEST.md
- User configuration fields can be marked as `"sensitive": true`
- Template literals supported: `${__dirname}`, `${user_config.key}`

### Configuration Requirements
```json
{
  "name": "extension-name",
  "version": "1.0.0",
  "server": {
    "type": "python",
    "entry_point": "server.py",
    "mcp_config": {
      "command": "python",
      "args": ["${__dirname}/server.py"],
      "env": {
        "CONFIG_VALUE": "${user_config.config_value}"
      }
    }
  },
  "user_config": {
    "config_value": {
      "type": "string",
      "title": "Configuration Value",
      "description": "Description",
      "required": true,
      "sensitive": false
    }
  }
}
```

## 5. Specific Fixes Required

### 1. Fix Python Type Annotations
```python
# Instead of JSON schema arrays
# BAD: inputSchema with ["string", "null"]
# GOOD: Use Python Optional types
from typing import Optional

@mcp.tool()
async def my_tool(
    required_param: str,              # Required, cannot be None
    optional_param: Optional[str] = None  # Optional, can be None
) -> dict:
    if optional_param is None:
        optional_param = ""  # Handle None explicitly
    return {"result": f"{required_param} {optional_param}"}
```

### 2. Fix Error Handling
```python
# Proper error handling for MCP
@app.call_tool()
async def handle_tool_call(name: str, arguments: dict) -> list:
    try:
        # Validate inputs
        if not arguments.get("required_field"):
            raise ValueError("required_field cannot be null or empty")
        
        result = process_tool(arguments)
        return [types.TextContent(type="text", text=json.dumps(result))]
    
    except Exception as e:
        # Return error in content, not as JSON-RPC error
        return [types.TextContent(
            type="text", 
            text=f"Error: {str(e)}"
        )]
```

### 3. Fix Response Format
```python
# Ensure responses follow JSON-RPC 2.0 exactly
def create_response(request_id, result=None, error=None):
    response = {
        "jsonrpc": "2.0",
        "id": request_id
    }
    
    if error:
        response["error"] = {
            "code": error.get("code", -32603),
            "message": error.get("message", "Internal error"),
            "data": error.get("data")
        }
    else:
        response["result"] = result
    
    return response
```

### 4. Fix Schema Generation
```python
# Use Pydantic for proper schema generation
from pydantic import BaseModel, Field

class ToolInput(BaseModel):
    required_string: str = Field(..., description="Required string parameter")
    optional_string: Optional[str] = Field(None, description="Optional string parameter")
    
    class Config:
        extra = "forbid"  # Reject unknown fields

@mcp.tool()
async def validated_tool(arguments: dict) -> dict:
    try:
        # Validate input with Pydantic
        validated = ToolInput(**arguments)
        
        # Process with validated data
        return {
            "status": "success",
            "data": process_data(validated.dict())
        }
    except ValidationError as e:
        return {
            "status": "error",
            "message": str(e)
        }
```

## 6. Testing and Validation

### Validation Steps
1. **Test with minimal example**: Create bare-minimum working server
2. **Validate JSON-RPC format**: Ensure all messages follow spec exactly
3. **Test error conditions**: Verify error handling doesn't break format
4. **Check null handling**: Test with None/null values in all fields
5. **Validate DXT package**: Use `dxt validate` before packaging

### Debug Logging
```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Log all requests/responses
@app.call_tool()
async def debug_tool_call(name: str, arguments: dict):
    logging.debug(f"Tool call: {name}")
    logging.debug(f"Arguments: {arguments}")
    logging.debug(f"Argument types: {[(k, type(v)) for k, v in arguments.items()]}")
    
    # Check for null values
    for key, value in arguments.items():
        if value is None:
            logging.error(f"Null value found for key: {key}")
```

## 7. Working Example Template

```python
import asyncio
import json
from typing import Optional
from mcp.server import Server
from mcp.server.stdio import stdio_server
import mcp.types as types

app = Server(name="working-example", version="1.0.0")

@app.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="echo",
            description="Echo back the input",
            inputSchema={
                "type": "object",
                "properties": {
                    "message": {
                        "type": "string",
                        "description": "Message to echo"
                    }
                },
                "required": ["message"]
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    if name == "echo":
        # Validate required field
        message = arguments.get("message")
        if message is None:
            return [types.TextContent(
                type="text",
                text="Error: message parameter is required"
            )]
        
        return [types.TextContent(
            type="text",
            text=f"Echo: {message}"
        )]
    
    raise ValueError(f"Unknown tool: {name}")

async def main():
    async with stdio_server() as (read_stream, write_stream):
        await app.run(read_stream, write_stream)

if __name__ == "__main__":
    asyncio.run(main())
```

## Conclusion

The Zod validation errors are primarily caused by:
1. Improper handling of null values in required fields
2. Incorrect JSON schema generation from Python types
3. Non-compliant JSON-RPC 2.0 message formatting
4. Poor error handling that breaks response structure

The fixes involve proper Python type annotations, explicit null handling, correct JSON-RPC formatting, and thorough validation of all inputs and outputs.