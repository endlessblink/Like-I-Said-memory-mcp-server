---
id: 1752667043713xwkwl83xs
timestamp: 2025-07-16T11:57:23.713Z
complexity: 4
project: like-i-said-mcp-server-v2
tags: ["git", "windows", "fix", "history", "clone", "maya", "title:Successfully Fixed Windows Git Clone Issues Resetting Git", "summary:Successfully fixed Windows git clone issues by resetting git history.  The root cause was a file named '."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T11:57:23.713Z
metadata:
  content_type: text
  size: 637
  mermaid_diagram: false
---Successfully fixed Windows git clone issues by resetting git history. The solution:

1. The root cause was a file named '.gitignore\r' (with carriage return) that Windows couldn't create
2. Used git checkout --orphan to create a fresh branch with no history
3. The problematic file was automatically removed when creating the orphan branch
4. Force pushed the clean history to replace the old repository

Now Maya and everyone else can successfully clone with:
git clone https://github.com/endlessblink/Like-I-Said-memory-mcp-server.git

The repository now has a single clean commit with all the code but no problematic files in history.