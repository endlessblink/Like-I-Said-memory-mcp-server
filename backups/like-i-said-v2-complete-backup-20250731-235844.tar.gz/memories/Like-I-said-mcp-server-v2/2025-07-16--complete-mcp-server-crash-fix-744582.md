---
id: 1752690744535kdyw1snu8
timestamp: 2025-07-16T18:32:24.535Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["mcp-server", "crash-fix", "implementation", "windows", "sharp-module", "vectorstorage", "title:Complete MCP Server Crash Fix Implementation", "summary:Problem Summary: The like-i-said-memory-v2 MCP server was crashing on Windows due to missing native bindings for the sharp module", "which is a trans..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T18:32:24.535Z
metadata:
  content_type: code
  size: 1611
  mermaid_diagram: false
---## Complete MCP Server Crash Fix Implementation

**Problem Summary**: The like-i-said-memory-v2 MCP server was crashing on Windows due to missing native bindings for the `sharp` module, which is a transitive dependency of `@xenova/transformers`.

**Solution Implemented**: Made VectorStorage optional by:

1. **Moved VectorStorage import to dynamic loading**:
   - Changed from static import to dynamic import with try-catch
   - Server continues without vector capabilities if sharp fails

2. **Added null checks throughout the codebase**:
   - All `vectorStorage` usage now checks if it exists first
   - Protected references in: add_memory, search_memories, create_task, set_memory_path, set_task_path
   - ConversationMonitor already had proper null handling

3. **Added informative error messages**:
   - Shows warning when vector storage fails to initialize
   - Provides command to fix: `npm install --platform=win32 --arch=x64 sharp`
   - Server continues with reduced functionality

**Files Modified**:
- `/server-markdown.js` - Made VectorStorage optional with safe null checks
- Created `/test-mcp-server-fix.js` - Test script to verify the fix
- Created `/SHARP-MODULE-FIX.md` - Documentation for users

**Testing**: The server now starts successfully without sharp module, displaying:
```
⚠️ Vector storage initialization failed (sharp module issue)
ℹ️ Running without vector search capabilities. To fix: npm install --platform=win32 --arch=x64 sharp
```

**Impact**: Users can now use the MCP server immediately without vector search, then optionally fix sharp module later for full functionality.