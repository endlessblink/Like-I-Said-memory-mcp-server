---
id: 1752523973780j2ngaytiu
timestamp: 2025-07-14T20:12:53.780Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["python-implementation", "schema-patterns", "dependencies", "validation", "architecture", "title:MCP Server Schema Patterns & Implementation Guide", "summary:Schema Structure Analysis"]
priority: high
status: reference
access_count: 0
last_accessed: 2025-07-14T20:12:53.780Z
metadata:
  content_type: code
  size: 6393
  mermaid_diagram: false
---# MCP Server Schema Patterns & Implementation Guide

## Schema Structure Analysis

### Common Schema Patterns
All 23 tools follow consistent schema patterns:

```typescript
{
  name: string,
  description: string,
  inputSchema: {
    type: 'object',
    properties: { ... },
    required?: string[]
  }
}
```

### Required Fields Summary
**Always Required**: 8 tools
- add_memory: content
- get_memory: id  
- delete_memory: id
- search_memories: query
- test_tool: message
- create_task: title, project
- update_task: task_id
- get_task_context: task_id
- delete_task: task_id
- enhance_memory_metadata: memory_id
- smart_status_update: natural_language_input
- validate_task_workflow: task_id, proposed_status
- get_automation_suggestions: task_id
- enhance_memory_ollama: memory_id

**No Required Fields**: 9 tools
- list_memories, list_tasks, generate_dropoff, batch_enhance_memories, get_task_status_analytics, batch_enhance_memories_ollama, batch_enhance_tasks_ollama, check_ollama_status, deduplicate_memories

### Enum Field Patterns
```python
# Status enums (used in 3 tools)
STATUS_ENUM = ['todo', 'in_progress', 'done', 'blocked']

# Priority enums (used in 2 tools)  
PRIORITY_ENUM = ['low', 'medium', 'high', 'urgent']

# Category enums (used in 2 tools)
CATEGORY_ENUM = ['personal', 'work', 'code', 'research']

# Time range enums (used in 1 tool)
TIME_RANGE_ENUM = ['day', 'week', 'month', 'quarter']

# Output format enums (used in 1 tool)
OUTPUT_FORMAT_ENUM = ['markdown', 'json']

# Depth enums (used in 1 tool)
DEPTH_ENUM = ['direct', 'deep']
```

### Default Values Mapping
```python
# Tools with defaults
DEFAULTS = {
    'create_task': {'priority': 'medium', 'auto_link': True},
    'generate_dropoff': {
        'session_summary': 'Session work completed',
        'include_recent_memories': True,
        'include_git_status': True, 
        'recent_memory_count': 5,
        'output_format': 'markdown',
        'output_path': None
    },
    'list_tasks': {'include_subtasks': True, 'limit': 20},
    'get_task_context': {'depth': 'direct'},
    'batch_enhance_memories': {'limit': 50, 'skip_existing': True},
    'smart_status_update': {'apply_automation': True},
    'get_task_status_analytics': {
        'time_range': 'week',
        'include_trends': True,
        'include_recommendations': True,
        'include_project_breakdown': True
    },
    'batch_enhance_memories_ollama': {
        'limit': 50,
        'skip_existing': True,
        'model': 'llama3.1:8b',
        'batch_size': 5
    },
    'batch_enhance_tasks_ollama': {
        'limit': 50,
        'skip_existing': True,
        'model': 'llama3.1:8b',
        'batch_size': 5
    },
    'check_ollama_status': {'show_models': True},
    'enhance_memory_ollama': {'force_update': False},
    'deduplicate_memories': {'preview_only': False}
}
```

## Tool Dependencies & Implementation Order

### Phase 1: Foundation (6 tools) 
**Core Memory Tools** - No dependencies, must be implemented first
1. test_tool (simplest - validation)
2. add_memory (core storage)
3. get_memory (core retrieval) 
4. list_memories (core listing)
5. search_memories (requires indexing)
6. delete_memory (core removal)

### Phase 2: Task System (6 tools)
**Task Management** - Depends on memory system for linking
1. create_task (depends on memory linking)
2. update_task (depends on task storage)
3. list_tasks (depends on task storage)
4. get_task_context (depends on memory-task linking)
5. delete_task (depends on task storage)
6. generate_dropoff (depends on memory + task systems)

### Phase 3: Enhancement (5 tools)
**Advanced Features** - Depends on both memory and task systems
1. enhance_memory_metadata (depends on memory system)
2. batch_enhance_memories (depends on memory system)
3. smart_status_update (depends on task system + NLP)
4. get_task_status_analytics (depends on task system + analytics)
5. validate_task_workflow (depends on task system + validation)

### Phase 4: Ollama Integration (3 tools)
**Local AI Processing** - Depends on Ollama server + existing systems
1. check_ollama_status (standalone Ollama check)
2. batch_enhance_memories_ollama (depends on memory + Ollama)
3. batch_enhance_tasks_ollama (depends on tasks + Ollama)

### Phase 5: Advanced Automation (3 tools)
**Complex Features** - Depends on all previous systems
1. get_automation_suggestions (depends on task analysis)
2. enhance_memory_ollama (depends on memory + Ollama)
3. deduplicate_memories (depends on memory system + file management)

## Critical Implementation Requirements

### Memory-Task Linking System
- Bidirectional connections between memories and tasks
- Content similarity analysis for auto-linking
- Relevance scoring for connection prioritization
- Support for manual override of auto-linking

### Project Organization
- All memories and tasks must support project context
- Cross-project relationships supported
- Default project handling for unassigned items

### State Management
- Task status transitions with validation
- Status change automation and suggestions
- Workflow analysis and recommendations

### Data Integrity
- File-based storage with backup systems
- Concurrent operation protection
- Graceful handling of missing/corrupted files
- Checksum validation for data integrity

### Schema Validation
- Input parameter validation against schemas
- Required field enforcement
- Enum value validation
- Type checking for all parameters

## Python Implementation Recommendations

### Base Classes
```python
class MCPTool:
    def __init__(self, name: str, description: str, schema: dict):
        self.name = name
        self.description = description
        self.schema = schema
    
    def validate_input(self, params: dict) -> bool:
        # Implement schema validation
        pass
    
    async def execute(self, params: dict) -> dict:
        # Override in subclasses
        raise NotImplementedError

class MemoryTool(MCPTool):
    # Base for memory tools
    pass

class TaskTool(MCPTool):
    # Base for task tools  
    pass
```

### Schema Validation
- Use pydantic or jsonschema for validation
- Implement enum validation helpers
- Add default value application logic
- Create type conversion utilities

### Error Handling
- Consistent error response format
- Proper HTTP status codes
- Detailed error messages for debugging
- Graceful degradation for missing dependencies