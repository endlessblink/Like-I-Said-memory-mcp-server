---
id: 1752610881175q0ox3khse
timestamp: 2025-07-15T20:21:21.175Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["environment-variables", "v2.5.0", "custom-paths", "configuration", "title:Edit `%APPDATA%\Claude\claude_desktop_config.json`", "summary:Added environment variable support in v2. 0 for custom memory and task paths."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T20:21:21.175Z
metadata:
  content_type: code
  size: 1082
  mermaid_diagram: false
---Added environment variable support in v2.5.0 for custom memory and task paths!

**Features added:**
1. **MEMORY_DIR** - Set custom memory storage location
2. **TASK_DIR** - Set custom task storage location
3. **LIKE_I_SAID_MEMORY_DIR** / **LIKE_I_SAID_TASK_DIR** - Alternative names

**Usage methods:**

**Method 1: Set before installation**
```cmd
set MEMORY_DIR=D:\MyMemories
set TASK_DIR=D:\MyTasks
npm install @endlessblink/like-i-said-v2@2.5.0
node node_modules\@endlessblink\like-i-said-v2\cli.js install
```

**Method 2: Manual Claude Desktop config**
Edit `%APPDATA%\Claude\claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "like-i-said-memory-v2": {
      "command": "node",
      "args": ["path/to/mcp-server-wrapper.js"],
      "env": {
        "MEMORY_DIR": "D:\\MyMemories",
        "TASK_DIR": "D:\\MyTasks"
      }
    }
  }
}
```

**Method 3: System-wide environment variables**
Set in Windows System Properties → Environment Variables

The server will use these paths instead of the default `memories/` and `tasks/` folders in the installation directory.