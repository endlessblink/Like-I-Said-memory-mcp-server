---
id: 1752607672280i8zjx1zls
timestamp: 2025-07-15T19:27:52.280Z
complexity: 4
project: like-i-said-mcp-server-v2
tags: ["dxt-installation", "fix-guide", "macos", "troubleshooting", "title:The guide provides three solutions", "summary:Created comprehensive DXT installation fix guide at fix-dxt-installation. md to help users resolve the "ENOENT: no such file or directory" error wh..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T19:27:52.280Z
metadata:
  content_type: text
  size: 774
  mermaid_diagram: false
---Created comprehensive DXT installation fix guide at fix-dxt-installation.md to help users resolve the "ENOENT: no such file or directory" error when installing the Like-I-Said DXT on macOS.

The guide provides three solutions:
1. **Manual extraction** - Extract DXT contents directly to Claude Extensions folder
2. **NPX installation** - Use the npm package instead of DXT
3. **Permission fixes** - Fix directory permissions if extraction worked but can't access

Also includes:
- Verification steps to confirm installation
- Troubleshooting steps for persistent issues
- Alternative manual MCP configuration for Cursor and Windsurf

This addresses the reported issue where Claude Desktop on macOS fails to properly extract or access the server/ directory from the DXT file.