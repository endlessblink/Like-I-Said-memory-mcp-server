---
id: 1752666362225glhpfmwkw
timestamp: 2025-07-16T11:46:02.225Z
complexity: 4
project: like-i-said-mcp-server-v2
tags: ["git", "windows", "fix", "clone", "checkout", "maya", "title:Solution", "summary:Fixed Windows git clone "unable to checkout working tree" error.  The root cause was a file named "."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T11:46:02.225Z
metadata:
  content_type: text
  size: 594
  mermaid_diagram: false
---Fixed Windows git clone "unable to checkout working tree" error. The root cause was a file named ".gitignore\r" (with quotes and carriage return) that was accidentally committed to the repository. 

Windows cannot create files with carriage returns in their names, causing the checkout to fail. 

Solution:
1. Removed the problematic file: git rm ".gitignore\r"
2. Added .gitattributes file to handle line endings properly
3. Committed and pushed the fix

Now the repository can be cloned successfully on Windows with:
git clone https://github.com/endlessblink/Like-I-Said-memory-mcp-server.git