---
id: 175267207244309yazb67m
timestamp: 2025-07-16T13:21:12.443Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["port-conflict", "dynamic-port-detection", "dashboard", "flowise", "windows-testing", "git-issues", "title:Dashboard Port Conflict Resolution Dynamic Port Detection", "summary:Dashboard Port Conflict Resolution & Dynamic Port Detection Implementation"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T13:21:12.443Z
metadata:
  content_type: code
  size: 3336
  mermaid_diagram: false
---# Dashboard Port Conflict Resolution & Dynamic Port Detection Implementation

## Problem Summary
User encountered JSON parsing errors when running the dashboard:
- Error: "Failed to load memories: SyntaxError: JSON.parse: unexpected character at line 1 column 1"
- Root cause: Flowise was using port 3001, preventing the API server from starting
- Dashboard was receiving HTML (Flowise page) instead of JSON from API calls

## User Requirements
- **Critical feedback**: "why can't it just automatically search for a free port?" 
- User explicitly rejected simplified workarounds: "stop with the simple versions, fix the issue"
- Wanted to test from fresh Windows installation to ensure it works for new users

## Solution Implemented

### 1. Immediate Fix
- Changed default API port from 3001 to 3002 to avoid Flowise conflict
- Updated all references in:
  - dashboard-server-bridge.js
  - vite.config.ts
  - src/App.tsx

### 2. Dynamic Port Detection System
Created automatic port detection with the following components:

#### Server Side (dashboard-server-bridge.js)
```javascript
async findAvailablePort(startPort) {
  const net = await import('net');
  
  const isPortAvailable = (port) => {
    return new Promise((resolve) => {
      const server = net.createServer();
      server.once('error', () => resolve(false));
      server.once('listening', () => {
        server.close(() => resolve(true));
      });
      server.listen(port);
    });
  };

  // Try preferred port first, then scan for available ports
  for (let port = startPort; port < startPort + 100; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  
  throw new Error(`No available ports found between ${startPort} and ${startPort + 100}`);
}
```

#### Frontend Side
- Created src/utils/apiConfig.ts for dynamic API discovery
- Created src/hooks/useApi.ts for API calls with port discovery
- Created vite-port-plugin.js to serve port information
- Updated PathConfiguration.tsx to use dynamic API discovery

### 3. Port Discovery Flow
1. Server finds available port and writes to `.dashboard-port` file
2. Vite plugin serves this port info at `/api-port` endpoint
3. Frontend discovers API port by:
   - First checking `/api-port` endpoint
   - Fallback to scanning common ports (3002, 3001, 3003-3005)
   - Cache discovered port for performance

### 4. Windows Testing Support
- Resolved git CRLF line ending issues
- Created test-windows.bat for easy testing
- Fixed git pull issues with `git config pull.rebase false`

## Key Files Created/Modified
- **New**: src/utils/apiConfig.ts - Dynamic port discovery utility
- **New**: src/hooks/useApi.ts - Custom hook for API calls
- **New**: vite-port-plugin.js - Vite plugin for port info
- **New**: test-windows.bat - Windows test script
- **Modified**: dashboard-server-bridge.js - Added port detection
- **Modified**: vite.config.ts - Updated proxy configuration
- **Modified**: src/App.tsx - Use dynamic WebSocket URL
- **Modified**: src/components/PathConfiguration.tsx - Use useApi hook

## Testing Directory
User tested on Windows at: `D:\MY PROJECTS\AI\LLM\AI Code Gen\my-builds\My MCP\like-i-said-npm-test`

## Current Status
- Port configuration changed from 3001 to 3002
- Dynamic port detection partially implemented
- Changes pushed to GitHub
- Ready for Windows testing