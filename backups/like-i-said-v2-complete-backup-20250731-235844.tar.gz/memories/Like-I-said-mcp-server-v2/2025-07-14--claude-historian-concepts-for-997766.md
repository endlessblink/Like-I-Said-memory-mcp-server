---
id: 17525219977503pm5a3yiu
timestamp: 2025-07-14T19:39:57.750Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["claude-historian", "concepts", "fuzzy-search", "query-parser", "conversation-threading", "enhancement", "title:Claude-Historian Concepts for Like-I-Said Enhancement", "summary:Key Concepts to Adapt"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T19:39:57.750Z
metadata:
  content_type: code
  size: 5369
  mermaid_diagram: false
---## Claude-Historian Concepts for Like-I-Said Enhancement

### Key Concepts to Adapt

#### 1. **Conversation Threading & Context**
Claude-Historian tracks conversation threads with parent-child relationships. We could:
- Add `conversation_id` to memories to group related discussions
- Link memories in conversation chains (problem → investigation → solution)
- Track conversation flow across sessions
- Implement "reply-to" relationships between memories

#### 2. **Temporal Search & Navigation**
- **Time-based queries**: "what did we discuss yesterday about DXT?"
- **Session continuity**: "continue from where we left off"
- **Chronological navigation**: Previous/next memory in time sequence
- **Date range filtering**: Built into search queries

#### 3. **Export & Portability**
- Export memories as structured markdown documents
- Generate conversation transcripts
- Create knowledge base snapshots
- Support for Git-based versioning of memory database

#### 4. **Advanced Search Operators**
```
before:2024-01-14 after:2024-01-10 category:code "DXT implementation"
from:session-abc to:session-xyz
near:"error message" ~10 words
has:code language:python
```

#### 5. **Memory Relationships Graph**
- Visualize memory connections as a knowledge graph
- Traverse related memories by relationship type
- Identify knowledge clusters
- Find isolated memories that need linking

### Safe Implementation Strategy

#### Phase 1: Fuse.js Integration (Low Risk)
```javascript
// Add to package.json dependencies
"fuse.js": "^7.0.0"

// Create lib/fuzzy-search.js
import Fuse from 'fuse.js';

export class FuzzySearch {
  constructor(options = {}) {
    this.fuseOptions = {
      includeScore: true,
      threshold: options.threshold || 0.3,
      keys: [
        { name: 'content', weight: 0.7 },
        { name: 'tags', weight: 0.2 },
        { name: 'metadata.searchableText', weight: 0.1 }
      ],
      ...options
    };
  }
  
  search(memories, query) {
    const fuse = new Fuse(memories, this.fuseOptions);
    return fuse.search(query);
  }
}
```

#### Phase 2: Query Parser (Medium Risk)
```javascript
// lib/advanced-query-parser.js
export class AdvancedQueryParser {
  parseQuery(query) {
    const parsed = {
      text: [],
      filters: {},
      operators: {},
      modifiers: {}
    };
    
    // Extract special operators
    const patterns = {
      before: /before:(\S+)/g,
      after: /after:(\S+)/g,
      category: /category:(\S+)/g,
      has: /has:(\S+)/g,
      language: /language:(\S+)/g,
      project: /project:"([^"]+)"|project:(\S+)/g,
      inTitle: /intitle:"([^"]+)"|intitle:(\S+)/g
    };
    
    // Parse and remove operators from query
    let cleanQuery = query;
    for (const [key, pattern] of Object.entries(patterns)) {
      let match;
      while ((match = pattern.exec(query)) !== null) {
        parsed.filters[key] = match[1] || match[2];
        cleanQuery = cleanQuery.replace(match[0], '');
      }
    }
    
    // Handle quoted phrases
    const phrases = cleanQuery.match(/"([^"]+)"/g) || [];
    parsed.text = cleanQuery.replace(/"[^"]+"/g, '').trim().split(/\s+/);
    parsed.phrases = phrases.map(p => p.replace(/"/g, ''));
    
    return parsed;
  }
}
```

#### Phase 3: Conversation Threading (Medium Risk)
```javascript
// Add to memory schema
metadata: {
  conversation_id: 'conv-uuid',
  parent_memory: 'memory-id',
  thread_position: 1,
  thread_depth: 0
}

// lib/conversation-tracker.js
export class ConversationTracker {
  constructor(storage) {
    this.storage = storage;
    this.activeConversation = null;
  }
  
  startConversation(topic) {
    this.activeConversation = {
      id: `conv-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      topic,
      startTime: Date.now(),
      memories: []
    };
    return this.activeConversation.id;
  }
  
  addToConversation(memoryId) {
    if (this.activeConversation) {
      this.activeConversation.memories.push(memoryId);
    }
  }
}
```

### Implementation Plan

#### Step 1: Add Fuse.js (Safe, Immediate)
1. Install fuse.js
2. Create FuzzySearch wrapper
3. Integrate into search pipeline alongside existing methods
4. Fall back to current search if Fuse.js fails

#### Step 2: Implement Query Parser (Safe, Isolated)
1. Create parser as separate module
2. Parse queries before sending to search methods
3. Apply filters after getting results
4. Keep backward compatibility for simple queries

#### Step 3: Add Temporal Features
1. Add timestamp indexing to memories
2. Implement date range filtering
3. Add "recent" and "today" shortcuts
4. Create timeline view in dashboard

#### Step 4: Conversation Threading
1. Add optional conversation metadata
2. Track active conversations in session
3. Link related memories automatically
4. Provide thread navigation

### Benefits Over Current System

1. **Natural Language Queries**: "show me everything about DXT from last week"
2. **Precise Filtering**: Combine fuzzy search with exact filters
3. **Context Preservation**: Maintain conversation continuity
4. **Better Discovery**: Find memories by time, not just content
5. **Export/Sharing**: Share knowledge with team members

### Risk Mitigation

- Each feature is isolated and optional
- Backward compatibility maintained
- Graceful degradation if features fail
- No changes to core storage format
- All enhancements are additive