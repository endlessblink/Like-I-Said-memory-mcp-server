---
id: 17526101336399c8hrzisu
timestamp: 2025-07-15T20:08:53.639Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["npm-fix", "v2.4.8", "critical-bug", "lib-folder", "title:**Issue found**", "summary:Critical bug fix for v2. 8 - Missing lib folder in NPM installation."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T20:08:53.639Z
metadata:
  content_type: code
  size: 795
  mermaid_diagram: false
---Critical bug fix for v2.4.8 - Missing lib folder in NPM installation!

**Issue found**: 
```
Error [ERR_MODULE_NOT_FOUND]: Cannot find module 'D:\...\lib\dropoff-generator.js'
```

The NPM installer was only copying 4 files but not the `lib` directory containing 48 essential files.

**Fix applied**:
Added code to copy the entire lib directory during installation:
```javascript
// Copy lib directory
const libSource = path.join(__dirname, 'lib');
const libDest = path.join(projectPath, 'lib');
if (fs.existsSync(libSource) && !fs.existsSync(libDest)) {
  fs.cpSync(libSource, libDest, { recursive: true });
  log('✓ Copied lib directory', 'green');
  copied++;
}
```

This was causing the "Server disconnected" error in Claude Desktop because server-markdown.js couldn't find its dependencies.