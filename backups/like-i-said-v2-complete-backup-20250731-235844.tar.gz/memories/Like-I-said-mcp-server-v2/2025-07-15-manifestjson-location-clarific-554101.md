---
id: 1752600554089ophi31uf1
timestamp: 2025-07-15T17:29:14.089Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt", "manifest", "cleanup", "claude-desktop", "title:Manifest.json location clarification", "summary:json location clarification:. json was an old/outdated file and has been safely removed."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:29:14.089Z
metadata:
  content_type: text
  size: 574
  mermaid_diagram: false
---Manifest.json location clarification:

The root manifest.json was an old/outdated file and has been safely removed. 

The actual working manifest.json is **inside the DXT file** (like-i-said-memory-v2-main.dxt). This is the correct location for DXT packages.

DXT files are zip archives that contain:
- manifest.json (at the root of the zip)
- server files
- dependencies
- configuration

The manifest inside the DXT is what Claude Desktop uses when installing the extension. The root manifest.json was not needed and was causing confusion by referencing non-existent files.