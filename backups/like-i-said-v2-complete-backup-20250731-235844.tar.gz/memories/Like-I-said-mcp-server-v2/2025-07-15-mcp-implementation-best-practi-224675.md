---
id: 1752609224662gq3i28a7l
timestamp: 2025-07-15T19:53:44.662Z
complexity: 4
project: like-i-said-mcp-server-v2
tags: ["mcp-research", "best-practices", "implementation-guide", "title:MCP Implementation Best Practices from Research", "summary:MCP Implementation Best Practices from Research:.  Server Structure Requirements:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T19:53:44.662Z
metadata:
  content_type: code
  size: 1343
  mermaid_diagram: false
---MCP Implementation Best Practices from Research:

1. **Server Structure Requirements**:
   - Must implement `ListToolsRequestSchema` handler
   - Needs proper JSON-RPC 2.0 protocol support
   - Requires initialization before tools/list works

2. **Correct Tool Registration Pattern**:
```typescript
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: "tool_name",
        description: "Tool description",
        inputSchema: {
          type: "object",
          properties: { /* ... */ },
          required: []
        }
      }
    ]
  };
});
```

3. **Claude Desktop Configuration**:
   - Config file: `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS)
   - Config file: `%APPDATA%\Claude\claude_desktop_config.json` (Windows)
   - Format:
   ```json
   {
     "mcpServers": {
       "server-name": {
         "command": "node",
         "args": ["path/to/server.js"]
       }
     }
   }
   ```

4. **Testing with MCP Inspector**:
   ```bash
   npx @modelcontextprotocol/inspector node ./server.js
   ```

5. **Common Issues Found**:
   - Server must handle initialization request before tools/list
   - inputSchema must be proper JSON Schema format
   - Transport must be StdioServerTransport for local servers
   - Server name in config must match exactly