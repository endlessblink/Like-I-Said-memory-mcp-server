---
id: 1752607618567qe61rd9tj
timestamp: 2025-07-15T19:26:58.567Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt-installation", "bug", "macos", "claude-desktop", "title:DXT Installation Issue Analysis", "summary:DXT Installation Issue Analysis:. Error reported by users:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T19:26:58.567Z
metadata:
  content_type: code
  size: 1251
  mermaid_diagram: false
---DXT Installation Issue Analysis:

**Error reported by users:**
```
ENOENT: no such file or directory, open '/Users/roeej/Library/Application Support/Claude/Claude Extensions/local.dxt.endlessblink.like-i-said-memory-v2/server/'
```

**Root cause:** The error suggests Claude Desktop is looking for a directory that doesn't exist after extraction.

**Current DXT structure verification:**
- ✅ manifest.json exists with correct entry_point: "server/mcp-server-dxt-optimized.js"
- ✅ server/ directory exists in DXT
- ✅ server/mcp-server-dxt-optimized.js exists (130KB)
- ✅ All node_modules dependencies are bundled in server/node_modules/

**Possible causes:**
1. Claude Desktop extraction issue on macOS
2. Permissions issue preventing directory creation
3. Path normalization issue between Windows-built DXT and macOS extraction

**The "Fixing Claude Script.txt" is unrelated** - it fixes Windows-MCP Python dependencies, not DXT installation issues.

**Potential solutions to investigate:**
1. Test DXT installation on macOS to reproduce issue
2. Check if server/ directory needs different permissions in DXT
3. Verify zip compression settings are compatible with macOS
4. Consider if entry_point path needs adjustment for cross-platform compatibility