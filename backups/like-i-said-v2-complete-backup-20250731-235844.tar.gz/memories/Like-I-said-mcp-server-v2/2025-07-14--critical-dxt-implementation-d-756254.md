---
id: 17525187562473t03zpm9j
timestamp: 2025-07-14T18:45:56.247Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt", "fastmcp", "json-rpc", "stdio", "solution", "critical-discovery", "python", "mcp", "title:Critical Dxt Implementation Discovery Raw Fastmcp Fails", "summary:AHA! The Critical Difference"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:45:56.247Z
metadata:
  content_type: code
  size: 1318
  mermaid_diagram: false
---## Critical DXT Implementation Discovery - Raw JSON-RPC Works, FastMCP Fails

### AHA! The Critical Difference
Found the key reason why some DXT implementations work while others fail:

### Working Implementation (Basic DXT) ✅
1. **Did NOT use FastMCP** - It was a raw JSON-RPC 2.0 implementation
2. **Read from stdin directly** - Simple `for line in sys.stdin:` loop
3. **Wrote to stdout directly** - Simple `print()` and `sys.stdout.flush()`
4. **No complex frameworks** - Just basic Python with json module

### Why FastMCP Fails in DXT ❌
FastMCP-based servers are failing because FastMCP might not be handling the stdio transport correctly in the DXT environment.

### Solution Pattern
```python
# Working approach - Direct stdio handling
import json
import sys

for line in sys.stdin:
    request = json.loads(line)
    # Process request
    response = {"jsonrpc": "2.0", "id": request["id"], "result": ...}
    print(json.dumps(response))
    sys.stdout.flush()
```

### Key Lessons
1. Keep DXT implementations simple and framework-free
2. Use direct stdio communication
3. Avoid abstractions that might interfere with Claude Desktop's communication
4. Test with basic JSON-RPC before adding complexity

This discovery explains why many sophisticated MCP servers fail in DXT while simple implementations succeed.