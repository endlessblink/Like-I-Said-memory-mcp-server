---
id: 1752519101437o5mdngepk
timestamp: 2025-07-14T18:51:41.437Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt", "working-version", "jsonrpc", "configuration", "title:dxt located at /home/endlessblink/projects/like-i-said-mc...", "summary:The working DXT file is like-i-said-v2-jsonrpc. dxt located at /home/endlessblink/projects/like-i-said-mcp-server-v2/docs/screenshots/like-i-said-v..."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:51:41.438Z
metadata:
  content_type: text
  size: 285
  mermaid_diagram: false
---The working DXT file is like-i-said-v2-jsonrpc.dxt located at /home/endlessblink/projects/like-i-said-mcp-server-v2/docs/screenshots/like-i-said-v2-jsonrpc.dxt. This is the version that successfully worked and needs to maintain all tools and connections to markdown memories and tasks.