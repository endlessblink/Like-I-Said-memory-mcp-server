---
id: 175266920921755biiz347
timestamp: 2025-07-16T12:33:29.217Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["api", "backend", "path-configuration", "express", "dashboard-server", "title:Endpoints", "summary:Path Configuration API endpoints implemented in dashboard-server-bridge.js"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T12:33:29.217Z
metadata:
  content_type: text
  size: 1446
  mermaid_diagram: false
---Path Configuration API endpoints implemented in dashboard-server-bridge.js

## Endpoints

### GET /api/paths
Returns current path configuration and validation status:
- Memory directory path, existence check, absolute path
- Task directory path, existence check, absolute path  
- Whether paths come from environment variables
- Suggested path configurations

### POST /api/paths
Updates memory and task directory paths:
- Validates both paths are provided
- Resolves paths to absolute
- Updates MemoryStorageWrapper and TaskStorage instances
- Restarts file watchers for new locations
- Persists to process.env for session persistence

## Implementation Details

### Path Validation
Uses fsPromises.access() and stat() to check:
- If path exists
- If path is a directory
- Resolves to absolute path

### Suggested Paths Helper
`getSuggestedPaths()` returns common locations:
- Claude Desktop Default: `~/memories` and `~/tasks`
- Like-I-Said Directory: `~/like-i-said-mcp/memories` and `~/like-i-said-mcp/tasks`
- Documents Folder: `~/Documents/like-i-said/memories` and `~/Documents/like-i-said/tasks`

### Key Features
- Path endpoints are public (no auth required) to allow initial setup
- Dynamic path updates without server restart
- File watcher restart on path change
- Environment variable persistence for current session

This backend implementation supports the frontend PathConfiguration component to provide complete path management.