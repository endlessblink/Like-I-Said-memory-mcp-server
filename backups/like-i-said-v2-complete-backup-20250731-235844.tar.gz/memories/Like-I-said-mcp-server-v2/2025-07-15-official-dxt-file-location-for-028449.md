---
id: 1752600028436tex50fpew
timestamp: 2025-07-15T17:20:28.436Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt", "installation", "claude-desktop", "release", "title:Official DXT file location for Like-I-Said v2", "summary:Official DXT file location for Like-I-Said v2:. Download URL: https://github."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:20:28.436Z
metadata:
  content_type: text
  size: 475
  mermaid_diagram: false
---Official DXT file location for Like-I-Said v2:

**Download URL**: https://github.com/endlessblink/Like-I-Said-memory-mcp-server/releases/latest/download/like-i-said-memory-v2.dxt

The DXT file is not stored in the repository but is published as a release artifact on GitHub. Users download it directly from the releases page for Claude Desktop installation.

This is the recommended installation method for Claude Desktop users - just download and double-click the .dxt file.