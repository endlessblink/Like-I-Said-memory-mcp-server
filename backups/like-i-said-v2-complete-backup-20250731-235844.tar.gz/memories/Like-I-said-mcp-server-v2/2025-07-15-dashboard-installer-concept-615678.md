---
id: 1752568615660lysy814wg
timestamp: 2025-07-15T08:36:55.661Z
complexity: 4
category: research
project: like-i-said-mcp-server-v2
tags: ["dashboard-installer", "embedded-nodejs", "electron", "tauri", "title:BENEFITS", "summary:Dashboard Installer Concept - Embedded Node. User suggestion: Create a standalone installer for the dashboard with embedded Node."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T08:36:55.661Z
metadata:
  content_type: text
  size: 796
  mermaid_diagram: false
---Dashboard Installer Concept - Embedded Node.js

User suggestion: Create a standalone installer for the dashboard with embedded Node.js

BENEFITS:
1. No Node.js installation required
2. True one-click installation experience
3. Professional desktop application feel
4. Consistent environment across all users
5. No PATH or npm issues

OPTIONS TO RESEARCH:
1. Electron - Full app with embedded Chromium + Node.js
2. Tauri - Lighter, uses system webview + embedded runtime
3. pkg/nexe - Bundle Node.js with the app
4. NSIS/Inno Setup - Windows installer with embedded Node.js
5. Neutralino - Lightweight alternative to Electron

CONSIDERATIONS:
- File size (Electron ~50-100MB, Tauri ~10-20MB)
- Cross-platform support needed
- Auto-update mechanism
- System tray integration
- Native OS integration