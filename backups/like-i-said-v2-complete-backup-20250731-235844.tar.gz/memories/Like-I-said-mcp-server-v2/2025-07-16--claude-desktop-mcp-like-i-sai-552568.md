---
id: 1752698551466o6lvvlzho
timestamp: 2025-07-16T20:42:31.466Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["claude-desktop", "json-rpc", "protocol-corruption", "npx", "windows", "mcp-quiet", "unicode-error", "title:Claude Desktop MCP Like-I-Said Failure - JSON Parse Error", "summary:Claude Desktop MCP Like-I-Said Failure - JSON Parse Error. - Command: npx -y @endlessblink/like-i-said-v2@latest like-i-said-v2 start."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T20:42:31.466Z
metadata:
  content_type: text
  size: 1032
  mermaid_diagram: false
---## Claude Desktop MCP Like-I-Said Failure - JSON Parse Error

**Error Details:**
- Command: `npx -y @endlessblink/like-i-said-v2@latest like-i-said-v2 start`
- Error: `Unexpected token '�', "�� More in"... is not valid JSON`
- Environment: Claude Desktop on Windows
- Environment Variables:
  - MEMORY_DIR=C:\Users\endle\memories
  - TASK_DIR= (empty)
  - MCP_QUIET=true
  - NO_COLOR=1

**Problem Analysis:**
This is the exact JSON-RPC protocol corruption issue we've seen before. The error indicates that non-JSON content (likely console output with Unicode characters or ANSI codes) is being sent to stdout, corrupting the JSON-RPC communication.

**Root Cause:**
Despite MCP_QUIET=true and NO_COLOR=1 environment variables, there's still output pollution happening, likely from:
1. NPM/NPX installation messages
2. Dependencies outputting to stdout
3. Unicode characters in console output

**Next Steps:**
Need to implement the npx-clean-wrapper solution or switch to the Python DXT alternative that bypasses this issue entirely.