---
id: 1752568298099amcoyz77o
timestamp: 2025-07-15T08:31:38.099Z
complexity: 3
category: code
project: like-i-said-mcp-server-v2
tags: ["batch-files", "dashboard-launcher", "windows", "title:Created batch files for easy dashboard launching", "summary:Created batch files for easy dashboard launching:. bat - Full-featured with auto-install."]
priority: medium
status: active
access_count: 0
last_accessed: 2025-07-15T08:31:38.099Z
metadata:
  content_type: text
  size: 340
  mermaid_diagram: false
---Created batch files for easy dashboard launching:

1. start-dashboard.bat - Full-featured with auto-install
2. start-dashboard-dev.bat - Development mode from source
3. start-dashboard-simple.bat - Minimal launcher

These allow creating desktop shortcuts to launch the Like-I-Said dashboard from anywhere on Windows without manual commands.