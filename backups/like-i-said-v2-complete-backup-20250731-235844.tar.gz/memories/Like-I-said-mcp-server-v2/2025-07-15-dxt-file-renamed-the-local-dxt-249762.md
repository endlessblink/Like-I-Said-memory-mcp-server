---
id: 1752600249749r00lgjram
timestamp: 2025-07-15T17:24:09.749Z
complexity: 3
category: code
project: like-i-said-mcp-server-v2
tags: ["dxt", "file-rename", "claude-desktop", "title:Dxt File Local Dxt File Renamed From", "summary:DXT file renamed: The local DXT file has been renamed from like-i-said-memory-v2-FINAL-WORKING. dxt to like-i-said-memory-v2-main."]
priority: medium
status: active
access_count: 0
last_accessed: 2025-07-15T17:24:09.749Z
metadata:
  content_type: text
  size: 240
  mermaid_diagram: false
---DXT file renamed: The local DXT file has been renamed from `like-i-said-memory-v2-FINAL-WORKING.dxt` to `like-i-said-memory-v2-main.dxt`

This is the main DXT file in the repository root that should be used for Claude Desktop installations.