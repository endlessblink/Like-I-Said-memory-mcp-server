---
id: 1752518195802wazy9xo12
timestamp: 2025-07-14T18:36:35.802Z
complexity: 4
category: development
project: like-i-said-mcp-server-v2
tags: ["python", "dxt", "builds", "summary", "mcp", "claude-desktop", "title:Three DXT builds created to solve disconnection issue:", "summary:Complete Python MCP DXT Build Summary. Three DXT builds created to solve disconnection issue:."]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T18:36:35.802Z
metadata:
  content_type: text
  size: 1309
  mermaid_diagram: false
---Complete Python MCP DXT Build Summary

**Three DXT builds created to solve disconnection issue:**

1. **like-i-said-v2-exact-comfy.dxt** (21.0 MB)
   - Exactly mimics working comfy-guru DXT structure
   - Uses standalone_mcp_server.py entry point
   - Auto-installs dependencies if missing
   - Debug logging to stderr
   - Dependencies pre-installed in server/lib/
   - Most likely to work since comfy-guru works

2. **like-i-said-v2-working-v3.dxt** (12.1 MB)
   - Minimal approach with critical fixes
   - Fixed python311._pth file for module loading
   - Simple direct main.py entry point
   - No async wrappers or complex error handling
   - Direct mcp.run() call

3. **like-i-said-v2-robust.dxt** (31.7 MB)
   - Full debugging and error handling
   - Complete dependency installation with sub-deps
   - Multiple path fixes (._pth and sitecustomize.py)
   - PYTHONPATH environment variable
   - Extensive debug logging

**Key learnings from research:**
- Embedded Python needs explicit path configuration
- Simple entry points work better than complex wrappers
- FastMCP handles stdio automatically with mcp.run()
- Debug logging to stderr helps diagnose issues
- Working examples (comfy-guru) provide the best template

**Next steps:** Test each build in Claude Desktop to identify which approach works.