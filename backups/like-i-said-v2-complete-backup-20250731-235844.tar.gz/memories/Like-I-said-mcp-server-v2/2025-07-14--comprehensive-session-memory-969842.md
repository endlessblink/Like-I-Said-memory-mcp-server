---
id: 1752503969827jvyit1o5c
timestamp: 2025-07-14T14:39:29.827Z
complexity: 4
category: work
project: Like-I-said-mcp-server-v2
tags: ["dxt", "windows", "debugging", "crisis", "solution", "title:Comprehensive Session Memory: DXT Windows Debugging Crisis", "summary:Critical Problem Status:"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-14T14:39:29.827Z
metadata:
  content_type: code
  size: 1466
  mermaid_diagram: false
---## Comprehensive Session Memory: DXT Windows Debugging Crisis

### Critical Problem Status:
**ALL Node.js DXT packages are failing on Windows** - This is a fundamental compatibility issue, not a code problem.

### What We Discovered:
1. **Node.js DXT Path Resolution Broken**: The `${__dirname}` template doesn't work properly for Node.js in Claude Desktop on Windows
2. **Python DXTs Work**: Because Python's path handling with `os.path.abspath(__file__)` and `sys.path.insert()` is more robust
3. **Core Issue**: Windows path extraction in Claude Desktop fails for Node.js module resolution

### Versions Created and Tested (All Failed):
- v2.4.6: CMD Wrapper - FAILED
- v2.4.7: Bundled Dependencies - FAILED  
- v2.4.8: Minimal - FAILED
- v2.4.9: Working Pattern (${__dirname}) - FAILED
- v2.5.0: Flat Structure - FAILED
- v2.5.1: Batch Entry Point - FAILED
- v2.5.2: NPX Global - Not tested yet

### Error Pattern:
```
ENOENT: no such file or directory
Path: C:\Users\endle\AppData\Roaming\Claude\Claude Extensions\local.dxt.endlessblink.like-i-said-memory-v2\server\index.js
```

### Solution Provided:
Created `MANUAL-WINDOWS-SETUP.md` for guaranteed working installation:
1. `npm install -g @endlessblink/like-i-said-v2`
2. Manual Claude Desktop config
3. Bypasses DXT entirely

### Key Insight:
Python DXTs work because Python's import system can adapt to any extraction location, while Node.js requires rigid directory structures that DXT extraction breaks.