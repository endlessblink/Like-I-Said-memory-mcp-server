---
id: 17523457737843q2pmqagq
timestamp: 2025-07-12T18:42:53.785Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["task-counter", "ui", "navigation", "tasks", "filter", "completed-tasks", "title:Task Counter Fix - Exclude Completed Tasks", "summary:ter Fix - Exclude Completed Tasks\n\nSuccessfully fixed the task cou. ly show active tasks (excludi"]
priority: medium
status: active
access_count: 0
last_accessed: 2025-07-12T18:42:53.785Z
metadata:
  content_type: code
  size: 1905
  mermaid_diagram: false
---## Task Counter Fix - Exclude Completed Tasks

Successfully fixed the task counter in the navigation bar to only show active tasks (excluding completed tasks).

### Problem
- Task counter was showing total task count including completed tasks
- Users wanted to see only active/pending tasks in the counter
- Category counts also included completed tasks

### Solution Implemented

**1. Added Active Task Calculation**
```typescript
// Calculate active tasks (exclude 'done' status)
const activeTasks = tasks.filter(task => task.status !== 'done')
const activeTaskCount = activeTasks.length
```

**2. Updated Navigation Task Counter**
```tsx
// Changed from tasks.length to activeTaskCount
<span className="text-sm font-bold text-foreground">
  {activeTaskCount}
</span>
```

**3. Updated Category Counts**
- Modified "All Tasks" category to use `activeTasks.length`
- Updated category filters to exclude done tasks:
  - Personal: `task.category === "personal" && task.status !== "done"`
  - Work: `task.category === "work" && task.status !== "done"`
  - Code: `task.category === "code" && task.status !== "done"`
  - Research: `task.category === "research" && task.status !== "done"`
- Status categories (Todo, In Progress, Done, Blocked) remain unchanged

### Technical Details

**File Modified:** `/src/App.tsx`

**Key Changes:**
1. Added `activeTasks` and `activeTaskCount` calculations before render
2. Updated task counter display to use `activeTaskCount`
3. Modified category count filters to exclude completed tasks
4. Preserved "Done" category to still show completed task count

### Results
- Navigation bar now shows only active task count
- Category filters show accurate counts of non-completed tasks
- Better user experience with clearer task metrics
- Build successful, all tests pass

The task counter now provides more meaningful information by focusing on tasks that still need attention.