---
id: 1752575567678j6lbgz9uu
timestamp: 2025-07-15T10:32:47.679Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["universal-system", "work-pattern-detection", "multi-domain", "auto-capture", "architecture", "title:Universal Work Pattern Detection System", "summary:Universal Work Pattern Detection System"]
priority: urgent
status: active
access_count: 0
last_accessed: 2025-07-15T10:32:47.679Z
metadata:
  content_type: code
  size: 7862
  mermaid_diagram: false
---## Universal Work Pattern Detection System

### The Real Problem
Current MCP server enhancement plan was too narrow - focused only on ComfyUI troubleshooting instead of creating a universal system that detects and captures ANY type of significant work automatically.

### Universal Work Patterns to Detect

#### 1. Problem-Solving Sessions
- **Any domain**: Software issues, configuration problems, debugging, installation failures
- **Indicators**: Error messages, retry attempts, multiple solution attempts, frustration signals
- **Auto-capture**: Problem description, attempts made, working solution, context

#### 2. Implementation & Development Work
- **Any language/framework**: Python, JavaScript, React, Node.js, Docker, etc.
- **Indicators**: Code creation, file modifications, build processes, testing
- **Auto-capture**: What was built, files involved, purpose, key decisions

#### 3. Configuration & Setup Work
- **Any system**: Servers, databases, APIs, development environments, tools
- **Indicators**: Settings changes, installation procedures, authentication setup
- **Auto-capture**: Working configurations, setup steps, gotchas encountered

#### 4. Research & Discovery Sessions
- **Any topic**: Technical research, tool evaluation, learning new systems
- **Indicators**: Multiple searches, documentation reading, testing different approaches
- **Auto-capture**: Findings, useful resources, conclusions, recommendations

#### 5. Workflow & Process Development
- **Any context**: Build scripts, automation, deployment procedures, maintenance tasks
- **Indicators**: Script creation, process documentation, step-by-step procedures
- **Auto-capture**: Complete workflows, dependencies, troubleshooting steps

### Universal Detection Patterns

#### Activity Sequence Patterns
```javascript
// Universal patterns that indicate significant work
const universalPatterns = {
  problemSolving: {
    indicators: ['error', 'failed', 'not working', 'issue', 'problem'],
    sequence: ['search', 'try', 'test', 'retry', 'success'],
    threshold: 3 // 3+ attempts indicates significant work
  },
  implementation: {
    indicators: ['create', 'build', 'implement', 'develop', 'write'],
    sequence: ['plan', 'code', 'test', 'deploy', 'verify'],
    threshold: 2 // 2+ files or significant code changes
  },
  configuration: {
    indicators: ['setup', 'configure', 'install', 'settings', 'auth'],
    sequence: ['install', 'configure', 'test', 'troubleshoot', 'working'],
    threshold: 1 // Any working configuration is significant
  },
  research: {
    indicators: ['how to', 'what is', 'best way', 'compare', 'evaluate'],
    sequence: ['search', 'read', 'test', 'compare', 'conclude'],
    threshold: 5 // 5+ searches indicates research session
  }
};
```

#### Time-Based Detection
```javascript
const timeThresholds = {
  quickTask: 5 * 60 * 1000,     // 5 minutes - simple operations
  significantWork: 15 * 60 * 1000, // 15 minutes - worth capturing
  majorSession: 30 * 60 * 1000,    // 30 minutes - definitely capture
  extended: 60 * 60 * 1000         // 1 hour - create detailed summary
};
```

#### Content Analysis Patterns
```javascript
const contentPatterns = {
  technical: /\b(error|exception|failed|config|setup|install|debug|fix|solution)\b/i,
  implementation: /\b(create|build|implement|develop|write|code|function|class)\b/i,
  success: /\b(working|success|fixed|solved|completed|done|resolved)\b/i,
  frustration: /\b(still|again|why|how|can't|won't|not working|failed again)\b/i,
  discovery: /\b(found|discovered|realized|learned|turns out|figured out)\b/i
};
```

### Universal Auto-Capture System

#### 1. Context-Aware Session Tracking
```javascript
class UniversalSessionTracker {
  constructor() {
    this.sessions = new Map(); // Track multiple concurrent sessions
    this.globalContext = {
      currentDomain: 'unknown',
      workType: 'general',
      complexity: 'low',
      importance: 'medium'
    };
  }
  
  detectWorkPattern(activity) {
    // Analyze any activity to determine work pattern
    const pattern = this.classifyActivity(activity);
    const session = this.getOrCreateSession(pattern.domain);
    
    session.addActivity(activity);
    
    if (this.shouldCapture(session)) {
      this.createUniversalMemory(session);
    }
  }
}
```

#### 2. Multi-Domain Intelligence
```javascript
class MultiDomainDetector {
  domains = {
    'software-development': {
      keywords: ['code', 'programming', 'development', 'software', 'app'],
      tools: ['git', 'npm', 'pip', 'docker', 'kubernetes'],
      patterns: ['build', 'test', 'deploy', 'debug']
    },
    'system-administration': {
      keywords: ['server', 'network', 'database', 'security', 'backup'],
      tools: ['ssh', 'nginx', 'apache', 'mysql', 'postgres'],
      patterns: ['configure', 'monitor', 'troubleshoot', 'optimize']
    },
    'data-science': {
      keywords: ['data', 'analysis', 'machine learning', 'ai', 'model'],
      tools: ['python', 'jupyter', 'pandas', 'tensorflow', 'pytorch'],
      patterns: ['analyze', 'train', 'evaluate', 'visualize']
    },
    'content-creation': {
      keywords: ['content', 'writing', 'design', 'media', 'documentation'],
      tools: ['markdown', 'html', 'css', 'photoshop', 'video'],
      patterns: ['create', 'edit', 'publish', 'review']
    }
  };
  
  detectDomain(context) {
    // Analyze context to determine work domain
    return this.scoreDomains(context);
  }
}
```

#### 3. Universal Memory Template
```javascript
class UniversalMemoryCreator {
  createMemory(session) {
    return {
      title: this.generateTitle(session),
      content: this.formatContent(session),
      metadata: {
        domain: session.domain,
        workType: session.workType,
        complexity: session.complexity,
        duration: session.duration,
        outcome: session.outcome,
        tools: session.toolsUsed,
        patterns: session.patternsDetected
      },
      tags: this.generateTags(session),
      category: this.mapToCategory(session.domain),
      priority: this.calculatePriority(session)
    };
  }
}
```

### Integration Strategy

#### Hook into All MCP Tools
```javascript
// Universal activity tracking in server-markdown.js
const universalTracker = new UniversalSessionTracker();

// Add to every MCP tool handler:
function trackActivity(toolName, args, result) {
  universalTracker.detectWorkPattern({
    tool: toolName,
    input: args,
    output: result,
    timestamp: Date.now(),
    success: !result.error
  });
}
```

#### Real-Time Pattern Recognition
```javascript
// Continuous monitoring system
class RealTimeMonitor {
  constructor() {
    this.activePatterns = new Map();
    this.patternHistory = [];
    this.contextBuffer = [];
  }
  
  processActivity(activity) {
    this.contextBuffer.push(activity);
    this.updatePatterns();
    this.checkCaptureConditions();
  }
  
  updatePatterns() {
    // Analyze recent activities for emerging patterns
    // Update active pattern tracking
    // Predict when capture should occur
  }
}
```

### Expected Universal Behaviors

#### Automatic Detection Examples
- **Any troubleshooting**: Docker issues, Python errors, Network problems, etc.
- **Any implementation**: Building APIs, Creating scripts, Setting up databases, etc.
- **Any configuration**: Server setup, Tool configuration, Environment setup, etc.
- **Any research**: Technology evaluation, Learning new tools, Comparing options, etc.

#### Smart Capture Decisions
- **Complexity scoring**: Simple tasks ignored, complex ones captured
- **Outcome detection**: Failed attempts vs successful solutions
- **Context preservation**: Full conversation flow maintained
- **Cross-session linking**: Related work across multiple sessions

This creates a truly universal system that adapts to any type of work, not just specific domains like ComfyUI.