---
id: 1752344817246o37qy37v2
timestamp: 2025-07-12T18:26:57.246Z
complexity: 4
category: code
project: like-i-said-mcp-server-v2
tags: ["tutorial","popup","positioning","viewport","responsive","ui-fix","title:Tutorial Popup Cutoff Fix","summary:Tutorial Popup Cutoff Fix\n\nFixed the tutorial popup bei. g cut off at viewport edges as show"]
priority: medium
status: active
access_count: 0
last_accessed: 2025-07-12T18:26:57.246Z
metadata:
  content_type: code
  size: 2053
  mermaid_diagram: false
---
## Tutorial Popup Cutoff Fix

Fixed the tutorial popup being cut off at viewport edges as shown in the screenshot. The issue was that the tutorial tooltip wasn't checking viewport boundaries when positioning itself.

### Problem
- Tutorial popup was positioned beyond the right edge of the viewport
- No boundary checking in positioning logic
- Fixed width tooltip (320px) could exceed small screens
- User reported: "tutorial popup is being cut off"

### Solution Implemented

**1. Smart Viewport Boundary Checking**
- Added dynamic calculations for tooltip width: `Math.min(320, window.innerWidth - 40)`
- Implemented boundary checks for all positioning cases (top, bottom, left, right)
- Added 20px safety margins from viewport edges

**2. Responsive Tooltip Width**
- Changed CSS from `max-w-sm` to `max-w-[calc(100vw-40px)]`
- Ensures tooltip never exceeds viewport width minus 40px margin
- Maintains 320px width (w-80) on larger screens

**3. Enhanced Positioning Logic**
- **Bottom position**: Checks if tooltip would extend beyond right edge, adjusts X position
- **Top position**: Similar horizontal boundary checking
- **Right position**: Switches to left side if no room, with fallback positioning
- **All positions**: Prevent tooltip from going outside viewport bounds

### Technical Implementation

**OnboardingTutorial.tsx changes:**
```typescript
// Dynamic width calculation
const tooltipWidth = Math.min(320, window.innerWidth - 40)
const margin = 20 // Safety margin

// Boundary checking example (bottom position)
if (bottomX + tooltipWidth/2 > window.innerWidth - margin) {
  bottomX = window.innerWidth - margin - tooltipWidth/2
}
```

**CSS changes:**
```jsx
className="w-80 max-w-[calc(100vw-40px)] bg-gray-800..."
```

### Testing Results
- Build completed successfully
- All tests pass (17/17)
- Tutorial popup now stays within viewport bounds
- Works correctly on different screen sizes
- No visual cutoffs on the right edge

The tutorial popup now positions intelligently within viewport boundaries and adapts to screen size.