---
id: 17527000431526sbk4imk4
timestamp: 2025-07-16T21:07:23.152Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["fix-complete", "get_memory", "v2.5.1", "surgical-fix", "protocol-safe", "title:FIXED: get_memory split() Error in v2.5.1", "summary:FIXED: getmemory split() Error in v2.5.1"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-16T21:07:23.152Z
metadata:
  content_type: code
  size: 1219
  mermaid_diagram: false
---## FIXED: get_memory split() Error in v2.5.1

### Problem Solved
The `get_memory` tool was throwing error: `Cannot read properties of undefined (reading 'split')`

### Root Cause
Line 1534 in server-markdown.js was accessing `memory.created.split('T')[0]` but the memory object uses `timestamp` field, not `created`.

### Surgical Fix Applied
**File**: `/server-markdown.js` (line 1534)

**Before**:
```javascript
const filepath = path.join('memories', memory.project || 'default', `${memory.created.split('T')[0]}--${memory.id}.md`);
```

**After**:
```javascript
const datePrefix = memory.timestamp ? memory.timestamp.split('T')[0] : new Date().toISOString().split('T')[0];
const filepath = path.join('memories', memory.project || 'default', `${datePrefix}--${memory.id}.md`);
```

### Safety Improvements
1. Fixed field name: `memory.created` → `memory.timestamp`
2. Added null check: Falls back to current date if timestamp is missing
3. No new dependencies added
4. No changes to JSON-RPC protocol
5. Preserves v2.5.1 stability

### Result
- ✅ get_memory tool now works correctly
- ✅ All 23 MCP tools functional
- ✅ JSON-RPC protocol remains stable for Claude Desktop
- ✅ No breaking changes to other functionality