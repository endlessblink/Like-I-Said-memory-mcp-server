---
id: 17526012995578duxex6k8
timestamp: 2025-07-15T17:41:39.557Z
complexity: 4
category: code
project: Like-I-said-mcp-server-v2
tags: ["windows-installer", "critical-files", "cleanup-reference", "dashboard", "title:ESSENTIAL FILES TO KEEP:", "summary:Core Executable and Launcher"]
priority: high
status: active
access_count: 0
last_accessed: 2025-07-15T17:41:39.557Z
metadata:
  content_type: text
  size: 2018
  mermaid_diagram: false
---Critical files and folders required for Windows Dashboard Installer (dist-final-working):

## ESSENTIAL FILES TO KEEP:

### Core Executable and Launcher
- **dashboard.exe** - Main Windows executable (36MB) with embedded Node.js 18
- **test-dashboard.bat** - Test launcher batch file
- **dashboard-server-bridge.js** - Express API server that bridges dashboard to file system

### Configuration Files
- **manifest.json** - DXT manifest for installer metadata (required for DXT builds)
- **dashboard-config.json** - Stores user's memory/task path preferences

### Library Dependencies (lib/ folder)
All 48 files in lib/ are REQUIRED by dashboard-server-bridge.js:
- memory-format.js, memory-storage-wrapper.js (memory operations)
- task-storage.js, task-format.js (task operations)
- file-system-monitor.js (real-time updates)
- system-safeguards.js, connection-protection.cjs (data protection)
- dropoff-generator.js, title-summary-generator.js (utilities)
- And all other lib/*.js files

### React Dashboard Build
- **dist/** folder - Contains built React app (index.html + assets/)

### Data Directories
- **data/** - Settings storage (settings.json)
- **logs/** - Dashboard operation logs
- **vectors/** - Vector embeddings for search

## FILES THAT CAN BE REMOVED:

### Redundant/Backup Files
- **"dist backup"/** folder - Complete backup copy (not needed after verification)
- **package-lock.json** - Not needed for standalone executable
- **README-FINAL-WORKING.md** - Development notes (not needed for distribution)

### Auto-generated Files
- **data-backups/** - Auto-created on dashboard startup
- Old log files in logs/ (keep directory, remove old logs)

## IMPORTANT NOTES:
1. The dashboard.exe reads from current directory structure
2. lib/ folder MUST be at same level as dashboard-server-bridge.js
3. dist/ folder contains the React frontend served by the API
4. manifest.json is only needed if building DXT packages
5. Never delete the core directories (lib/, dist/, data/, logs/, vectors/) even if empty