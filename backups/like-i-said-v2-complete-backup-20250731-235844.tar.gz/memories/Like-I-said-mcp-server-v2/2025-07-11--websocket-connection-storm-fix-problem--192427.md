---
id: 1752246192427kwmfkq3g8jh
timestamp: 2025-07-11T15:03:12.428Z
complexity: 4
project: like-i-said-mcp-server-v2
tags: ["websocket", "bug-fix", "connection-storm", "api", "performance"]
priority: medium
status: active
access_count: 0
last_accessed: 2025-07-11T15:03:12.428Z
metadata:
  content_type: code
  size: 3329
  mermaid_diagram: false
---# WebSocket Connection Storm Fix

## Problem Description
The application was experiencing a critical issue where WebSocket connections were creating a connection storm, resulting in "Insufficient resources" errors. This prevented the API from functioning properly and caused memories to fail loading in the UI.

## Root Cause Analysis
The WebSocket reconnection logic in both `App.tsx` and `useQualityStandards.ts` was too aggressive:
- Attempted to reconnect immediately on any error without delay
- Did not properly check connection state before attempting reconnection
- Could create multiple simultaneous connection attempts
- Reconnected even on normal closures

## Solution Implemented

### Key Changes:
1. **Connection State Validation**: Added checks for both OPEN (1) and CONNECTING (0) states to prevent multiple simultaneous connections
2. **Increased Reconnection Delay**: Changed from 10 seconds to 30 seconds to reduce server load
3. **Selective Reconnection**: Only reconnect on abnormal closures (not codes 1000 or 1001)
4. **Cleanup on Manual Close**: Clear onclose handler before manual close to prevent reconnection loops

### Code Changes:

#### App.tsx WebSocket Connection:
```typescript
// Before reconnecting, check if already connected or connecting
if (wsRef.current?.readyState === WebSocket.OPEN || 
    wsRef.current?.readyState === WebSocket.CONNECTING) {
  return;
}

// Only reconnect on abnormal closures
ws.onclose = (event) => {
  console.log("WebSocket closed:", event.code, event.reason);
  setIsConnected(false);
  
  // Only attempt reconnect on abnormal closures
  if (event.code !== 1000 && event.code !== 1001) {
    reconnectTimeoutRef.current = setTimeout(() => {
      connectWebSocket();
    }, 30000); // Increased from 10s to 30s
  }
};

// Clear handler before manual close
if (wsRef.current) {
  wsRef.current.onclose = null;
  wsRef.current.close();
}
```

#### useQualityStandards.ts WebSocket Connection:
```typescript
// Same pattern applied:
// - Check CONNECTING state in addition to OPEN
// - Increased reconnection delay to 30s
// - Only reconnect on abnormal closures
// - Clear onclose handler before manual close
```

## Files Modified
- `/src/App.tsx` - Main WebSocket connection for real-time updates
- `/src/hooks/useQualityStandards.ts` - Quality standards WebSocket connection

## Impact and Results
- ✅ Eliminated "Insufficient resources" errors
- ✅ Fixed memory loading issues in the UI
- ✅ Prevented resource exhaustion on the API server
- ✅ Improved overall application stability
- ✅ Reduced server load from excessive reconnection attempts

## Technical Details
- WebSocket readyState values: 0=CONNECTING, 1=OPEN, 2=CLOSING, 3=CLOSED
- Normal closure codes: 1000 (normal closure), 1001 (going away)
- Abnormal closures trigger reconnection with 30-second delay
- Connection state checks prevent concurrent connection attempts

## Lessons Learned
1. Always check WebSocket state before attempting operations
2. Include CONNECTING state in connection checks, not just OPEN
3. Implement exponential backoff or reasonable delays for reconnection
4. Distinguish between normal and abnormal connection closures
5. Clean up event handlers before manual disconnection to prevent loops