# Perplexity Prompt: Debug JSON Parse Error with Unicode Character

## Problem Description

I'm experiencing a JSON parsing error in a React dashboard application with the following specific error:

```
Unexpected token '�', "📖 More in"... is not valid JSON
```

## Technical Context

- **Frontend**: React 18.2.0 with TypeScript
- **Backend**: Express.js API server
- **Error Location**: `JSON.parse()` at line 309 in App.tsx
- **API Endpoint**: `/api/memories` 
- **Expected Response**: JSON array or paginated JSON object with `data` array
- **Actual Error**: Unicode replacement character (�) followed by emoji (📖)

## Code Context

```typescript
// App.tsx - Where error occurs
const response = await apiGet(`/api/memories?page=${page}&limit=100`)
const text = await response.text()
const data = JSON.parse(text) // Error happens here
```

## Symptoms

1. API works fine with curl: `curl -s http://localhost:3002/api/memories` returns valid JSON
2. Browser fetch fails with JSON parse error mentioning "📖 More in"
3. Error suggests non-JSON content is being returned, possibly HTML or corrupted text
4. The � character indicates encoding issues or binary data

## What I Need

1. **Common causes** for this specific error pattern (� followed by emoji in JSON parse)
2. **Debugging techniques** to identify where non-JSON content enters the response
3. **Browser vs curl differences** that could cause this discrepancy
4. **Encoding issues** that could transform valid JSON into corrupted text
5. **Middleware or proxy issues** that might inject content into responses
6. **CORS or security headers** that could cause response corruption
7. **Step-by-step debugging approach** to isolate the problem

## Additional Information

- The backend is returning proper JSON when tested directly
- The error only occurs in the browser environment
- The "📖 More in" text doesn't appear in our codebase
- We're using `response.text()` before parsing to inspect the raw response

Please provide a comprehensive solution focusing on:
- How to trace where the non-JSON content is coming from
- Tools and techniques to debug response corruption
- Common Express.js middleware that might cause this
- Browser-specific issues that could inject content into responses