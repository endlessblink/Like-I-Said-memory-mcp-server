# NPX MCP Server Configuration for Claude Desktop - Cross-Platform Solution

## Problem Context

I have an MCP (Model Context Protocol) server published as an NPM package (@endlessblink/like-i-said-v2) that users install via NPX. The installation command is:

```bash
npx @endlessblink/like-i-said-v2 like-i-said-v2 install
```

This should configure Claude Desktop to use the MCP server, but I'm getting the error:
```
Unexpected token '�', "📖 More in"... is not valid JSON
```

This happens because the CLI is outputting help text instead of starting the MCP server properly.

## Current Setup

1. **Package structure:**
   - `cli.js` - Main CLI entry point
   - `mcp-quiet-wrapper.js` - Wrapper that filters output to only JSON-RPC
   - `server-markdown.js` - Actual MCP server
   - Published as: `@endlessblink/like-i-said-v2`

2. **NPX installation flow:**
   - User runs: `npx @endlessblink/like-i-said-v2 like-i-said-v2 install`
   - NPX downloads package to temporary directory (e.g., ~/.npm/_npx/...)
   - CLI detects NPX mode via: `__dirname.includes('npm-cache/_npx')`
   - CLI should configure Claude Desktop config.json

3. **The issue:**
   - When Claude Desktop starts the server, it's showing help text ("📖 More in...")
   - This breaks JSON-RPC protocol
   - Previous versions worked but current doesn't

## What I Need

1. **How should NPX configure the MCP server path?**
   - Should it point to the NPX cache directory where files are downloaded?
   - Should it use `npx` command to re-download each time?
   - What's the most reliable cross-platform approach?

2. **Claude Desktop config.json format:**
   - Windows path: `C:\Users\[user]\AppData\Roaming\Claude\claude_desktop_config.json`
   - Mac path: `~/Library/Application Support/Claude/claude_desktop_config.json`
   - Linux path: `~/.config/Claude/claude_desktop_config.json`

3. **Example configurations that should work:**

For local installation:
```json
{
  "mcpServers": {
    "like-i-said-memory-v2": {
      "command": "node",
      "args": ["D:/path/to/mcp-quiet-wrapper.js"],
      "env": {
        "MCP_QUIET": "true"
      }
    }
  }
}
```

For NPX (what should this be?):
```json
{
  "mcpServers": {
    "like-i-said-memory-v2": {
      "command": "???",
      "args": ["???"],
      "env": {
        "MCP_QUIET": "true"
      }
    }
  }
}
```

## Specific Questions

1. **NPX execution:** When NPX installs a package, where does it install files and how long do they persist?

2. **Path resolution:** How to get the absolute path to the NPX-installed files from within the CLI script?

3. **Cross-platform:** What's the best way to handle Windows vs Unix path differences?

4. **Persistence:** Will pointing to NPX cache directory work after system restart?

5. **Alternative approaches:**
   - Should we copy files to a permanent location?
   - Should we use `npx` command in the config?
   - Should we download to user's home directory?

## Technical Details

- Node.js ESM modules (type: "module" in package.json)
- MCP requires clean stdout (only JSON-RPC messages)
- Works on Windows, macOS, and Linux
- Using `__dirname` via `fileURLToPath(import.meta.url)`

## What Has Been Tried

1. Using `npx` command directly in config - causes help text output
2. Detecting MCP mode in CLI - various environment checks failed
3. Creating separate entry points - gets complex

## Ideal Solution

A configuration approach that:
- Works reliably across platforms
- Doesn't require re-downloading on each start
- Properly starts the MCP server without any console output
- Handles NPX temporary directory limitations

Please provide best practices for NPX-based MCP server installation and configuration.